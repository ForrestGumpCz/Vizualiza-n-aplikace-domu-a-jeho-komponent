﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace VisualizationApp
{
    public class Draw
    {
        //Drawing Dimension FORM2
        public static void Dimension(Graphics g, Pen pen, Point from, string dimType, string type, int id)
        {
            int value = 1;
            int label_offsetX = 0;
            int label_offsetY = 0;
            Point to = new Point();
            StringFormat stringFormat = new StringFormat();
            stringFormat.Alignment = StringAlignment.Center;
            stringFormat.LineAlignment = StringAlignment.Center;
            int angle = 0;
            if (dimType == "left")
            {
                int width = Get.XOfObject(type, id) - Form2._start_offsetX;
                to.X = from.X + width;
                to.Y = from.Y;
                value = width / Form2. _zoom;
                label_offsetY = -10;
            }
            else if (dimType == "up")
            {
                int height = Get.YOfObject(type, id) - Form2._start_offsetY;
                to.X = from.X;
                to.Y = from.Y + height;
                value = height / Form2. _zoom;
                angle = 90;
                label_offsetX = 17;
            }
            else if (dimType == "right")
            {
                int width = Form2._openedWall.lenght * Form2. _zoom - from.X + Form2._start_offsetX;

                to.X = Form2._openedWall.lenght * Form2. _zoom + Form2._start_offsetX;
                to.Y = from.Y;
                value = width / Form2. _zoom;
                label_offsetY = -10;
            }


            else if (dimType == "down")
            {

                int height = Form2._openedWall.height * Form2. _zoom - from.Y + Form2._start_offsetY;
                to.X = from.X;
                to.Y = Form2._openedWall.height * Form2. _zoom + Form2._start_offsetY;
                value = height / Form2. _zoom;
                angle = 90;
                label_offsetX = 17;
            }



            //dimension body
            g.DrawLine(pen, from, to);

            //dimension label
            g.TranslateTransform(Get.MidPoint(from, to, 2).X, Get.MidPoint(from, to, 2).Y);


            g.DrawString(value.ToString() + "cm", new Font("Arial", 8), new SolidBrush(pen.Color), new Point(0 + label_offsetX, 0 + label_offsetY), stringFormat);
            g.ResetTransform();

            //start-point arrow
            g.TranslateTransform(from.X, from.Y);
            g.RotateTransform(330 + angle);
            g.DrawLine(pen, new Point(0, 0), new Point(8, 0));
            g.RotateTransform(-300);
            g.DrawLine(pen, new Point(0, 0), new Point(8, 0));
            g.ResetTransform();

            //end-point arrow
            g.TranslateTransform(to.X, to.Y);
            g.RotateTransform(150 + angle);
            g.DrawLine(pen, new Point(0, 0), new Point(8, 0));
            g.RotateTransform(60);
            g.DrawLine(pen, new Point(0, 0), new Point(8, 0));
            g.ResetTransform();
        }

        //Drawing all already created elements FORM2
        public static void CreatedElements(Pen pen, Graphics g)
        {
            //drawing all windows for this wall
            pen.Color = Color.Black;
            pen.Width = 2;
            foreach (Form1.objectEntity window in Form1.listWindows)
            {
                if (window.wallId == Form2._selectedWall && window.wallSide == Form2._wallSide)
                {
                    g.FillRectangle(Brushes.LightGray, window.locationXY.X, window.locationXY.Y, window.width * Form2._zoom, window.height * Form2._zoom);
                    g.DrawRectangle(pen, window.locationXY.X, window.locationXY.Y, window.width * Form2._zoom, window.height * Form2._zoom);
                }

            }

            //drawing all doors for this wall
            pen.Color = Color.Black;
            pen.Width = 2;
            foreach (Form1.objectEntity door in Form1.listDoors)
            {
                if (door.wallId == Form2._selectedWall && door.wallSide == Form2._wallSide)
                {
                    g.FillRectangle(Brushes.LightGray, door.locationXY.X, door.locationXY.Y, door.width * Form2._zoom, door.height * Form2._zoom);
                    g.DrawRectangle(pen, door.locationXY.X, door.locationXY.Y, door.width * Form2._zoom, door.height * Form2._zoom);
                }

            }

            //drawing all cables for this wall
            pen.Color = Color.Blue;
            pen.Width = 1;
            foreach (Form1.objectCableEntity cable in Form1.listCables)
            {
                if (cable.wallId == Form2._selectedWall && cable.wallSide == Form2._wallSide)
                {
                    if (EntityDetection.IsHorizontal(cable.width))
                        g.DrawRectangle(pen, cable.locationXY.X, cable.locationXY.Y, cable.width * Form2._zoom, cable.height);
                    else
                        g.DrawRectangle(pen, cable.locationXY.X, cable.locationXY.Y, cable.width, cable.height * Form2._zoom);
                }
            }

            //drawing all electrical boxes for this wall
            pen.Color = Color.Black;
            pen.Width = 1;
            foreach (Form1.objectEntity box in Form1.listElectricalBoxes)
            {
                if (box.wallId == Form2._selectedWall && box.wallSide == Form2._wallSide)
                {
                    g.FillEllipse(Brushes.LightGray, box.locationXY.X, box.locationXY.Y, box.width * Form2. _zoom, box.height * Form2. _zoom);
                    g.DrawEllipse(pen, box.locationXY.X, box.locationXY.Y, box.width * Form2. _zoom, box.height * Form2. _zoom);
                }
            }

            //drawing all sockets for this wall
            pen.Color = Color.Black;
            pen.Width = 1;
            foreach (Form1.objectEntity socket in Form1.listSockets)
            {
                if (socket.wallId == Form2._selectedWall && socket.wallSide == Form2._wallSide)
                {
                    int offsetX = Get.OffsetX(); //offset (changes with Form2. _zoom)

                    //draw socket
                    g.FillRectangle(Brushes.LightGray, socket.locationXY.X, socket.locationXY.Y, socket.width * Form2. _zoom, socket.height * Form2. _zoom);
                    g.DrawRectangle(pen, socket.locationXY.X, socket.locationXY.Y, socket.width * Form2. _zoom, socket.height * Form2. _zoom);

                    g.DrawEllipse(pen, (socket.locationXY.X + socket.width / 2) + offsetX, (socket.locationXY.Y + 2 * Form2. _zoom), 4 * Form2. _zoom, 4 * Form2. _zoom);
                    g.DrawEllipse(pen, (socket.locationXY.X + socket.width / 2) + offsetX, (socket.locationXY.Y + 8 * Form2. _zoom), 4 * Form2. _zoom, 4 * Form2. _zoom);

                    g.DrawEllipse(pen, (socket.locationXY.X + socket.width / 2) + offsetX + (int)(3.5 * Form2. _zoom / 2), (socket.locationXY.Y + 3 * Form2._zoom), (int)1 * Form2. _zoom / 2, (int)1 * Form2. _zoom / 2);
                    g.DrawEllipse(pen, (socket.locationXY.X + socket.width / 2) + offsetX + (int)(3.5 * Form2. _zoom / 2), (socket.locationXY.Y + 9 * Form2._zoom), (int)1 * Form2. _zoom / 2, (int)1 * Form2. _zoom / 2);

                    g.DrawEllipse(pen, (socket.locationXY.X + socket.width / 2) + offsetX + (int)(2 * Form2. _zoom / 2), (socket.locationXY.Y + 4 * Form2._zoom), (int)1 * Form2. _zoom / 2, (int)1 * Form2. _zoom / 2);
                    g.DrawEllipse(pen, (socket.locationXY.X + socket.width / 2) + offsetX + (int)(5 * Form2. _zoom / 2), (socket.locationXY.Y + 4 * Form2._zoom), (int)1 * Form2. _zoom / 2, (int)1 * Form2. _zoom / 2);
                    g.DrawEllipse(pen, (socket.locationXY.X + socket.width / 2) + offsetX + (int)(2 * Form2. _zoom / 2), (socket.locationXY.Y + 10 * Form2._zoom), (int)1 * Form2. _zoom / 2, (int)1 * Form2. _zoom / 2);
                    g.DrawEllipse(pen, (socket.locationXY.X + socket.width / 2) + offsetX + (int)(5 * Form2. _zoom / 2), (socket.locationXY.Y + 10 * Form2._zoom), (int)1 * Form2. _zoom / 2, (int)1 * Form2. _zoom / 2);
                }

            }

            //drawing all switches for this wall
            pen.Color = Color.Black;
            pen.Width = 1;
            foreach (Form1.objectEntity obj_switch in Form1.listSwitches)
            {
                if (obj_switch.wallId == Form2._selectedWall && obj_switch.wallSide == Form2._wallSide)
                {
                    g.FillRectangle(Brushes.LightGray, obj_switch.locationXY.X, obj_switch.locationXY.Y, obj_switch.width * Form2._zoom, obj_switch.height * Form2._zoom);
                    g.DrawRectangle(pen, obj_switch.locationXY.X, obj_switch.locationXY.Y, obj_switch.width * Form2._zoom, obj_switch.height * Form2._zoom);
                }

            }

            //drawing all Gas pipes for this wall
            pen.Color = Color.Yellow;
            pen.Width = 1;
            foreach (Form1.objectPipeEntity pipe in Form1.listGasPipes)
            {
                if (pipe.wallId == Form2._selectedWall && pipe.wallSide == Form2._wallSide)
                {
                    if (EntityDetection.IsHorizontal(pipe.width))
                        g.DrawRectangle(pen, pipe.locationXY.X, pipe.locationXY.Y, pipe.width * Form2. _zoom, pipe.height);
                    else
                        g.DrawRectangle(pen, pipe.locationXY.X, pipe.locationXY.Y, pipe.width, pipe.height * Form2. _zoom);
                }
            }

            //drawing all gas tapes for this wall
            foreach (Form1.objectTapEntity tap in Form1.listGasTapes)
            {
                if (tap.wallId == Form2._selectedWall && tap.wallSide == Form2._wallSide)
                    g.FillRectangle(Brushes.Yellow, tap.locationXY.X, tap.locationXY.Y, tap.width * Form2._zoom, tap.height * Form2._zoom);
            }

            //drawing all water pipes for this wall
            pen.Color = Color.Red;
            pen.Width = 1;
            foreach (Form1.objectPipeEntity pipe in Form1.listWaterPipes)
            {
                if (pipe.wallId == Form2._selectedWall && pipe.wallSide == Form2._wallSide)
                {
                    if (EntityDetection.IsHorizontal(pipe.width))
                        g.DrawRectangle(pen, pipe.locationXY.X, pipe.locationXY.Y, pipe.width * Form2. _zoom, pipe.height);
                    else
                        g.DrawRectangle(pen, pipe.locationXY.X, pipe.locationXY.Y, pipe.width, pipe.height * Form2. _zoom);
                }
            }

            //drawing all water tapes for this wall
            foreach (Form1.objectTapEntity tap in Form1.listWaterTapes)
            {
                if (tap.wallId == Form2._selectedWall && tap.wallSide == Form2._wallSide)
                    g.FillRectangle(Brushes.Red, tap.locationXY.X, tap.locationXY.Y, tap.width * Form2. _zoom, tap.height * Form2. _zoom);
            }

            //drawing all created dimensions for this wall
            foreach (Form1.objectDimension dim in Form1.listDimensions)
            {
                if (dim.wallId == Form2._selectedWall && dim.wallSide == Form2._wallSide)
                {
                    pen.Color = Color.Green;
                    pen.Width = 1;
                    Draw.Dimension(g, pen, dim.startXY, dim.dimType, dim.objectType, dim.idObject);
                }

            }

            //drawing all created labels for this wall
            foreach (Form1.WallLabels label in Form1.listWallLabels)
            {
                if (label.wallId == Form2._selectedWall && label.wallSide == Form2._wallSide)
                {
                    Color color = Color.Black;
                    StringFormat stringFormat = new StringFormat();
                    g.DrawString(label.text, new Font("Arial", 8), new SolidBrush(color), label.XY, stringFormat);
                }
            }
        }

        public static void Realtime(Pen pen, Graphics g)
        {
            //Real-time draw Window
            if (Form2._selectedWindow >= 0)
                g.DrawRectangle(pen,Form2._ptNEW.X,Form2. _ptNEW.Y, Form2._widthNEW * Form2. _zoom, Form2._heghtNEW * Form2. _zoom);

            //Real-time draw Door
            else if (Form2._selectedDoor >= 0)
                g.DrawRectangle(pen,Form2._ptNEW.X,Form2._ptNEW.Y, Form2._widthNEW * Form2. _zoom, Form2._heghtNEW * Form2. _zoom);

            //Real-time draw Cable
            else if (Form2._selectedCable >= 0)
                if (EntityDetection.IsHorizontal(Form2._widthNEW))
                    g.DrawRectangle(pen, Form2._ptNEW.X,Form2._ptNEW.Y, Form2._widthNEW * Form2. _zoom, Form2._heghtNEW);
                else
                    g.DrawRectangle(pen, Form2._ptNEW.X, Form2._ptNEW.Y, Form2._widthNEW, Form2._heghtNEW * Form2. _zoom);

            //Real-time draw Electrical Box
            else if (Form2._selectedElectricalBox >= 0)
                g.DrawEllipse(pen, Form2._ptNEW.X, Form2._ptNEW.Y, Form2._widthNEW * Form2. _zoom, Form2._heghtNEW * Form2. _zoom);

            //Real-time draw socket
            else if (Form2._selectedSocket >= 0)
            {
                int offsetX = Get.OffsetX(); //offset (changes with Form2. _zoom)

                //draw socket
                g.DrawRectangle(pen, Form2._ptNEW.X, Form2._ptNEW.Y, Form2._widthNEW * Form2. _zoom, Form2._heghtNEW * Form2. _zoom);

                g.DrawEllipse(pen, (Form2._ptNEW.X + Form2._widthNEW / 2) + offsetX, (Form2._ptNEW.Y + 2 * Form2. _zoom), 4 * Form2. _zoom, 4 * Form2. _zoom);
                g.DrawEllipse(pen, (Form2._ptNEW.X + Form2._widthNEW / 2) + offsetX, (Form2._ptNEW.Y + 8 * Form2. _zoom), 4 * Form2. _zoom, 4 * Form2. _zoom);

                g.DrawEllipse(pen, (Form2._ptNEW.X + Form2._widthNEW / 2) + offsetX + (int)(3.5 * Form2. _zoom / 2), (Form2._ptNEW.Y + 3 * Form2. _zoom), (int)1 * Form2. _zoom / 2, (int)1 * Form2. _zoom / 2);
                g.DrawEllipse(pen, (Form2._ptNEW.X + Form2._widthNEW / 2) + offsetX + (int)(3.5 * Form2. _zoom / 2), (Form2._ptNEW.Y + 9 * Form2. _zoom), (int)1 * Form2. _zoom / 2, (int)1 * Form2. _zoom / 2);

                g.DrawEllipse(pen, (Form2._ptNEW.X + Form2._widthNEW / 2) + offsetX + (int)(2 * Form2. _zoom / 2), (Form2._ptNEW.Y + 4 * Form2. _zoom), (int)1 * Form2. _zoom / 2, (int)1 * Form2. _zoom / 2);
                g.DrawEllipse(pen, (Form2._ptNEW.X + Form2._widthNEW / 2) + offsetX + (int)(5 * Form2. _zoom / 2), (Form2._ptNEW.Y + 4 * Form2. _zoom), (int)1 * Form2. _zoom / 2, (int)1 * Form2. _zoom / 2);
                g.DrawEllipse(pen, (Form2._ptNEW.X + Form2._widthNEW / 2) + offsetX + (int)(2 * Form2. _zoom / 2), (Form2._ptNEW.Y + 10 * Form2. _zoom), (int)1 * Form2. _zoom / 2, (int)1 * Form2. _zoom / 2);
                g.DrawEllipse(pen, (Form2._ptNEW.X + Form2._widthNEW / 2) + offsetX + (int)(5 * Form2. _zoom / 2), (Form2._ptNEW.Y + 10 * Form2. _zoom), (int)1 * Form2. _zoom / 2, (int)1 * Form2. _zoom / 2);
            }

            //Real-time draw switch
            else if (Form2._selectedSwitch >= 0)
                g.DrawRectangle(pen,Form2._ptNEW.X, Form2._ptNEW.Y, Form2._widthNEW * Form2. _zoom, Form2._heghtNEW * Form2. _zoom);

            //Real-time draw Gas pipe
            else if (Form2._selectedGasPipe >= 0)
                if (EntityDetection.IsHorizontal(Form2._widthNEW))
                    g.DrawRectangle(pen, Form2._ptNEW.X, Form2._ptNEW.Y, Form2._widthNEW * Form2. _zoom, Form2._heghtNEW);
                else
                    g.DrawRectangle(pen,Form2. _ptNEW.X,Form2._ptNEW.Y, Form2._widthNEW, Form2._heghtNEW * Form2. _zoom);

            //Real-time draw gas tap
            else if (Form2._selectedGasTap >= 0)
                g.DrawRectangle(pen, Form2._ptNEW.X, Form2._ptNEW.Y, Form2._widthNEW * Form2. _zoom, Form2._heghtNEW * Form2. _zoom);

            //Real-time draw Water pipe
            else if (Form2._selectedWaterPipe >= 0)
                if (EntityDetection.IsHorizontal(Form2._widthNEW))
                    g.DrawRectangle(pen, Form2._ptNEW.X, Form2._ptNEW.Y, Form2._widthNEW * Form2. _zoom, Form2._heghtNEW);
                else
                    g.DrawRectangle(pen, Form2._ptNEW.X, Form2._ptNEW.Y, Form2._widthNEW, Form2._heghtNEW * Form2. _zoom);

            //Real-time draw water tap
            else if (Form2._selectedWaterTap >= 0)
                g.DrawRectangle(pen, Form2._ptNEW.X, Form2._ptNEW.Y, Form2._widthNEW * Form2. _zoom, Form2._heghtNEW * Form2. _zoom);

            else if (Form2._selectedDimension >= 0)
                Draw.Dimension(g, pen, new Point(Form2._ptNEW.X, Form2._ptNEW.Y), Form1.listDimensions[Form2._selectedDimension].dimType, Form1.listDimensions[Form2._selectedDimension].objectType, Form1.listDimensions[Form2._selectedDimension].idObject);

            else if (Form2._selectedLabel >= 0)
            {
                Color color = Color.Gray;
                StringFormat stringFormat = new StringFormat();
                g.DrawString(Form1.listWallLabels[Form2._selectedLabel].text, new Font("Arial", 8), new SolidBrush(color), Form2._ptNEW, stringFormat);
            }
        }

        public static void Selected(Pen pen, Graphics g)
        {
            if (Form2._selectedWindow >= 0)
            {
                if (Form1.listWindows[Form2._selectedWindow].wallId ==Form2._selectedWall && Form1.listWindows[Form2._selectedWindow].wallSide == Form2._wallSide)
                {
                    pen.Color = Color.Black;
                    pen.Width = 3;
                    g.FillRectangle(Brushes.LightGray, Form1.listWindows[Form2._selectedWindow].locationXY.X, Form1.listWindows[Form2._selectedWindow].locationXY.Y, Form1.listWindows[Form2._selectedWindow].width * Form2._zoom, Form1.listWindows[Form2._selectedWindow].height * Form2._zoom);
                    g.DrawRectangle(pen, Form1.listWindows[Form2._selectedWindow].locationXY.X, Form1.listWindows[Form2._selectedWindow].locationXY.Y, Form1.listWindows[Form2._selectedWindow].width * Form2._zoom, Form1.listWindows[Form2._selectedWindow].height * Form2._zoom);
                }
            }

            else if (Form2._selectedDoor >= 0)
            {
                if (Form1.listDoors[Form2._selectedDoor].wallId ==Form2._selectedWall && Form1.listDoors[Form2._selectedDoor].wallSide == Form2._wallSide)
                {
                    pen.Color = Color.Black;
                    pen.Width = 3;
                    g.FillRectangle(Brushes.LightGray, Form1.listDoors[Form2._selectedDoor].locationXY.X, Form1.listDoors[Form2._selectedDoor].locationXY.Y, Form1.listDoors[Form2._selectedDoor].width * Form2._zoom, Form1.listDoors[Form2._selectedDoor].height * Form2._zoom);
                    g.DrawRectangle(pen, Form1.listDoors[Form2._selectedDoor].locationXY.X, Form1.listDoors[Form2._selectedDoor].locationXY.Y, Form1.listDoors[Form2._selectedDoor].width * Form2._zoom, Form1.listDoors[Form2._selectedDoor].height * Form2._zoom);
                }
            }

            else if (Form2._selectedCable >= 0)
            {
                if (Form1.listCables[Form2._selectedCable].wallId ==Form2._selectedWall && Form1.listCables[Form2._selectedCable].wallSide == Form2._wallSide)
                {
                    pen.Color = Color.LightBlue;
                    pen.Width = 3;
                    if (EntityDetection.IsHorizontal(Form1.listCables[Form2._selectedCable].width))
                        g.DrawRectangle(pen, Form1.listCables[Form2._selectedCable].locationXY.X, Form1.listCables[Form2._selectedCable].locationXY.Y, Form1.listCables[Form2._selectedCable].width * Form2._zoom, Form1.listCables[Form2._selectedCable].height);

                    else
                        g.DrawRectangle(pen, Form1.listCables[Form2._selectedCable].locationXY.X, Form1.listCables[Form2._selectedCable].locationXY.Y, Form1.listCables[Form2._selectedCable].width, Form1.listCables[Form2._selectedCable].height * Form2._zoom);

                }
            }

            else if (Form2._selectedElectricalBox >= 0)
            {
                if (Form1.listElectricalBoxes[Form2._selectedElectricalBox].wallId ==Form2._selectedWall && Form1.listElectricalBoxes[Form2._selectedElectricalBox].wallSide == Form2._wallSide)
                {
                    pen.Color = Color.Black;
                    pen.Width = 2;
                    g.FillRectangle(Brushes.LightGray, Form1.listElectricalBoxes[Form2._selectedElectricalBox].locationXY.X, Form1.listElectricalBoxes[Form2._selectedElectricalBox].locationXY.Y, Form1.listElectricalBoxes[Form2._selectedElectricalBox].width * Form2._zoom, Form1.listElectricalBoxes[Form2._selectedElectricalBox].height * Form2._zoom);
                    g.DrawEllipse(pen, Form1.listElectricalBoxes[Form2._selectedElectricalBox].locationXY.X, Form1.listElectricalBoxes[Form2._selectedElectricalBox].locationXY.Y, Form1.listElectricalBoxes[Form2._selectedElectricalBox].width * Form2._zoom, Form1.listElectricalBoxes[Form2._selectedElectricalBox].height * Form2._zoom);
                }
            }

            else if (Form2._selectedSocket >= 0)
            {
                if (Form1.listSockets[Form2._selectedSocket].wallId ==Form2._selectedWall && Form1.listSockets[Form2._selectedSocket].wallSide == Form2._wallSide)
                {
                    pen.Color = Color.Black;
                    pen.Width = 2;
                    int offsetX = Get.OffsetX(); //offset (changes with _zoom)

                    //draw socket
                    g.FillRectangle(Brushes.LightGray, Form1.listSockets[Form2._selectedSocket].locationXY.X, Form1.listSockets[Form2._selectedSocket].locationXY.Y, Form1.listSockets[Form2._selectedSocket].width * Form2._zoom, Form1.listSockets[Form2._selectedSocket].height * Form2._zoom);
                    g.DrawRectangle(pen, Form1.listSockets[Form2._selectedSocket].locationXY.X, Form1.listSockets[Form2._selectedSocket].locationXY.Y, Form1.listSockets[Form2._selectedSocket].width * Form2._zoom, Form1.listSockets[Form2._selectedSocket].height * Form2._zoom);

                    g.DrawEllipse(pen, (Form1.listSockets[Form2._selectedSocket].locationXY.X + Form1.listSockets[Form2._selectedSocket].width / 2) + offsetX, (Form1.listSockets[Form2._selectedSocket].locationXY.Y + 2 * Form2._zoom), 4 * Form2._zoom, 4 * Form2._zoom);
                    g.DrawEllipse(pen, (Form1.listSockets[Form2._selectedSocket].locationXY.X + Form1.listSockets[Form2._selectedSocket].width / 2) + offsetX, (Form1.listSockets[Form2._selectedSocket].locationXY.Y + 8 * Form2._zoom), 4 * Form2._zoom, 4 * Form2._zoom);

                    g.DrawEllipse(pen, (Form1.listSockets[Form2._selectedSocket].locationXY.X + Form1.listSockets[Form2._selectedSocket].width / 2) + offsetX + (int)(3.5 * Form2._zoom / 2), (Form1.listSockets[Form2._selectedSocket].locationXY.Y + 3 * Form2._zoom), (int)1 * Form2._zoom / 2, (int)1 * Form2._zoom / 2);
                    g.DrawEllipse(pen, (Form1.listSockets[Form2._selectedSocket].locationXY.X + Form1.listSockets[Form2._selectedSocket].width / 2) + offsetX + (int)(3.5 * Form2._zoom / 2), (Form1.listSockets[Form2._selectedSocket].locationXY.Y + 9 * Form2._zoom), (int)1 * Form2._zoom / 2, (int)1 * Form2._zoom / 2);

                    g.DrawEllipse(pen, (Form1.listSockets[Form2._selectedSocket].locationXY.X + Form1.listSockets[Form2._selectedSocket].width / 2) + offsetX + (int)(2 * Form2._zoom / 2), (Form1.listSockets[Form2._selectedSocket].locationXY.Y + 4 * Form2._zoom), (int)1 * Form2._zoom / 2, (int)1 * Form2._zoom / 2);
                    g.DrawEllipse(pen, (Form1.listSockets[Form2._selectedSocket].locationXY.X + Form1.listSockets[Form2._selectedSocket].width / 2) + offsetX + (int)(5 * Form2._zoom / 2), (Form1.listSockets[Form2._selectedSocket].locationXY.Y + 4 * Form2._zoom), (int)1 * Form2._zoom / 2, (int)1 * Form2._zoom / 2);
                    g.DrawEllipse(pen, (Form1.listSockets[Form2._selectedSocket].locationXY.X + Form1.listSockets[Form2._selectedSocket].width / 2) + offsetX + (int)(2 * Form2._zoom / 2), (Form1.listSockets[Form2._selectedSocket].locationXY.Y + 10 * Form2._zoom), (int)1 * Form2._zoom / 2, (int)1 * Form2._zoom / 2);
                    g.DrawEllipse(pen, (Form1.listSockets[Form2._selectedSocket].locationXY.X + Form1.listSockets[Form2._selectedSocket].width / 2) + offsetX + (int)(5 * Form2._zoom / 2), (Form1.listSockets[Form2._selectedSocket].locationXY.Y + 10 * Form2._zoom), (int)1 * Form2._zoom / 2, (int)1 * Form2._zoom / 2);
                }
            }

            else if (Form2._selectedSwitch >= 0)
            {
                if (Form1.listSwitches[Form2._selectedSwitch].wallId ==Form2._selectedWall && Form1.listSwitches[Form2._selectedSwitch].wallSide == Form2._wallSide)
                {
                    pen.Color = Color.Black;
                    pen.Width = 2;
                    g.FillRectangle(Brushes.LightGray, Form1.listSwitches[Form2._selectedSwitch].locationXY.X, Form1.listSwitches[Form2._selectedSwitch].locationXY.Y, Form1.listSwitches[Form2._selectedSwitch].width * Form2._zoom, Form1.listSwitches[Form2._selectedSwitch].height * Form2._zoom);
                    g.DrawRectangle(pen, Form1.listSwitches[Form2._selectedSwitch].locationXY.X, Form1.listSwitches[Form2._selectedSwitch].locationXY.Y, Form1.listSwitches[Form2._selectedSwitch].width * Form2._zoom, Form1.listSwitches[Form2._selectedSwitch].height * Form2._zoom);
                }
            }

            else if (Form2._selectedGasPipe >= 0)
            {
                if (Form1.listGasPipes[Form2._selectedGasPipe].wallId ==Form2._selectedWall && Form1.listGasPipes[Form2._selectedGasPipe].wallSide == Form2._wallSide)
                {
                    pen.Color = Color.LightBlue;
                    pen.Width = 3;
                    if (EntityDetection.IsHorizontal(Form1.listGasPipes[Form2._selectedGasPipe].width))
                        g.DrawRectangle(pen, Form1.listGasPipes[Form2._selectedGasPipe].locationXY.X, Form1.listGasPipes[Form2._selectedGasPipe].locationXY.Y, Form1.listGasPipes[Form2._selectedGasPipe].width * Form2._zoom, Form1.listGasPipes[Form2._selectedGasPipe].height);

                    else
                        g.DrawRectangle(pen, Form1.listGasPipes[Form2._selectedGasPipe].locationXY.X, Form1.listGasPipes[Form2._selectedGasPipe].locationXY.Y, Form1.listGasPipes[Form2._selectedGasPipe].width, Form1.listGasPipes[Form2._selectedGasPipe].height * Form2._zoom);

                }
            }

            else if (Form2._selectedGasTap >= 0)
            {
                if (Form1.listGasTapes[Form2._selectedGasTap].wallId ==Form2._selectedWall && Form1.listGasTapes[Form2._selectedGasTap].wallSide == Form2._wallSide)
                {
                    g.FillRectangle(Brushes.LightBlue, Form1.listGasTapes[Form2._selectedGasTap].locationXY.X, Form1.listGasTapes[Form2._selectedGasTap].locationXY.Y, Form1.listGasTapes[Form2._selectedGasTap].width * Form2._zoom, Form1.listGasTapes[Form2._selectedGasTap].height * Form2._zoom);
                }
            }

            else if (Form2._selectedWaterPipe >= 0)
            {
                if (Form1.listWaterPipes[Form2._selectedWaterPipe].wallId ==Form2._selectedWall && Form1.listWaterPipes[Form2._selectedWaterPipe].wallSide == Form2._wallSide)
                {
                    pen.Color = Color.LightBlue;
                    pen.Width = 3;
                    if (EntityDetection.IsHorizontal(Form1.listWaterPipes[Form2._selectedWaterPipe].width))
                        g.DrawRectangle(pen, Form1.listWaterPipes[Form2._selectedWaterPipe].locationXY.X, Form1.listWaterPipes[Form2._selectedWaterPipe].locationXY.Y, Form1.listWaterPipes[Form2._selectedWaterPipe].width * Form2._zoom, Form1.listWaterPipes[Form2._selectedWaterPipe].height);

                    else
                        g.DrawRectangle(pen, Form1.listWaterPipes[Form2._selectedWaterPipe].locationXY.X, Form1.listWaterPipes[Form2._selectedWaterPipe].locationXY.Y, Form1.listWaterPipes[Form2._selectedWaterPipe].width, Form1.listWaterPipes[Form2._selectedWaterPipe].height * Form2._zoom);

                }
            }

            else if (Form2._selectedWaterTap >= 0)
            {
                if (Form1.listWaterTapes[Form2._selectedWaterTap].wallId ==Form2._selectedWall && Form1.listWaterTapes[Form2._selectedWaterTap].wallSide == Form2._wallSide)
                {
                    g.FillRectangle(Brushes.LightBlue, Form1.listWaterTapes[Form2._selectedWaterTap].locationXY.X, Form1.listWaterTapes[Form2._selectedWaterTap].locationXY.Y, Form1.listWaterTapes[Form2._selectedWaterTap].width * Form2._zoom, Form1.listWaterTapes[Form2._selectedWaterTap].height * Form2._zoom);
                }
            }

            else if (Form2._selectedDimension >= 0)
            {
                if (Form1.listDimensions[Form2._selectedDimension].wallId ==Form2._selectedWall && Form1.listDimensions[Form2._selectedDimension].wallSide == Form2._wallSide)
                {
                    pen.Color = Color.Orange;
                    Draw.Dimension(g, pen, Form1.listDimensions[Form2._selectedDimension].startXY, Form1.listDimensions[Form2._selectedDimension].dimType, Form1.listDimensions[Form2._selectedDimension].objectType, Form1.listDimensions[Form2._selectedDimension].idObject);
                }
            }

            else if (Form2._selectedLabel >= 0)
            {
                if (Form1.listWallLabels[Form2._selectedLabel].wallId ==Form2._selectedWall && Form1.listWallLabels[Form2._selectedLabel].wallSide == Form2._wallSide)
                {
                    Color color = Color.Red;
                    StringFormat stringFormat = new StringFormat();
                    g.DrawString(Form1.listWallLabels[Form2._selectedLabel].text, new Font("Arial", 8), new SolidBrush(color), Form1.listWallLabels[Form2._selectedLabel].XY, stringFormat);

                }
            }
        }

        //Draws label on selected position
        public static void Label(Point pt, string text, Graphics g, Color color)
        {
            StringFormat stringFormat = new StringFormat();
            stringFormat.Alignment = StringAlignment.Center;
            stringFormat.LineAlignment = StringAlignment.Center;
            g.DrawString(text, new Font("Arial", 8), new SolidBrush(color), pt, stringFormat);
        }

        public static void Dimension(Point from, Point to, int value, Graphics g)
        {
            Pen pen = new Pen(Color.Green);
            float angle = Get.Angle(from, to);
            StringFormat stringFormat = new StringFormat();
            stringFormat.Alignment = StringAlignment.Center;
            stringFormat.LineAlignment = StringAlignment.Center;

            int offset = 10; //offset size from oreginal line
            int length = (int)Get.Distance(from, to);

            if (length <= 0)
                length = 1;

            //coordinates recalculation for dimension (parallel line)
            Point dim_from = new Point(from.X + offset * (to.Y - from.Y) / length, from.Y + offset * (from.X - to.X) / length);
            Point dim_to = new Point(to.X + offset * (to.Y - from.Y) / length, to.Y + offset * (from.X - to.X) / length);

            //dimension body
            g.DrawLine(pen, dim_from, dim_to);


            //dimension label
            g.TranslateTransform(Get.MidPoint(dim_from, dim_to, 2).X, Get.MidPoint(dim_from, dim_to, 2).Y);
            g.RotateTransform(angle);

            if (dim_from.X > dim_to.X)
            {
                g.RotateTransform(180);
                offset *= -1;
            }

            g.DrawString(value.ToString() + "cm", new Font("Arial", 8), new SolidBrush(Color.Green), new Point(0, -offset), stringFormat);
            g.ResetTransform();

            //start-point arrow
            g.TranslateTransform(dim_from.X, dim_from.Y);
            g.RotateTransform(angle);
            g.RotateTransform(330);
            g.DrawLine(pen, new Point(0, 0), new Point(8, 0));
            g.RotateTransform(-300);
            g.DrawLine(pen, new Point(0, 0), new Point(8, 0));
            g.ResetTransform();

            //end-point arrow
            g.TranslateTransform(dim_to.X, dim_to.Y);
            g.RotateTransform(angle);
            g.RotateTransform(150);
            g.DrawLine(pen, new Point(0, 0), new Point(8, 0));
            g.RotateTransform(60);
            g.DrawLine(pen, new Point(0, 0), new Point(8, 0));
            g.ResetTransform();
        }

        //It draws angle dimension
        public static void DimAngle(Point from, Point to, Graphics g)
        {
            //wall angle
            StringFormat stringFormat = new StringFormat();
            stringFormat.Alignment = StringAlignment.Center;
            stringFormat.LineAlignment = StringAlignment.Center;
            float angle = Get.Angle(from, to);
            string angle_string = Math.Round(Math.Abs(angle), 1).ToString() + "°";
            g.TranslateTransform(to.X, to.Y);
            g.DrawString(angle_string, new Font("Arial", 8), new SolidBrush(Color.Green), new Point(30, 10), stringFormat);
            g.ResetTransform();
        }
    }
}
