﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing.Drawing2D;
using System.IO;
using System.Runtime.Serialization;
using System.Xml;
using System.Xml.Serialization;

namespace VisualizationApp
{
    public partial class Form1 : Form
    {
        
        public static List<Walls> listWalls;
        public static List<WallLabels> listWallLabels;
        public static List<objectEntity> listWindows;
        public static List<objectEntity> listDoors;
        public static List<objectCableEntity> listCables;
        public static List<objectEntity> listElectricalBoxes;
        public static List<objectEntity> listSockets;
        public static List<objectEntity> listSwitches;
        public static List<objectPipeEntity> listGasPipes;
        public static List<objectTapEntity> listGasTapes;
        public static List<objectTapEntity> listWaterTapes;
        public static List<objectPipeEntity> listWaterPipes;
        public static List<objectDimension> listDimensions;

        public Form1()
        {
            InitializeComponent();
            listWalls = new List<Walls>();
            listWallLabels = new List<WallLabels>();
            listWindows = new List<objectEntity>();
            listDoors = new List<objectEntity>();
            listCables = new List<objectCableEntity>();
            listElectricalBoxes = new List<objectEntity>();
            listSockets = new List<objectEntity>();
            listSwitches = new List<objectEntity>();
            listGasPipes = new List<objectPipeEntity>();
            listGasTapes = new List<objectTapEntity>();
            listWaterPipes = new List<objectPipeEntity>();
            listWaterTapes = new List<objectTapEntity>();
            listDimensions = new List<objectDimension>();
        }

        public class Save
        {
            public List<Walls> listWalls;
            public List<Labels> listLabels;
            public List<WallLabels> listWallLabels;
            public List<objectEntity> listWindows;
            public List<objectEntity> listDoors;
            public List<objectCableEntity> listCables;
            public List<objectEntity> listElectricalBoxes;
            public List<objectEntity> listSockets;
            public List<objectEntity> listSwitches;
            public List<objectPipeEntity> listGasPipes;
            public List<objectTapEntity> listGasTapes;
            public List<objectPipeEntity> listWaterPipes;
            public List<objectTapEntity> listWaterTapes;
            public List<objectDimension> listDimensions;
        }

        public class WallLabels : Labels
        {
            public int wallId;
            public char wallSide;
        }

        public class Labels
        {
            public int id;
            public String text;
            public Point XY;
        }

        
        public class Walls
        {
            public String name;
            public Point startXY;   //location of mouse down           
            public Point finishXY;    //location when mouse up                   
            public int lenght;        // in centimetres           
            public int width;        // in centimetres            
            public int height;       // in centimetres            
            public int material;
        }


        public class objectEntity
        {
            public string name;
            public int wallId;
            public char wallSide;
            public Point locationXY;
            public int height;
            public int width;
        }

        public class objectCableEntity : objectEntity
        {
            public string isolation;
            public string diameter;
            public int num_of_wires;
            public string material_of_wires;
        }

        public class objectPipeEntity :objectEntity
        {
            public string diameter;
            public string material;
        }
        public class objectTapEntity : objectEntity
        {
            public string diameter;
        }

        public class objectDimension
        {
            public Point startXY;
            public int wallId;
            public char wallSide;
            public string dimType;
            public string objectType;
            public int idObject;
        }

        public static List<Labels> listLabels = new List<Labels>();

        //Global variables
        Point _ptFrom, _ptTo, _newPt1, _newPt2;
        Walls _copiedWall = new Walls();
        Labels _copiedLabel = new Labels();
        public static int _selectedWall = -1;
        public static int _selectedLabel = -1;
        public static bool _alreadySelected = false; //true if any wall selected
        public static int _resizing = 0; // 0 = no _resizing, 1 start-point, 2 finish-point
        int _canvasMovingX = 0, _canvasMovingY = 0; //canvas moving distances

        int _labelCounter = 0;
        bool _isMouseDown = false;
        bool _allowDim = false;
        int _mouseOnWall = -1;
        int _timeToHide = 5; //interval to hide labe saved
        

        private void Form1_Load(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
            button_paste.Enabled = false;
            button_copy.Enabled = false;
            SetWallPropertiesToDefault();
            label_saved.Visible = false;
        }
//Mouse interactions
        private void pictureBox_canvas_MouseDown(object sender, MouseEventArgs e)
        {
            button_copy.Enabled = false;
            button_delete.Enabled = false;
            _allowDim = false;
            _canvasMovingX = 0;
            _canvasMovingY = 0;

            _isMouseDown = true;
            int i;
            _ptFrom = e.Location;
            _ptTo = e.Location;

            //new wall creation
            if (radioButton_wall.Checked)
            {
                _selectedLabel = -1;
                return;
            }
                
            //label, wall, free space click detection         
            else if (radioButton_hand.Checked)
            {
                i = 0;
                _selectedLabel = -1;
                _selectedWall = -1;
                
                //label click detection
                foreach(Labels label in listLabels)
                {
                    if (EntityDetection.MouseProximityDetection(new Point(label.XY.X, label.XY.Y - 5), e.Location, (int)label.text.Length , 10))
                    {
                        button_copy.Enabled = true;
                        _selectedLabel = i;
                        _newPt1 = listLabels[_selectedLabel].XY;
                        textBox_wallName.Text = listLabels[_selectedLabel].text;
                        return;
                    }
                    i++;
                }                   

                i = Get.IndexOfWall(e);

                //wall click detection
                if (i >= 0)
                {
                    button_copy.Enabled = true;
                    button_delete.Enabled = true;
                    Cursor = Cursors.Cross;
                    _selectedWall = i;
                    _newPt1 = listWalls[_selectedWall].startXY;
                    _newPt2 = listWalls[_selectedWall].finishXY;

                    //load info about wall
                    textBox_wallName.Text = listWalls[_selectedWall].name;
                    numericUpDown_wallLength.Value = new decimal((double)listWalls[_selectedWall].lenght);
                    numericUpDown_wallWidth.Value = new decimal((double)listWalls[_selectedWall].width);
                    numericUpDown_wallHeight.Value = new decimal((double)listWalls[_selectedWall].height);
                    comboBox_wallMaterial.SelectedIndex = listWalls[_selectedWall].material;

                    pictureBox_canvas.Invalidate();
                }

                //free space click detection == cancel selection
                else if (i < 0 && _selectedLabel < 0)
                {
                    _selectedLabel = -1;
                    _selectedWall = i;
                    numericUpDown_wallLength.Value = 0;
                    numericUpDown_wallWidth.Value = 0;
                    comboBox_wallMaterial.SelectedIndex = 0;
                    SetWallPropertiesToDefault();
                }

            }

            //new label creation
            else if (radioButton_label.Checked)
            {
                
                Labels label = new Labels();
                label.id = _labelCounter; 
                label.XY = e.Location;
                label.text = "Zde napište text";
                listLabels.Add(label);
                textBox_wallName.Text = label.text;
                listBox_explorer.ExplorerForm1(comboBox_wallMaterial);
                pictureBox_canvas.Invalidate();
                _labelCounter++;
            }
        }
        private void pictureBox_canvas_MouseMove(object sender, MouseEventArgs e)
        {
            //snap to points (start-points OR end-points)
            if (ToolStripMenuItem_pointSnap.Checked)
            {
                foreach (Walls wall in listWalls)
                {
                    //no snap to self points
                    if (_selectedWall >= 0 && wall == listWalls[_selectedWall])
                        continue;
                    else
                    {
                        if (EntityDetection.MouseProximityDetection(wall.startXY, e.Location, 3, 3))
                        {
                            Cursor.Position = pictureBox_canvas.PointToScreen(new Point(0, 0)) + (Size)(wall.startXY);
                            break;
                        }
                        if (EntityDetection.MouseProximityDetection(wall.finishXY, e.Location, 3, 3))
                        {
                            Cursor.Position = pictureBox_canvas.PointToScreen(new Point(0, 0)) + (Size)(wall.finishXY);
                            break;
                        }
                    }                    
                }
            }

            //hover over wall
            if (radioButton_hand.Checked && _isMouseDown == false)
            {
                int i;
                if ((i = Get.IndexOfWall(e)) >= 0)
                    _mouseOnWall = i;
                
                else
                    _mouseOnWall = -1;
            }

            //wall customize (point moving, wall moving)
            else if (radioButton_hand.Checked && _isMouseDown == true && _selectedWall >= 0)
            {
                //Moving wall
                if (_resizing == 0)
                {
                    _newPt1.X = e.X + listWalls[_selectedWall].startXY.X - _ptFrom.X;
                    _newPt1.Y = e.Y + listWalls[_selectedWall].startXY.Y - _ptFrom.Y;
                    _newPt2.X = e.X + listWalls[_selectedWall].finishXY.X - _ptFrom.X;
                    _newPt2.Y = e.Y + listWalls[_selectedWall].finishXY.Y - _ptFrom.Y;
                }
                //moving with start-point of wall
                else if (_resizing == 1)
                {
                    _newPt1.X = e.X + listWalls[_selectedWall].startXY.X - _ptFrom.X;
                    _newPt1.Y = e.Y + listWalls[_selectedWall].startXY.Y - _ptFrom.Y;
                    _allowDim = true;
                }
                //moving with end-point of wall
                else if (_resizing == 2)
                {
                    _newPt2.X = e.X + listWalls[_selectedWall].finishXY.X - _ptFrom.X;
                    _newPt2.Y = e.Y + listWalls[_selectedWall].finishXY.Y - _ptFrom.Y;
                    _allowDim = true;
                }
            }
            
            //canvas moving
            else if (radioButton_hand.Checked && _isMouseDown == true && _selectedWall < 0 && _selectedLabel < 0)
            {
                _canvasMovingX = e.Location.X - _ptFrom.X;
                _canvasMovingY = e.Location.Y - _ptFrom.Y;
            }

            //drawing wall real time
            else if (radioButton_wall.Checked && _isMouseDown && _selectedLabel < 0)
            {
                _ptTo = e.Location;
                _allowDim = true;
            }
           
            //moving label real time
            else if(radioButton_hand.Checked && _isMouseDown && _selectedLabel >= 0)
            {
                _newPt1 = new Point(e.Location.X,e.Location.Y);
            }


            pictureBox_canvas.Invalidate(); // it starts pictureBox_canvas_Paint()
        }
        private void pictureBox_canvas_MouseUp(object sender, MouseEventArgs e)
        {
            _isMouseDown = false;
            _allowDim = false;
            //Draw new wall
            if (radioButton_wall.Checked && e.Button == MouseButtons.Left)
            {
                if ((int)Get.Distance(_ptFrom, _ptTo) > 0)
                {
                    listWalls.Add(NewEntity.Wall(_ptFrom, _ptTo));
                    pictureBox_canvas.Invalidate();
                }
            }

            //moving selected walls (recalculation of positions) + wall customizing
            else if (radioButton_hand.Checked && e.Button == MouseButtons.Left && _selectedWall >= 0)
            {
                if (_ptFrom != e.Location)
                {
                    listWalls[_selectedWall].startXY = _newPt1;
                    listWalls[_selectedWall].finishXY = _newPt2;
                    listWalls[_selectedWall].lenght = Get.Distance(_newPt1, _newPt2);
                }
                _alreadySelected = true;

                Cursor = Cursors.Hand;
                pictureBox_canvas.Invalidate();
            }

            //moving with canvas (clicked-hold on free space)
            else if (radioButton_hand.Checked && e.Button == MouseButtons.Left && _selectedWall < 0 && _selectedLabel < 0)
            {
                _alreadySelected = false;
                if (_ptFrom != e.Location)
                {
                    foreach (Walls wall in listWalls)//recalculation of coordinates for each wall
                    {
                        wall.startXY.X = wall.startXY.X + _canvasMovingX;
                        wall.startXY.Y = wall.startXY.Y + _canvasMovingY;
                        wall.finishXY.X = wall.finishXY.X + _canvasMovingX;
                        wall.finishXY.Y = wall.finishXY.Y + _canvasMovingY;
                    }
                    foreach(Labels label in listLabels)
                    {
                        label.XY.X += _canvasMovingX;
                        label.XY.Y += _canvasMovingY;            
                    }
                }
            }
            
            //moving with label
            else if(radioButton_hand.Checked && e.Button == MouseButtons.Left && _selectedLabel >= 0)
            {
                listLabels[_selectedLabel].XY = _newPt1;
            }
            listBox_explorer.ExplorerForm1(comboBox_wallMaterial);
        }

//My methods
        private void resetAll()
        {
            listWalls.Clear();
            listWindows.Clear();
            listDoors.Clear();
            listCables.Clear();
            listElectricalBoxes.Clear();
            listSockets.Clear();
            listSwitches.Clear();
            listGasPipes.Clear();
            listGasTapes.Clear();
            listWaterTapes.Clear();
            listWaterPipes.Clear();
            listDimensions.Clear();
            SetWallPropertiesToDefault();

            listLabels.Clear();
            _copiedWall = new Walls();
            _selectedWall = -1;
            _selectedLabel = -1;
            _alreadySelected = false;
            _resizing = 0;
            _canvasMovingX = 0;
            _canvasMovingY = 0;
            _labelCounter = 0;
            _isMouseDown = false;
            _allowDim = false;
            _mouseOnWall = -1;

            listBox_explorer.ExplorerForm1(comboBox_wallMaterial);
            pictureBox_canvas.Invalidate();
        }

        private void radioButton_hand_CheckedChanged(object sender, EventArgs e)
        {
            //changing cursor type on changed drawing mode
            if (radioButton_hand.Checked)
                Cursor = Cursors.Hand;
            else
                Cursor = Cursors.Arrow;
        }
    
    //Get methods

        //It Sets wall properties window to default "no select" mode
        private void SetWallPropertiesToDefault()
        {
            textBox_wallName.Text = "Není vybraná žádná stěna";
            numericUpDown_wallLength.Value = 0;
            numericUpDown_wallWidth.Value = 0;
            comboBox_wallMaterial.SelectedIndex = 0;
        }

        public void LabelProperties()
        {
            label6.Text = "Text";
            label3.Visible = false;
            label4.Visible = false;
            label5.Visible = false;
            label7.Visible = false;
            numericUpDown_wallHeight.Visible = false;
            numericUpDown_wallLength.Visible = false;
            numericUpDown_wallWidth.Visible = false;
            comboBox_wallMaterial.Visible = false;
            pictureBox1.Visible = false;
        }

        public void WallProperties()
        {
            label6.Text = "Název";
            label3.Visible = true;
            label4.Visible = true;
            label5.Visible = true;
            label7.Visible = true;
            numericUpDown_wallHeight.Visible = true;
            numericUpDown_wallLength.Visible = true;
            numericUpDown_wallWidth.Visible = true;
            comboBox_wallMaterial.Visible = true;
            pictureBox1.Visible = true;
        }

//Buttons, radibuttons
        //save wall info
        private void button_saveChanges_Click(object sender, EventArgs e)
        {
            if (_selectedWall >= 0)
            {
                listWalls[_selectedWall].name = textBox_wallName.Text;
                listWalls[_selectedWall].width = (int)numericUpDown_wallWidth.Value;
                listWalls[_selectedWall].material = comboBox_wallMaterial.SelectedIndex;
                listWalls[_selectedWall].height = (int)numericUpDown_wallHeight.Value;
                listBox_explorer.ExplorerForm1(comboBox_wallMaterial);
            }
            else if(_selectedLabel >= 0)
            {
                listLabels[_selectedLabel].text = textBox_wallName.Text;
                listBox_explorer.ExplorerForm1(comboBox_wallMaterial);
                pictureBox_canvas.Invalidate();
            }
        }

        //delete selected line
        private void button_delete_Click(object sender, EventArgs e)
        {
            if (_selectedWall >= 0)           
                listWalls.Remove(listWalls[_selectedWall]);
                           
            else if (_selectedLabel >= 0)
                listLabels.Remove(listLabels[_selectedLabel]);
                
            
            if(_selectedWall >= 0 || _selectedLabel >= 0)
            {
                _selectedWall = -1;
                _selectedLabel = -1;
                pictureBox_canvas.Invalidate();
                button_delete.Enabled = false;
                SetWallPropertiesToDefault();
                listBox_explorer.ExplorerForm1(comboBox_wallMaterial);
            }

        }

        //selected index in list of wall was changed
        private void listBox_explorer_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBox_explorer.SelectedItem == null)
                return;

            button_delete.Enabled = true;
            if (listBox_explorer.SelectedItem.ToString().Substring(0,6) == "Popis:")
            {
                _selectedWall = -1;
                _selectedLabel = listBox_explorer.SelectedIndex-listWalls.Count;
                radioButton_hand.Checked = true;
                LabelProperties();
            }
                
            else
            {
                _selectedLabel = -1;
                _selectedWall = listBox_explorer.SelectedIndex;
                WallProperties();
            }

            pictureBox_canvas.Invalidate();
            
        }

        //New wall is insterted with offset of 10 points of copied
        private void button_paste_Click(object sender, EventArgs e)
        {
            if(_copiedWall.name != null)
            {
                radioButton_hand.Checked = true;

                int offset = 10;
                int length = (int)Get.Distance(_copiedWall.startXY, _copiedWall.finishXY);

                Walls wall = new Walls();
                wall.name = _copiedWall.name + " (kopie)";
                wall.startXY.X = _copiedWall.startXY.X + offset * (_copiedWall.finishXY.Y - _copiedWall.startXY.Y) / length;
                wall.startXY.Y = _copiedWall.startXY.Y + offset * (_copiedWall.startXY.X - _copiedWall.finishXY.X) / length;
                wall.finishXY.X = _copiedWall.finishXY.X + offset * (_copiedWall.finishXY.Y - _copiedWall.startXY.Y) / length;
                wall.finishXY.Y = _copiedWall.finishXY.Y + offset * (_copiedWall.startXY.X - _copiedWall.finishXY.X) / length;
                wall.lenght = _copiedWall.lenght;
                wall.width = _copiedWall.width;
                wall.height = _copiedWall.height;
                wall.material = _copiedWall.material;
                listWalls.Add(wall);

                _selectedWall = listWalls.Count() - 1;
            }

            else if(_copiedLabel.text != null)
            {
                radioButton_hand.Checked = true;

                int offset = 15;

                Labels label = new Labels();
                label.id = listLabels.Count();
                label.text = _copiedLabel.text + "(kopie)";
                label.XY = _copiedLabel.XY;
                label.XY.Y -= offset;

                listLabels.Add(label);

                _selectedLabel = listWalls.Count() - 1;
            }

            listBox_explorer.ExplorerForm1(comboBox_wallMaterial);
            pictureBox_canvas.Invalidate();
        }

        private void button_copy_Click(object sender, EventArgs e)
        {
            if (_selectedWall >= 0)
            {
                _copiedWall = listWalls[_selectedWall];
                _copiedLabel = new Labels();
                button_paste.Enabled = true;
            }
            else if(_selectedLabel >= 0)
            {
                _copiedWall = new Walls();
                _copiedLabel = listLabels[_selectedLabel];
                button_paste.Enabled = true;
            }

        }

        private void ToolStripMenuItem_wallsExplorer_CheckedChanged(object sender, EventArgs e)
        {
            if (listBox_explorer.Visible)
                listBox_explorer.Visible = false;
            else
                listBox_explorer.Visible = true;
        }

        private void ToolStripMenuItem_wallsProperties_CheckedChanged(object sender, EventArgs e)
        {
            if (groupBox_properties.Visible)
                groupBox_properties.Visible = false;
            else
                groupBox_properties.Visible = true;
        }

        private void ToolStripMenuItem_dimLenghts_CheckedChanged(object sender, EventArgs e)
        {
            pictureBox_canvas.Invalidate();
        }

        private void ToolStripMenuItem_dimAngles_CheckedChanged(object sender, EventArgs e)
        {
            pictureBox_canvas.Invalidate();
        }

        private void comboBox_wallMaterial_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            string imageLocation = Environment.CurrentDirectory;
            imageLocation = imageLocation.Replace(@"bin\Debug", @"Materials\");

            if (comboBox_wallMaterial.SelectedIndex == 0 || comboBox_wallMaterial.SelectedIndex == 1)
                imageLocation = imageLocation + comboBox_wallMaterial.SelectedIndex.ToString() + ".png";
            else
                imageLocation = imageLocation + comboBox_wallMaterial.SelectedIndex.ToString() + ".jpg";

            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.ImageLocation = imageLocation;      
        }

        private void button_openWall_Click(object sender, EventArgs e)
        {
            Form2 frm = new Form2(_selectedWall);
            frm.Owner = this;
            frm.Show();

        }

        private void radioButton_wall_CheckedChanged(object sender, EventArgs e)
        {
            _selectedWall = -1;
            _selectedLabel = -1;
            pictureBox_canvas.Invalidate();
        }

        //button "uložit jako"
        private void uložitJakoToolStripMenuItem_Click(object sender, EventArgs e)
        {

            SaveFileDialog saveFileDialog1 = new SaveFileDialog();
            saveFileDialog1.DefaultExt = ".xml";
            saveFileDialog1.Filter = "Soubor xml | *.xml";
            saveFileDialog1.Title = "Uložení konfigurace";
            saveFileDialog1.ShowDialog();
            if (saveFileDialog1.FileName != "")
            {
                System.IO.FileStream fs = (System.IO.FileStream)saveFileDialog1.OpenFile();

                Save save = new Save();
                save.listWalls = listWalls;
                save.listWallLabels = listWallLabels;
                save.listLabels = listLabels;
                save.listWindows = listWindows;
                save.listDoors = listDoors;
                save.listCables = listCables;
                save.listElectricalBoxes = listElectricalBoxes;
                save.listSockets = listSockets;
                save.listSwitches = listSwitches;
                save.listGasPipes = listGasPipes;
                save.listGasTapes = listGasTapes;
                save.listWaterPipes = listWaterPipes;
                save.listWaterTapes = listWaterTapes;
                save.listDimensions = listDimensions;

                //writing all lists to xml file
                new XmlSerializer(typeof(Save)).Serialize(fs, save);

                label_saved.Visible = true;
                timer1.Start();

                // Close the file
                fs.Close();
            }               
        }

        //button "nahrát"
        private void nahrátToolStripMenuItem_Click(object sender, EventArgs e)
        {        
            OpenFileDialog openFileDialog1 = new OpenFileDialog();
            openFileDialog1.DefaultExt = ".xml";
            openFileDialog1.Filter = "Soubor xml | *.xml";
            openFileDialog1.Title = "Otevření konfigurace";
            openFileDialog1.ShowDialog();
            if (openFileDialog1.FileName != "")
            {
                resetAll();
                XmlSerializer ser = new XmlSerializer(typeof(Save), new XmlRootAttribute("Save"));           

                FileStream fs = (FileStream)openFileDialog1.OpenFile();

                Save save = new Save();

                save = (Save)ser.Deserialize(fs);

                listWalls = save.listWalls;
                listLabels = save.listLabels;
                listWallLabels = save.listWallLabels;
                listWindows = save.listWindows;
                listDoors = save.listDoors;
                listCables = save.listCables;
                listElectricalBoxes = save.listElectricalBoxes;
                listSockets = save.listSockets;
                listSwitches = save.listSwitches;
                listGasPipes = save.listGasPipes;
                listGasTapes = save.listGasTapes;
                listWaterPipes = save.listWaterPipes;
                listWaterTapes = save.listWaterTapes;
                listDimensions = save.listDimensions;

                _labelCounter = listLabels.Count();
                fs.Close();
            }
            pictureBox_canvas.Invalidate();
            listBox_explorer.ExplorerForm1(comboBox_wallMaterial);
        }
        
        private void novýToolStripMenuItem_Click(object sender, EventArgs e)
        {
            resetAll();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (_timeToHide == 0)
            {
                timer1.Stop();
                _timeToHide = 5;
                label_saved.Visible = false;
            }
            else
                _timeToHide--;
        }

//Drawing
        private void pictureBox_canvas_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            Pen pen = new Pen(Color.Black);
            //Drawing all already created walls

            int idx = 0;
            foreach (Walls wall in listWalls)
            {
                if (_mouseOnWall == idx)
                    pen.Color = Color.Red;
                else
                    pen.Color = Color.Black;

                pen.Width = 2;

                g.DrawLine(pen, wall.startXY, wall.finishXY);
               
                //hide original dimension if user customize wall
                if(_allowDim == false || _selectedWall < 0 || wall != listWalls[_selectedWall])
                {
                    //if "show length dimensions" checked
                    if (ToolStripMenuItem_dimLenghts.Checked)
                        Draw.Dimension(wall.startXY, wall.finishXY, wall.lenght, g);
                    
                    //if "show angle dimensions" checked
                    if (ToolStripMenuItem_dimAngles.Checked)
                        Draw.DimAngle(wall.startXY, wall.finishXY, g);
                }


                idx++;
            }

            //Drawing all already created labels
            foreach (Labels label in listLabels)
            {
                //hightline selected label
                if (_selectedLabel >= 0 && label.id == listLabels[_selectedLabel].id)
                {
                    Draw.Label(label.XY, label.text, g, Color.Red);
                }
                else    
                    Draw.Label(label.XY, label.text, g, Color.Black);
            }                       
                
            //Drawing new wall in real time
            if(_isMouseDown && radioButton_wall.Checked)
            {
                if (_allowDim)
                {
                    Draw.Dimension(_ptFrom, _ptTo, Get.Distance(_ptFrom, _ptTo), g);
                    Draw.DimAngle(_ptFrom, _ptTo, g);
                }      
                g.DrawLine(Pens.Black, _ptFrom, _ptTo);
            }


            //Wall/label selecting
            if (radioButton_hand.Checked)
            {
                //Drawing moving wall in real time
                if (_isMouseDown && _selectedWall >= 0)
                {
                    if (_allowDim)
                    {
                        Draw.Dimension(_newPt1, _newPt2, Get.Distance(_newPt1, _newPt2), g);
                        Draw.DimAngle(_newPt1, _newPt2, g);
                    }
                    g.DrawLine(Pens.Black, _newPt1, _newPt2);
                }

                //Drawing moving label in real time
                if (_isMouseDown && _selectedLabel >= 0)
                {
                    Draw.Label(_newPt1, listLabels[_selectedLabel].text, g, Color.Black);                   
                }    
                    
            }

            // Draw circles on the begin and end of selected wall
            if (_selectedWall >= 0)
            {
                g.DrawEllipse(Pens.Blue, listWalls[_selectedWall].startXY.X - 5, listWalls[_selectedWall].startXY.Y - 5, 10, 10);
                g.DrawEllipse(Pens.Blue, listWalls[_selectedWall].finishXY.X - 5, listWalls[_selectedWall].finishXY.Y - 5, 10, 10);
            }


               

        }

    }
}
