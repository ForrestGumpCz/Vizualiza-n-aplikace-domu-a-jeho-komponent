﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace VisualizationApp
{
    public static class Get
    {
        public static string SelectedObjectType()
        {
            if (Form2._selectedWindow >= 0)
                return "window";

            else if (Form2._selectedDoor >= 0)
                return "door";

            else if (Form2._selectedCable >= 0)
                return "cable";

            else if (Form2._selectedElectricalBox >= 0)
                return "box";

            else if (Form2._selectedSocket >= 0)
                return "socket";

            else if (Form2._selectedSwitch >= 0)
                return "switch";

            else if (Form2._selectedGasPipe >= 0)
                return "gas_pipe";

            else if (Form2._selectedGasTap >= 0)
                return "gas_tap";

            else if (Form2._selectedWaterPipe >= 0)
                return "water_pipe";

            else if (Form2._selectedWaterTap >= 0)
                return "water_tap";
            else if (Form2._selectedLabel >= 0)
                return "label";

            return "none";
        }

        public static int SelectedObjectId()
        {
            if (Form2._selectedWindow >= 0)
                return Form2._selectedWindow;

            else if (Form2._selectedDoor >= 0)
                return Form2._selectedDoor;

            else if (Form2._selectedCable >= 0)
                return Form2._selectedCable;

            else if (Form2._selectedElectricalBox >= 0)
                return Form2._selectedElectricalBox;

            else if (Form2._selectedSocket >= 0)
                return Form2._selectedSocket;

            else if (Form2._selectedSwitch >= 0)
                return Form2._selectedSwitch;

            else if (Form2._selectedGasPipe >= 0)
                return Form2._selectedGasPipe;

            else if (Form2._selectedGasTap >= 0)
                return Form2._selectedGasTap;

            else if (Form2._selectedWaterPipe >= 0)
                return Form2._selectedWaterPipe;

            else if (Form2._selectedWaterTap >= 0)
                return Form2._selectedWaterTap;

            else if (Form2._selectedLabel >= 0)
                return Form2._selectedLabel;

            return -1;
        }

        public static int XOfObject(string type, int id)
        {
            if (type == "window")
                return Form1.listWindows[id].locationXY.X;

            else if (type == "door")
                return Form1.listDoors[id].locationXY.X;

            else if (type == "cable")
                return Form1.listCables[id].locationXY.X;

            else if (type == "box")
                return Form1.listElectricalBoxes[id].locationXY.X;

            else if (type == "socket")
                return Form1.listSockets[id].locationXY.X;

            else if (type == "switch")
                return Form1.listSwitches[id].locationXY.X;

            else if (type == "gas_pipe")
                return Form1.listGasPipes[id].locationXY.X;

            else if (type == "gas_tap")
                return Form1.listGasTapes[id].locationXY.X;

            else if (type == "water_pipe")
                return Form1.listWaterPipes[id].locationXY.X;

            else if (type == "water_tap")
                return Form1.listWaterTapes[id].locationXY.X;

            return -1;
        }

        public static int YOfObject(string type, int id)
        {
            if (type == "window")
                return Form1.listWindows[id].locationXY.Y;

            else if (type == "door")
                return Form1.listDoors[id].locationXY.Y;

            else if (type == "cable")
                return Form1.listCables[id].locationXY.Y;

            else if (type == "box")
                return Form1.listElectricalBoxes[id].locationXY.Y;

            else if (type == "socket")
                return Form1.listSockets[id].locationXY.Y;

            else if (type == "switch")
                return Form1.listSwitches[id].locationXY.Y;

            else if (type == "gas_pipe")
                return Form1.listGasPipes[id].locationXY.Y;

            else if (type == "gas_tap")
                return Form1.listGasTapes[id].locationXY.Y;

            else if (type == "water_pipe")
                return Form1.listWaterPipes[id].locationXY.Y;

            else if (type == "water_tap")
                return Form1.listWaterTapes[id].locationXY.Y;

            return -1;
        }

        //returns X value of left side for selected object
        public static Point LeftSideLocationOfObject()
        {
            if (Form2._selectedWindow >= 0)
                return new Point(Form1.listWindows[Form2._selectedWindow].locationXY.X, Form1.listWindows[Form2._selectedWindow].locationXY.Y + Form1.listWindows[Form2._selectedWindow].height / 2);

            else if (Form2._selectedDoor >= 0)
                return new Point(Form1.listDoors[Form2._selectedDoor].locationXY.X, Form1.listDoors[Form2._selectedDoor].locationXY.Y + Form1.listDoors[Form2._selectedDoor].height / 2);

            else if (Form2._selectedCable >= 0)
                return new Point(Form1.listCables[Form2._selectedCable].locationXY.X, Form1.listCables[Form2._selectedCable].locationXY.Y + Form1.listCables[Form2._selectedCable].height / 2);

            else if (Form2._selectedElectricalBox >= 0)
                return new Point(Form1.listElectricalBoxes[Form2._selectedElectricalBox].locationXY.X, Form1.listElectricalBoxes[Form2._selectedElectricalBox].locationXY.Y + Form1.listElectricalBoxes[Form2._selectedElectricalBox].height / 2);

            else if (Form2._selectedSocket >= 0)
                return new Point(Form1.listSockets[Form2._selectedSocket].locationXY.X, Form1.listSockets[Form2._selectedSocket].locationXY.Y + Form1.listSockets[Form2._selectedSocket].height / 2);

            else if (Form2._selectedSwitch >= 0)
                return new Point(Form1.listSwitches[Form2._selectedSwitch].locationXY.X, Form1.listSwitches[Form2._selectedSwitch].locationXY.Y + Form1.listSwitches[Form2._selectedSwitch].height / 2);

            else if (Form2._selectedGasPipe >= 0)
                return new Point(Form1.listGasPipes[Form2._selectedGasPipe].locationXY.X, Form1.listGasPipes[Form2._selectedGasPipe].locationXY.Y + Form1.listGasPipes[Form2._selectedGasPipe].height / 2);

            else if (Form2._selectedGasTap >= 0)
                return new Point(Form1.listGasTapes[Form2._selectedGasTap].locationXY.X, Form1.listGasTapes[Form2._selectedGasTap].locationXY.Y + Form1.listGasTapes[Form2._selectedGasTap].height / 2);

            else if (Form2._selectedWaterPipe >= 0)
                return new Point(Form1.listWaterPipes[Form2._selectedWaterPipe].locationXY.X, Form1.listWaterPipes[Form2._selectedWaterPipe].locationXY.Y + Form1.listWaterPipes[Form2._selectedWaterPipe].height / 2);

            else if (Form2._selectedWaterTap >= 0)
                return new Point(Form1.listWaterTapes[Form2._selectedWaterTap].locationXY.X, Form1.listWaterTapes[Form2._selectedWaterTap].locationXY.Y + Form1.listWaterTapes[Form2._selectedWaterTap].height / 2);

            return new Point(-1, -1);
        }

        //returns Y value of up side for selected object
        public static Point UpSideLocationOfObject()
        {
            if (Form2._selectedWindow >= 0)
                return new Point(Form1.listWindows[Form2._selectedWindow].locationXY.X + Form1.listWindows[Form2._selectedWindow].width / 2, Form1.listWindows[Form2._selectedWindow].locationXY.Y);

            else if (Form2._selectedDoor >= 0)
                return new Point(Form1.listDoors[Form2._selectedDoor].locationXY.X + Form1.listDoors[Form2._selectedDoor].width / 2, Form1.listDoors[Form2._selectedDoor].locationXY.Y);

            else if (Form2._selectedCable >= 0)
                return new Point(Form1.listCables[Form2._selectedCable].locationXY.X + Form1.listCables[Form2._selectedCable].width / 2, Form1.listCables[Form2._selectedCable].locationXY.Y);

            else if (Form2._selectedElectricalBox >= 0)
                return new Point(Form1.listElectricalBoxes[Form2._selectedElectricalBox].locationXY.X + Form1.listElectricalBoxes[Form2._selectedElectricalBox].width / 2, Form1.listElectricalBoxes[Form2._selectedElectricalBox].locationXY.Y);

            else if (Form2._selectedSocket >= 0)
                return new Point(Form1.listSockets[Form2._selectedSocket].locationXY.X + Form1.listSockets[Form2._selectedSocket].width / 2, Form1.listSockets[Form2._selectedSocket].locationXY.Y);

            else if (Form2._selectedSwitch >= 0)
                return new Point(Form1.listSwitches[Form2._selectedSwitch].locationXY.X + Form1.listSwitches[Form2._selectedSwitch].width / 2, Form1.listSwitches[Form2._selectedSwitch].locationXY.Y);

            else if (Form2._selectedGasPipe >= 0)
                return new Point(Form1.listGasPipes[Form2._selectedGasPipe].locationXY.X + Form1.listGasPipes[Form2._selectedGasPipe].width / 2, Form1.listGasPipes[Form2._selectedGasPipe].locationXY.Y);

            else if (Form2._selectedGasTap >= 0)
                return new Point(Form1.listGasTapes[Form2._selectedGasTap].locationXY.X + Form1.listGasTapes[Form2._selectedGasTap].width / 2, Form1.listGasTapes[Form2._selectedGasTap].locationXY.Y);

            else if (Form2._selectedWaterPipe >= 0)
                return new Point(Form1.listWaterPipes[Form2._selectedWaterPipe].locationXY.X + Form1.listWaterPipes[Form2._selectedWaterPipe].width / 2, Form1.listWaterPipes[Form2._selectedWaterPipe].locationXY.Y);

            else if (Form2._selectedWaterTap >= 0)
                return new Point(Form1.listWaterTapes[Form2._selectedWaterTap].locationXY.X + Form1.listWaterTapes[Form2._selectedWaterTap].width / 2, Form1.listWaterTapes[Form2._selectedWaterTap].locationXY.Y);

            return new Point(-1, -1);
        }

        //returns X value of right side for selected object
        public static Point RightSideLocationOfObject()
        {
            if (Form2._selectedWindow >= 0)
                return new Point(Form1.listWindows[Form2._selectedWindow].locationXY.X + Form1.listWindows[Form2._selectedWindow].width * Form2._zoom, Form1.listWindows[Form2._selectedWindow].locationXY.Y + Form1.listWindows[Form2._selectedWindow].height / 2);

            else if (Form2._selectedDoor >= 0)
                return new Point(Form1.listDoors[Form2._selectedDoor].locationXY.X + Form1.listDoors[Form2._selectedDoor].width * Form2._zoom, Form1.listDoors[Form2._selectedDoor].locationXY.Y + Form1.listDoors[Form2._selectedDoor].height / 2);

            else if (Form2._selectedCable >= 0)
                return new Point(Form1.listCables[Form2._selectedCable].locationXY.X + Form1.listCables[Form2._selectedCable].width * Form2._zoom, Form1.listCables[Form2._selectedCable].locationXY.Y + Form1.listCables[Form2._selectedCable].height / 2);

            else if (Form2._selectedElectricalBox >= 0)
                return new Point(Form1.listElectricalBoxes[Form2._selectedElectricalBox].locationXY.X + Form1.listElectricalBoxes[Form2._selectedElectricalBox].width * Form2._zoom, Form1.listElectricalBoxes[Form2._selectedElectricalBox].locationXY.Y + Form1.listElectricalBoxes[Form2._selectedElectricalBox].height / 2);

            else if (Form2._selectedSocket >= 0)
                return new Point(Form1.listSockets[Form2._selectedSocket].locationXY.X + Form1.listSockets[Form2._selectedSocket].width * Form2._zoom, Form1.listSockets[Form2._selectedSocket].locationXY.Y + Form1.listSockets[Form2._selectedSocket].height / 2);

            else if (Form2._selectedSwitch >= 0)
                return new Point(Form1.listSwitches[Form2._selectedSwitch].locationXY.X + Form1.listSwitches[Form2._selectedSwitch].width * Form2._zoom, Form1.listSwitches[Form2._selectedSwitch].locationXY.Y + Form1.listSwitches[Form2._selectedSwitch].height / 2);

            else if (Form2._selectedGasPipe >= 0)
                return new Point(Form1.listGasPipes[Form2._selectedGasPipe].locationXY.X + Form1.listGasPipes[Form2._selectedGasPipe].width * Form2._zoom, Form1.listGasPipes[Form2._selectedGasPipe].locationXY.Y + Form1.listGasPipes[Form2._selectedGasPipe].height / 2);

            else if (Form2._selectedGasTap >= 0)
                return new Point(Form1.listGasTapes[Form2._selectedGasTap].locationXY.X + Form1.listGasTapes[Form2._selectedGasTap].width * Form2._zoom, Form1.listGasTapes[Form2._selectedGasTap].locationXY.Y + Form1.listGasTapes[Form2._selectedGasTap].height / 2);

            else if (Form2._selectedWaterPipe >= 0)
                return new Point(Form1.listWaterPipes[Form2._selectedWaterPipe].locationXY.X + Form1.listWaterPipes[Form2._selectedWaterPipe].width * Form2._zoom, Form1.listWaterPipes[Form2._selectedWaterPipe].locationXY.Y + Form1.listWaterPipes[Form2._selectedWaterPipe].height / 2);

            else if (Form2._selectedWaterTap >= 0)
                return new Point(Form1.listWaterTapes[Form2._selectedWaterTap].locationXY.X + Form1.listWaterTapes[Form2._selectedWaterTap].width * Form2._zoom, Form1.listWaterTapes[Form2._selectedWaterTap].locationXY.Y + Form1.listWaterTapes[Form2._selectedWaterTap].height / 2);

            return new Point(-1, -1);
        }

        public static Point DownSideLocationOfObject()
        {
            if (Form2._selectedWindow >= 0)
                return new Point(Form1.listWindows[Form2._selectedWindow].locationXY.X + Form1.listWindows[Form2._selectedWindow].width / 2, Form1.listWindows[Form2._selectedWindow].locationXY.Y + Form1.listWindows[Form2._selectedWindow].height * Form2._zoom);

            else if (Form2._selectedDoor >= 0)
                return new Point(Form1.listDoors[Form2._selectedDoor].locationXY.X + Form1.listDoors[Form2._selectedDoor].width / 2, Form1.listDoors[Form2._selectedDoor].locationXY.Y + Form1.listDoors[Form2._selectedDoor].height * Form2._zoom);

            else if (Form2._selectedCable >= 0)
                return new Point(Form1.listCables[Form2._selectedCable].locationXY.X + Form1.listCables[Form2._selectedCable].width / 2, Form1.listCables[Form2._selectedCable].locationXY.Y + Form1.listCables[Form2._selectedCable].height * Form2._zoom);

            else if (Form2._selectedElectricalBox >= 0)
                return new Point(Form1.listElectricalBoxes[Form2._selectedElectricalBox].locationXY.X + Form1.listElectricalBoxes[Form2._selectedElectricalBox].width / 2, Form1.listElectricalBoxes[Form2._selectedElectricalBox].locationXY.Y + Form1.listElectricalBoxes[Form2._selectedElectricalBox].height * Form2._zoom);

            else if (Form2._selectedSocket >= 0)
                return new Point(Form1.listSockets[Form2._selectedSocket].locationXY.X + Form1.listSockets[Form2._selectedSocket].width / 2, Form1.listSockets[Form2._selectedSocket].locationXY.Y + Form1.listSockets[Form2._selectedSocket].height * Form2._zoom);

            else if (Form2._selectedSwitch >= 0)
                return new Point(Form1.listSwitches[Form2._selectedSwitch].locationXY.X + Form1.listSwitches[Form2._selectedSwitch].width / 2, Form1.listSwitches[Form2._selectedSwitch].locationXY.Y + Form1.listSwitches[Form2._selectedSwitch].height * Form2._zoom);

            else if (Form2._selectedGasPipe >= 0)
                return new Point(Form1.listGasPipes[Form2._selectedGasPipe].locationXY.X + Form1.listGasPipes[Form2._selectedGasPipe].width / 2, Form1.listGasPipes[Form2._selectedGasPipe].locationXY.Y + Form1.listGasPipes[Form2._selectedGasPipe].height * Form2._zoom);

            else if (Form2._selectedGasTap >= 0)
                return new Point(Form1.listGasTapes[Form2._selectedGasTap].locationXY.X + Form1.listGasTapes[Form2._selectedGasTap].width / 2, Form1.listGasTapes[Form2._selectedGasTap].locationXY.Y + Form1.listGasTapes[Form2._selectedGasTap].height * Form2._zoom);

            else if (Form2._selectedWaterPipe >= 0)
                return new Point(Form1.listWaterPipes[Form2._selectedWaterPipe].locationXY.X + Form1.listWaterPipes[Form2._selectedWaterPipe].width / 2, Form1.listWaterPipes[Form2._selectedWaterPipe].locationXY.Y + Form1.listWaterPipes[Form2._selectedWaterPipe].height * Form2._zoom);

            else if (Form2._selectedWaterTap >= 0)
                return new Point(Form1.listWaterTapes[Form2._selectedWaterTap].locationXY.X + Form1.listWaterTapes[Form2._selectedWaterTap].width / 2, Form1.listWaterTapes[Form2._selectedWaterTap].locationXY.Y + Form1.listWaterTapes[Form2._selectedWaterTap].height * Form2._zoom);

            return new Point(-1, -1);
        }

        //find dimension record for selected object
        public static Form1.objectDimension GetDim(int obj_id, string obj_type, string dim_type)
        {

            foreach (Form1.objectDimension dim in Form1.listDimensions)
            {
                if (dim.wallId == Form2._selectedWall && dim.wallSide == Form2._wallSide && dim.objectType == obj_type && dim.idObject == obj_id && dim.dimType == dim_type)
                    return dim;
            }
            return new Form1.objectDimension();
        }
        //returns count of entities by type for opened wall
        public static int TrueCount(string type)
        {
            int count = 0;
            if (type == "window")
            {
                foreach (Form1.objectEntity window in Form1.listWindows)
                {
                    if (window.wallId == Form2._selectedWall && window.wallSide == Form2._wallSide)
                        count++;
                }
                return count;
            }
            else if (type == "door")
            {
                foreach (Form1.objectEntity door in Form1.listDoors)
                {
                    if (door.wallId == Form2._selectedWall && door.wallSide == Form2._wallSide)
                        count++;
                }
                return count;
            }
            else if (type == "cable")
            {
                foreach (Form1.objectCableEntity cable in Form1.listCables)
                {
                    if (cable.wallId == Form2._selectedWall && cable.wallSide == Form2._wallSide)
                        count++;
                }
                return count;
            }
            else if (type == "box")
            {
                foreach (Form1.objectEntity box in Form1.listElectricalBoxes)
                {
                    if (box.wallId == Form2._selectedWall && box.wallSide == Form2._wallSide)
                        count++;
                }
                return count;
            }
            else if (type == "socket")
            {
                foreach (Form1.objectEntity socket in Form1.listSockets)
                {
                    if (socket.wallId == Form2._selectedWall && socket.wallSide == Form2._wallSide)
                        count++;
                }
                return count;
            }
            else if (type == "switch")
            {
                foreach (Form1.objectEntity sw in Form1.listSwitches)
                {
                    if (sw.wallId == Form2._selectedWall && sw.wallSide == Form2._wallSide)
                        count++;
                }
                return count;
            }
            else if (type == "gas_pipe")
            {
                foreach (Form1.objectPipeEntity g_pipe in Form1.listGasPipes)
                {
                    if (g_pipe.wallId == Form2._selectedWall && g_pipe.wallSide == Form2._wallSide)
                        count++;
                }
                return count;
            }
            else if (type == "gas_tap")
            {
                foreach (Form1.objectTapEntity tap in Form1.listGasTapes)
                {
                    if (tap.wallId == Form2._selectedWall && tap.wallSide == Form2._wallSide)
                        count++;
                }
                return count;
            }
            else if (type == "water_pipe")
            {
                foreach (Form1.objectPipeEntity pipe in Form1.listWaterPipes)
                {
                    if (pipe.wallId == Form2._selectedWall && pipe.wallSide == Form2._wallSide)
                        count++;
                }
                return count;
            }
            else if (type == "water_tap")
            {
                foreach (Form1.objectTapEntity tap in Form1.listWaterTapes)
                {
                    if (tap.wallId == Form2._selectedWall && tap.wallSide == Form2._wallSide)
                        count++;
                }
                return count;
            }
            else if (type == "label")
            {
                foreach (Form1.WallLabels label in Form1.listWallLabels)
                {
                    if (label.wallId == Form2._selectedWall && label.wallSide == Form2._wallSide)
                        count++;
                }
                return count;
            }
            return -1;
        }

        //returns index if entity in list for selected item in explorer
        public static int IndexFromExplorer(string str)
        {
            if (str.Length == 0)
                return -1;

            string res = "";
            char c;
            for (int i = 0; i < str.Length; i++)
            {
                c = str[i];
                if (c == ':')
                    break;
                else
                    res = res + c;

            }
            return Int32.Parse(res);
        }

        //find first match in explorer by searchString
        public static int ExplorerIndex(this System.Windows.Forms.ListBox explorer, string searchString, int id)
        {
            int d = 0;
            foreach (string explorerItem in explorer.Items)
                if (explorerItem.Contains(searchString) && id == Get.IndexFromExplorer(explorerItem))
                    return d;
                else
                    d++;
            return 0;
        }

        // X offset for socket
        public static int OffsetX()
        {
            return -5 + Form2._zoom * 3;
        }

        //Find index of wall by actual mouse position
        //!!! it find only first match, not all
        public static int IndexOfWall(System.Windows.Forms.MouseEventArgs e)
        {
            int i = 0;
            Point mouseLocation = e.Location;
            List<Point> pixs = new List<Point>();

            foreach (Form1.Walls wall in Form1.listWalls)
            {
                Form1._resizing = 0;
                if (Form1._alreadySelected)
                    Form1._resizing = EntityDetection.StartEndPointDetection(e, i);
                if (Form1._resizing > 0)
                    return i;
                pixs.Clear();
                pixs = Pixels(wall.startXY, wall.finishXY);
                foreach (Point pix in pixs)
                    //single pixel tolerance from mouse location
                    if (EntityDetection.MouseProximityDetection(pix, mouseLocation, 1, 1))
                        return i;

                i++;
            }
            return -1;
        }

        //Bresenham algorithm for counting all pixels of line
        public static List<Point> Pixels(Point _ptFrom, Point _ptTo)
        {
            List<Point> pixels = new List<Point>();
            int w = _ptTo.X - _ptFrom.X;
            int h = _ptTo.Y - _ptFrom.Y;
            int dx1 = 0, dy1 = 0, dx2 = 0, dy2 = 0;
            if (w < 0) dx1 = -1; else if (w > 0) dx1 = 1;
            if (h < 0) dy1 = -1; else if (h > 0) dy1 = 1;
            if (w < 0) dx2 = -1; else if (w > 0) dx2 = 1;
            int longest = Math.Abs(w);
            int shortest = Math.Abs(h);
            if (!(longest > shortest))
            {
                longest = Math.Abs(h);
                shortest = Math.Abs(w);
                if (h < 0) dy2 = -1; else if (h > 0) dy2 = 1;
                dx2 = 0;
            }
            int numerator = longest >> 1;
            Point pt = _ptFrom;
            for (int i = 0; i <= longest; i++)
            {
                pixels.Add(pt);
                numerator += shortest;
                if (!(numerator < longest))
                {
                    numerator -= longest;
                    pt.X += dx1;
                    pt.Y += dy1;
                }
                else
                {
                    pt.X += dx2;
                    pt.Y += dy2;
                }
            }
            return pixels;
        }


        //result is distance between two points
        public static int Distance(Point from, Point to)
        {
            return (int)Math.Sqrt(Math.Pow((to.Y - from.Y), 2) + Math.Pow((to.X - from.X), 2));
        }

        public static Point MidPoint(Point p1, Point p2, int offset)
        {
            return new Point(offset + (p1.X + p2.X) / 2, offset + (p1.Y + p2.Y) / 2);
        }

        //Get angle of two points
        public static float Angle(Point p1, Point p2)
        {
            float deltaX = p2.X - p1.X;
            float deltaY = p2.Y - p1.Y;
            return (float)(Math.Atan2(deltaY, deltaX) * 180.0 / Math.PI);
        }

    }
}
