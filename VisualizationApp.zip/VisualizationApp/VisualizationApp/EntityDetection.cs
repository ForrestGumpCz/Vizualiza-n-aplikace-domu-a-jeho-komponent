﻿using System.Drawing;
using System.Linq;
using System;

namespace VisualizationApp
{
    public class EntityDetection
    {
        //if is mous in rectangle returns true
        private static bool IsMouseInRectangle(Point mouseLocation, Point startXY, int width, int height)
        {
            if (mouseLocation.X >= startXY.X && mouseLocation.X <= startXY.X + width)
                if (mouseLocation.Y >= startXY.Y && mouseLocation.Y <= startXY.Y + height)
                    return true;

            return false;
        }

        //when is object width higher than 1, it's detected as horizontal
        public static bool IsHorizontal(int width)
        {
            if (width > 1)
                return true;
            else
                return false;
        }

        //Mouse hover object detection methods
        public static int MouseInAnyWindow(Point mouseLocation)
        {
            int i = 0;
            foreach (Form1.objectEntity window in Form1.listWindows)
            {
                if (window.wallId == Form2._selectedWall && window.wallSide == Form2._wallSide)
                    if (IsMouseInRectangle(mouseLocation, window.locationXY, window.width * Form2._zoom, window.height * Form2._zoom))
                        return i;
                    else
                        i++;
                else
                    i++;
            }
            return -1;
        }

        public static int MouseInAnyDoor(Point mouseLocation)
        {
            int i = 0;
            foreach (Form1.objectEntity door in Form1.listDoors)
            {
                if (door.wallId == Form2._selectedWall && door.wallSide == Form2._wallSide)
                    if (IsMouseInRectangle(mouseLocation, door.locationXY, door.width * Form2._zoom, door.height * Form2._zoom))
                        return i;
                    else
                        i++;
                else
                    i++;
            }
            return -1;
        }

        public static int MouseInAnyCable(Point mouseLocation)
        {
            int i = 0;
            foreach (Form1.objectCableEntity cable in Form1.listCables)
            {
                if (cable.wallId == Form2._selectedWall && cable.wallSide == Form2._wallSide)
                    if (IsHorizontal(cable.width))
                        if (IsMouseInRectangle(mouseLocation, cable.locationXY, cable.width * Form2._zoom, cable.height))
                            return i;
                        else
                            i++;
                    else
                         if (IsMouseInRectangle(mouseLocation, cable.locationXY, cable.width, cable.height * Form2._zoom))
                        return i;
                    else
                        i++;
                else
                    i++;
            }
            return -1;
        }

        public static int MouseInAnyElectricalBox(Point mouseLocation)
        {
            int i = 0;
            foreach (Form1.objectEntity box in Form1.listElectricalBoxes)
            {
                if (box.wallId == Form2._selectedWall && box.wallSide == Form2._wallSide)
                    if (IsMouseInRectangle(mouseLocation, new Point(box.locationXY.X - box.width / 2 + 4, box.locationXY.Y - box.height / 2 + 4), box.width * Form2._zoom, box.height * Form2._zoom))
                        return i;
                    else
                        i++;
                else
                    i++;
            }
            return -1;
        }

        public static int MouseInAnySocket(Point mouseLocation)
        {
            int i = 0;
            foreach (Form1.objectEntity socket in Form1.listSockets)
            {
                if (socket.wallId == Form2._selectedWall && socket.wallSide == Form2._wallSide)
                    if (IsMouseInRectangle(mouseLocation, socket.locationXY, socket.width * Form2._zoom, socket.height * Form2._zoom))
                        return i;
                    else
                        i++;
                else
                    i++;
            }
            return -1;
        }

        public static int MouseInAnySwitch(Point mouseLocation)
        {
            int i = 0;
            foreach (Form1.objectEntity obj_switch in Form1.listSwitches)
            {
                if (obj_switch.wallId == Form2._selectedWall && obj_switch.wallSide == Form2._wallSide)
                    if (IsMouseInRectangle(mouseLocation, obj_switch.locationXY, obj_switch.width * Form2._zoom, obj_switch.height * Form2._zoom))
                        return i;
                    else
                        i++;
                else
                    i++;
            }
            return -1;
        }

        public static int MouseInAnyGasPipe(Point mouseLocation)
        {
            int i = 0;
            foreach (Form1.objectPipeEntity pipe in Form1.listGasPipes)
            {
                if (pipe.wallId == Form2._selectedWall && pipe.wallSide == Form2._wallSide)
                    if (IsHorizontal(pipe.width))
                        if (IsMouseInRectangle(mouseLocation, pipe.locationXY, pipe.width * Form2._zoom, pipe.height))
                            return i;
                        else
                            i++;
                    else
                         if (IsMouseInRectangle(mouseLocation, pipe.locationXY, pipe.width, pipe.height * Form2._zoom))
                        return i;
                    else
                        i++;
                else
                    i++;
            }
            return -1;
        }

        public static int MouseInAnyGasTap(Point mouseLocation)
        {
            int i = 0;
            foreach (Form1.objectTapEntity tap in Form1.listGasTapes)
            {
                if (tap.wallId == Form2._selectedWall && tap.wallSide == Form2._wallSide)
                    if (IsMouseInRectangle(mouseLocation, tap.locationXY, tap.width * Form2._zoom, tap.height * Form2._zoom))
                        return i;
                    else
                        i++;
                else
                    i++;
            }
            return -1;
        }

        public static int MouseInAnyWaterPipe(Point mouseLocation)
        {
            int i = 0;
            foreach (Form1.objectPipeEntity pipe in Form1.listWaterPipes)
            {
                if (pipe.wallId == Form2._selectedWall && pipe.wallSide == Form2._wallSide)
                    if (IsHorizontal(pipe.width))
                        if (IsMouseInRectangle(mouseLocation, pipe.locationXY, pipe.width * Form2._zoom, pipe.height))
                            return i;
                        else
                            i++;
                    else
                         if (IsMouseInRectangle(mouseLocation, pipe.locationXY, pipe.width, pipe.height * Form2._zoom))
                        return i;
                    else
                        i++;
                else
                    i++;
            }
            return -1;
        }

        public static int MouseInAnyWaterTap(Point mouseLocation)
        {
            int i = 0;
            foreach (Form1.objectTapEntity tap in Form1.listWaterTapes)
            {
                if (tap.wallId == Form2._selectedWall && tap.wallSide == Form2._wallSide)
                    if (IsMouseInRectangle(mouseLocation, tap.locationXY, tap.width * Form2._zoom, tap.height * Form2._zoom))
                        return i;
                    else
                        i++;
                else
                    i++;
            }
            return -1;
        }

        public static int MouseInAnyDimension(Point mouseLocation)
        {
            int i = 0;
            int width = 0;
            int height = 0;
            int tmp_dimX, tmp_dimY;
            foreach (Form1.objectDimension dim in Form1.listDimensions)
            {
                if (dim.wallId == Form2._selectedWall && dim.wallSide == Form2._wallSide)
                {
                    tmp_dimX = dim.startXY.X;
                    tmp_dimY = dim.startXY.Y;
                    if (dim.dimType == "left")
                    {
                        width = Get.XOfObject(dim.objectType, dim.idObject) - Form2._start_offsetX;
                        height = 10;
                        tmp_dimY = dim.startXY.Y - 10;

                    }
                    else if (dim.dimType == "up")
                    {
                        width = 10;
                        height = Get.YOfObject(dim.objectType, dim.idObject) - Form2._start_offsetY;
                        tmp_dimX = dim.startXY.X + 5;
                    }

                    else if (dim.dimType == "right")
                    {
                        width = Form2._openedWall.lenght * Form2._zoom - dim.startXY.X + Form2._start_offsetX;
                        height = 10;
                        tmp_dimY = dim.startXY.Y - 10;
                    }

                    else if (dim.dimType == "down")
                    {
                        width = 10;
                        height = Form2._openedWall.height * Form2._zoom - dim.startXY.Y + Form2._start_offsetY;
                        tmp_dimX = dim.startXY.X + 5;
                    }


                    if (IsMouseInRectangle(mouseLocation, new Point(tmp_dimX, tmp_dimY), width, height))
                    {
                        return i;
                    }

                    else
                        i++;
                }
                else
                    i++;
            }
            return -1;
        }

        public static int MouseInAnyLabel(Point mouseLocation)
        {
            int i = 0;
            foreach (Form1.WallLabels label in Form1.listWallLabels)
            {
                if (label.wallId == Form2._selectedWall && label.wallSide == Form2._wallSide)
                    if (IsMouseInRectangle(mouseLocation, label.XY, label.text.Length * 5 * Form2._zoom, 10 * Form2._zoom))
                        return i;
                    else
                        i++;
                else
                    i++;
            }
            return -1;
        }

        //return TRUE if mouse is inside Proximity of startPoint, else returns FALSE
        //proximity is formed by deltaX and deltaY
        public static bool MouseProximityDetection(Point startPoint, Point mouseLocation, int toleranceX, int toleranceY)
        {
            if (mouseLocation.X >= startPoint.X - toleranceX && mouseLocation.X <= startPoint.X + toleranceX)
                if (mouseLocation.Y >= startPoint.Y - toleranceY && mouseLocation.Y <= startPoint.Y + toleranceY)
                    return true;

            return false;
        }

        //returns 1 if start-point hover, 2 if end-point hover, 0 if no point hover
        public static int StartEndPointDetection(System.Windows.Forms.MouseEventArgs e, int idx)
        {
            Point mouseLocation = e.Location;
            if (MouseProximityDetection(Form1.listWalls[idx].startXY, mouseLocation, 5, 5)) //check if mouse is on start-point location
                return 1;

            else if (MouseProximityDetection(Form1.listWalls[idx].finishXY, mouseLocation, 5, 5))//check if mouse is on end-point location
                return 2;

            return 0;
        }

    }
}
