﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace VisualizationApp
{
    public class NewEntity
    {
        public static Form1.objectEntity Window()
        {
            Form1.objectEntity window = new Form1.objectEntity();
            window.name = "Okno č. " + Form1.listWindows.Count.ToString();
            window.wallId = Form2._selectedWall;
            window.wallSide = Form2._wallSide;
            window.width = Form2._openedWall.lenght / 5;
            window.height = Form2._openedWall.height / 5;
            window.locationXY = Zoom.RecalculDelta(new Point(50, 50), window.width, window.height);
            return window;
        }

        public static Form1.objectEntity Door()
        {
            Form1.objectEntity door = new Form1.objectEntity();
            door.name = "Dveře č. " + Form1.listDoors.Count.ToString();
            door.wallId = Form2._selectedWall;
            door.wallSide = Form2._wallSide;
            door.width = 80;    //defalut door width is 80 centimetres
            door.height = 180;   //defalut door height is 180 centimetres
            door.locationXY = Zoom.RecalculDelta(new Point(50, 50), door.width, door.height);
            return door;
        }

        public static Form1.objectCableEntity Cable()
        {
            Form1.objectCableEntity cable = new Form1.objectCableEntity();
            cable.name = "Kabel č. " + Form1.listCables.Count.ToString();
            cable.wallId = Form2._selectedWall;
            cable.wallSide = Form2._wallSide;
            cable.width = 100;
            cable.height = 1;
            cable.locationXY = Zoom.RecalculDelta(new Point(50, 50), cable.width, cable.height);
            cable.isolation = "CYKY";
            cable.diameter = "2,5";
            cable.num_of_wires = 3;
            cable.material_of_wires = "Měď";
            return cable;
        }

        public static Form1.objectEntity Box()
        {
            Form1.objectEntity box = new Form1.objectEntity();
            box.name = "El. krabice č. " + Form1.listElectricalBoxes.Count.ToString();
            box.wallId = Form2._selectedWall;
            box.wallSide = Form2._wallSide;
            box.width = 10;
            box.height = 10;
            box.locationXY = Zoom.RecalculDelta(new Point(50, 50), box.width, box.height);
            return box;
        }

        public static Form1.objectEntity Socket()
        {
            Form1.objectEntity socket = new Form1.objectEntity();
            socket.name = "Zásuvka č. " + Form1.listSockets.Count.ToString();
            socket.wallId = Form2._selectedWall;
            socket.wallSide = Form2._wallSide;
            socket.width = 10;
            socket.height = 14;
            socket.locationXY = Zoom.RecalculDelta(new Point(50, 50), socket.width, socket.height);
            return socket;
        }

        public static Form1.objectEntity Switch()
        {
            Form1.objectEntity obj_switch = new Form1.objectEntity();
            obj_switch.name = "Vypínač č. " + Form1.listSwitches.Count.ToString();
            obj_switch.wallId = Form2._selectedWall;
            obj_switch.wallSide = Form2._wallSide;
            obj_switch.width = 10;
            obj_switch.height = 10;
            obj_switch.locationXY = Zoom.RecalculDelta(new Point(50, 50), obj_switch.width, obj_switch.height);
            return obj_switch;
        }

        public static Form1.objectPipeEntity GasPipe()
        {
            Form1.objectPipeEntity pipe = new Form1.objectPipeEntity();
            pipe.name = "Plyn_potr. č. " + Form1.listGasPipes.Count.ToString();
            pipe.wallId = Form2._selectedWall;
            pipe.wallSide = Form2._wallSide;
            pipe.width = 100;
            pipe.height = 1;
            pipe.locationXY = Zoom.RecalculDelta(new Point(50, 50), pipe.width, pipe.height);
            pipe.diameter = "16";
            pipe.material = "Měď";
            return pipe;
        }

        public static Form1.objectTapEntity GasTap()
        {
            Form1.objectTapEntity tap = new Form1.objectTapEntity();
            tap.name = "Plynový kohout č. " + Form1.listGasTapes.Count.ToString();
            tap.wallId = Form2._selectedWall;
            tap.wallSide = Form2._wallSide;
            tap.width = 5;
            tap.height = 3;
            tap.locationXY = Zoom.RecalculDelta(new Point(50, 50), tap.width, tap.height);
            tap.diameter = "3/4";
            return tap;
        }

        public static Form1.objectPipeEntity WaterPipe()
        {
            Form1.objectPipeEntity pipe = new Form1.objectPipeEntity();
            pipe.name = "Vodovodní_potr. č. " + Form1.listWaterPipes.Count.ToString();
            pipe.wallId = Form2._selectedWall;
            pipe.wallSide = Form2._wallSide;
            pipe.width = 100;
            pipe.height = 1;
            pipe.locationXY = Zoom.RecalculDelta(new Point(50, 50), pipe.width, pipe.height);
            pipe.diameter = "16";
            pipe.material = "PVC";
            return pipe;
        }

        public static Form1.objectTapEntity WaterTap()
        {
            Form1.objectTapEntity tap = new Form1.objectTapEntity();
            tap.name = "Vodovodní kohout č. " + Form1.listWaterTapes.Count.ToString();
            tap.wallId = Form2._selectedWall;
            tap.wallSide = Form2._wallSide;
            tap.width = 5;
            tap.height = 3;
            tap.locationXY = Zoom.RecalculDelta(new Point(50, 50), tap.width, tap.height);
            tap.diameter = "1/2";
            return tap;
        }

        public static Form1.WallLabels Label()
        {
            Form1.WallLabels label = new Form1.WallLabels();
            label.id = Form1.listWallLabels.Count();
            label.text = "Zde napište text";
            label.wallId = Form2._selectedWall;
            label.wallSide = Form2._wallSide;
            label.XY = new Point(50, 50);
            return label;
        }

        //returns Walls item with default properties to save in list of walls 
        public static Form1.Walls Wall(Point startXY, Point endXY)
        {
            Form1.Walls wall = new Form1.Walls();
            wall.name = "stěna č. " + (Form1.listWalls.Count() + 1).ToString();
            wall.startXY = startXY;
            wall.finishXY = endXY;
            wall.lenght = Get.Distance(startXY, endXY);
            wall.width = 20;
            wall.height = 200;
            wall.material = 0;
            return wall;
        }

    }
}
