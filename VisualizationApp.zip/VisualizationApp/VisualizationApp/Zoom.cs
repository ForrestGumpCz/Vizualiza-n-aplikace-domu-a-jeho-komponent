﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace VisualizationApp
{
    public class Zoom
    {

        public static Point RecalculDelta(Point locationXY, int width, int height)
        {
            Form2._aX = locationXY.X - Form2._start_offsetX;
            Form2._bX = Form2._openedWall.lenght + Form2._start_offsetX - (locationXY.X + width);
            Form2._aY = locationXY.Y - Form2._start_offsetY;
            Form2._bY = Form2._openedWall.height + Form2._start_offsetY - (locationXY.Y + height);
            Form2._distX = Form2._openedWall.lenght - width;
            Form2._distY = Form2._openedWall.height - height;

            double deltaX = Form2._distX / (Form2._aX + Form2._bX);
            double deltaY = Form2._distY / (Form2._aY + Form2._bY);

            deltaX /= Form2._prevZoom;
            deltaY /= Form2._prevZoom;

            deltaX *= Form2._zoom;
            deltaY *= Form2._zoom;

            Point res = new Point(Form2._start_offsetX + (int)(deltaX * Form2._aX), Form2._start_offsetY + (int)(deltaY * Form2._aY));
            return res;
        }


        //recalculation positions for each created stuff placed on wall by actual Form2._zoom
        public static void NewLocationsForAllStuff()
        {

            //Window
            int tmp = Form2._selectedWindow;
            int id = 0;
            foreach (Form1.objectEntity window in Form1.listWindows)
            {
                if (window.wallId == Form2._selectedWall && window.wallSide == Form2._wallSide)
                {
                    window.locationXY = RecalculDelta(window.locationXY, window.width, window.height);
                    Form2._selectedWindow = id;
                    Actualize.RightDownDims();
                }
                id++;
            }
            Form2._selectedWindow = tmp;

            //door
            tmp = Form2._selectedDoor;
            id = 0;
            foreach (Form1.objectEntity door in Form1.listDoors)
            {
                if (door.wallId == Form2._selectedWall && door.wallSide == Form2._wallSide)
                {
                    door.locationXY = RecalculDelta(door.locationXY, door.width, door.height);
                    Form2._selectedDoor = id;
                    Actualize.RightDownDims();
                }
                id++;
            }
            Form2._selectedDoor = tmp;

            //cable
            tmp = Form2._selectedCable;
            id = 0;
            foreach (Form1.objectCableEntity cable in Form1.listCables)
            {
                if (cable.wallId == Form2._selectedWall && cable.wallSide == Form2._wallSide)
                {
                    cable.locationXY = RecalculDelta(cable.locationXY, cable.width, cable.height);
                    Form2._selectedCable = id;
                    Actualize.RightDownDims();
                }
                id++;
            }
            Form2._selectedCable = tmp;

            //electrical box
            tmp = Form2._selectedElectricalBox;
            id = 0;
            foreach (Form1.objectEntity box in Form1.listElectricalBoxes)
            {
                if (box.wallId == Form2._selectedWall && box.wallSide == Form2._wallSide)
                {
                    box.locationXY = RecalculDelta(box.locationXY, box.width, box.height);
                    Form2._selectedElectricalBox = id;
                    Actualize.RightDownDims();
                }
                id++;
            }
            Form2._selectedElectricalBox = tmp;

            //socket
            tmp = Form2._selectedSocket;
            id = 0;
            foreach (Form1.objectEntity socket in Form1.listSockets)
            {
                if (socket.wallId == Form2._selectedWall && socket.wallSide == Form2._wallSide)
                {
                    socket.locationXY = RecalculDelta(socket.locationXY, socket.width, socket.height);
                    Form2._selectedSocket = id;
                    Actualize.RightDownDims();
                }
                id++;
            }
            Form2._selectedSocket = tmp;

            //switch
            tmp = Form2._selectedSwitch;
            id = 0;
            foreach (Form1.objectEntity obj_switch in Form1.listSwitches)
            {
                if (obj_switch.wallId == Form2._selectedWall && obj_switch.wallSide == Form2._wallSide)
                {
                    obj_switch.locationXY = RecalculDelta(obj_switch.locationXY, obj_switch.width, obj_switch.height);
                    Form2._selectedSwitch = id;
                    Actualize.RightDownDims();
                }
                id++;
            }
            Form2._selectedSwitch = tmp;

            //gas pipe
            tmp = Form2._selectedGasPipe;
            id = 0;
            foreach (Form1.objectPipeEntity pipe in Form1.listGasPipes)
            {
                if (pipe.wallId == Form2._selectedWall && pipe.wallSide == Form2._wallSide)
                {
                    pipe.locationXY = RecalculDelta(pipe.locationXY, pipe.width, pipe.height);
                    Form2._selectedGasPipe = id;
                    Actualize.RightDownDims();
                }
                id++;
            }
            Form2._selectedGasPipe = tmp;

            //gas tap
            tmp = Form2._selectedGasTap;
            id = 0;
            foreach (Form1.objectTapEntity tap in Form1.listGasTapes)
            {
                if (tap.wallId == Form2._selectedWall && tap.wallSide == Form2._wallSide)
                {
                    tap.locationXY = RecalculDelta(tap.locationXY, tap.width, tap.height);
                    Form2._selectedGasTap = id;
                    Actualize.RightDownDims();
                }
                id++;
            }
            Form2._selectedGasTap = tmp;

            //water pipe
            tmp = Form2._selectedWaterPipe;
            id = 0;
            foreach (Form1.objectPipeEntity pipe in Form1.listWaterPipes)
            {
                if (pipe.wallId == Form2._selectedWall && pipe.wallSide == Form2._wallSide)
                {
                    pipe.locationXY = RecalculDelta(pipe.locationXY, pipe.width, pipe.height);
                    Form2._selectedWaterPipe = id;
                    Actualize.RightDownDims();
                }
                id++;
            }
            Form2._selectedWaterPipe = tmp;

            //water tap
            tmp = Form2._selectedWaterTap;
            id = 0;
            foreach (Form1.objectTapEntity tap in Form1.listWaterTapes)
            {
                if (tap.wallId == Form2._selectedWall && tap.wallSide == Form2._wallSide)
                {
                    tap.locationXY = RecalculDelta(tap.locationXY, tap.width, tap.height);
                    Form2._selectedWaterTap = id;
                    Actualize.RightDownDims();
                }
                id++;
            }
            Form2._selectedWaterTap = tmp;

            //label
            tmp = Form2._selectedLabel;
            id = 0;
            foreach (Form1.WallLabels label in Form1.listWallLabels)
            {
                if (label.wallId == Form2._selectedWall && label.wallSide == Form2._wallSide)
                {
                    label.XY = RecalculDelta(label.XY, label.text.Length * 5, 8);
                    Form2._selectedLabel = id;
                    Actualize.RightDownDims();
                }
                id++;
            }
            Form2._selectedLabel = tmp;

        }
    }
}
