﻿
namespace VisualizationApp
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.listBox_toolbox = new System.Windows.Forms.ListBox();
            this.pictureBox_canvas = new System.Windows.Forms.PictureBox();
            this.listBox_explorer = new System.Windows.Forms.ListBox();
            this.groupBox_properties = new System.Windows.Forms.GroupBox();
            this.button_turnObject = new System.Windows.Forms.Button();
            this.textBox_isolation = new System.Windows.Forms.TextBox();
            this.label_isolation = new System.Windows.Forms.Label();
            this.numericUpDown_numOfWires = new System.Windows.Forms.NumericUpDown();
            this.label_numOfWires = new System.Windows.Forms.Label();
            this.textBox_material = new System.Windows.Forms.TextBox();
            this.textBox_diameter = new System.Windows.Forms.TextBox();
            this.label_diameter = new System.Windows.Forms.Label();
            this.button_save = new System.Windows.Forms.Button();
            this.label_material = new System.Windows.Forms.Label();
            this.numericUpDown_width = new System.Windows.Forms.NumericUpDown();
            this.label_width = new System.Windows.Forms.Label();
            this.numericUpDown_height = new System.Windows.Forms.NumericUpDown();
            this.label_height = new System.Windows.Forms.Label();
            this.textBox_name = new System.Windows.Forms.TextBox();
            this.label_name = new System.Windows.Forms.Label();
            this.button_newObjectWindow = new System.Windows.Forms.Button();
            this.button_newObjectDoor = new System.Windows.Forms.Button();
            this.button_newObjectSwitch = new System.Windows.Forms.Button();
            this.button_newObjectSocket = new System.Windows.Forms.Button();
            this.button_newObjectCable = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.button_newObjectElectricalBox = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.button_newObjectGasPipe = new System.Windows.Forms.Button();
            this.button_newObjectGasTap = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.button_newObjectWaterPipe = new System.Windows.Forms.Button();
            this.button_newObjectWaterTap = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.button_turnWall = new System.Windows.Forms.Button();
            this.label_wallSide = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label_zoom = new System.Windows.Forms.Label();
            this.trackBar_zoom = new System.Windows.Forms.TrackBar();
            this.button_delete = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button_DownDim = new System.Windows.Forms.Button();
            this.button_UpDim = new System.Windows.Forms.Button();
            this.button_RightDim = new System.Windows.Forms.Button();
            this.button_LeftDim = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.button_newObjectLabel = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.button_MoveDown = new System.Windows.Forms.Button();
            this.button_MoveUp = new System.Windows.Forms.Button();
            this.button_MoveRight = new System.Windows.Forms.Button();
            this.button_MoveLeft = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_canvas)).BeginInit();
            this.groupBox_properties.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_numOfWires)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_width)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_height)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_zoom)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // listBox_toolbox
            // 
            this.listBox_toolbox.FormattingEnabled = true;
            this.listBox_toolbox.ItemHeight = 16;
            this.listBox_toolbox.Location = new System.Drawing.Point(0, 31);
            this.listBox_toolbox.Name = "listBox_toolbox";
            this.listBox_toolbox.Size = new System.Drawing.Size(138, 500);
            this.listBox_toolbox.TabIndex = 2;
            // 
            // pictureBox_canvas
            // 
            this.pictureBox_canvas.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox_canvas.BackColor = System.Drawing.Color.White;
            this.pictureBox_canvas.Location = new System.Drawing.Point(144, 93);
            this.pictureBox_canvas.Name = "pictureBox_canvas";
            this.pictureBox_canvas.Size = new System.Drawing.Size(860, 703);
            this.pictureBox_canvas.TabIndex = 4;
            this.pictureBox_canvas.TabStop = false;
            this.pictureBox_canvas.Paint += new System.Windows.Forms.PaintEventHandler(this.pictureBox_canvas_Paint);
            this.pictureBox_canvas.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox_canvas_MouseDown);
            this.pictureBox_canvas.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pictureBox_canvas_MouseMove);
            this.pictureBox_canvas.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pictureBox_canvas_MouseUp);
            // 
            // listBox_explorer
            // 
            this.listBox_explorer.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.listBox_explorer.FormattingEnabled = true;
            this.listBox_explorer.HorizontalScrollbar = true;
            this.listBox_explorer.ItemHeight = 16;
            this.listBox_explorer.Location = new System.Drawing.Point(1010, 31);
            this.listBox_explorer.Name = "listBox_explorer";
            this.listBox_explorer.ScrollAlwaysVisible = true;
            this.listBox_explorer.Size = new System.Drawing.Size(238, 324);
            this.listBox_explorer.TabIndex = 5;
            this.listBox_explorer.SelectedIndexChanged += new System.EventHandler(this.listBox_explorer_SelectedIndexChanged);
            // 
            // groupBox_properties
            // 
            this.groupBox_properties.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox_properties.Controls.Add(this.button_turnObject);
            this.groupBox_properties.Controls.Add(this.textBox_isolation);
            this.groupBox_properties.Controls.Add(this.label_isolation);
            this.groupBox_properties.Controls.Add(this.numericUpDown_numOfWires);
            this.groupBox_properties.Controls.Add(this.label_numOfWires);
            this.groupBox_properties.Controls.Add(this.textBox_material);
            this.groupBox_properties.Controls.Add(this.textBox_diameter);
            this.groupBox_properties.Controls.Add(this.label_diameter);
            this.groupBox_properties.Controls.Add(this.button_save);
            this.groupBox_properties.Controls.Add(this.label_material);
            this.groupBox_properties.Controls.Add(this.numericUpDown_width);
            this.groupBox_properties.Controls.Add(this.label_width);
            this.groupBox_properties.Controls.Add(this.numericUpDown_height);
            this.groupBox_properties.Controls.Add(this.label_height);
            this.groupBox_properties.Controls.Add(this.textBox_name);
            this.groupBox_properties.Controls.Add(this.label_name);
            this.groupBox_properties.Location = new System.Drawing.Point(1010, 361);
            this.groupBox_properties.Name = "groupBox_properties";
            this.groupBox_properties.Size = new System.Drawing.Size(238, 282);
            this.groupBox_properties.TabIndex = 6;
            this.groupBox_properties.TabStop = false;
            this.groupBox_properties.Text = "Vlastnosti";
            // 
            // button_turnObject
            // 
            this.button_turnObject.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button_turnObject.Location = new System.Drawing.Point(6, 230);
            this.button_turnObject.Name = "button_turnObject";
            this.button_turnObject.Size = new System.Drawing.Size(100, 46);
            this.button_turnObject.TabIndex = 18;
            this.button_turnObject.Text = "Otočit";
            this.button_turnObject.UseVisualStyleBackColor = true;
            this.button_turnObject.Click += new System.EventHandler(this.button_turnObject_Click);
            // 
            // textBox_isolation
            // 
            this.textBox_isolation.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_isolation.Location = new System.Drawing.Point(126, 89);
            this.textBox_isolation.Name = "textBox_isolation";
            this.textBox_isolation.Size = new System.Drawing.Size(100, 22);
            this.textBox_isolation.TabIndex = 17;
            // 
            // label_isolation
            // 
            this.label_isolation.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label_isolation.AutoSize = true;
            this.label_isolation.Location = new System.Drawing.Point(126, 69);
            this.label_isolation.Name = "label_isolation";
            this.label_isolation.Size = new System.Drawing.Size(52, 17);
            this.label_isolation.TabIndex = 16;
            this.label_isolation.Text = "Izolace";
            // 
            // numericUpDown_numOfWires
            // 
            this.numericUpDown_numOfWires.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.numericUpDown_numOfWires.Location = new System.Drawing.Point(126, 142);
            this.numericUpDown_numOfWires.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.numericUpDown_numOfWires.Name = "numericUpDown_numOfWires";
            this.numericUpDown_numOfWires.Size = new System.Drawing.Size(100, 22);
            this.numericUpDown_numOfWires.TabIndex = 15;
            // 
            // label_numOfWires
            // 
            this.label_numOfWires.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label_numOfWires.AutoSize = true;
            this.label_numOfWires.Location = new System.Drawing.Point(126, 122);
            this.label_numOfWires.Name = "label_numOfWires";
            this.label_numOfWires.Size = new System.Drawing.Size(89, 17);
            this.label_numOfWires.TabIndex = 14;
            this.label_numOfWires.Text = "Počet vodičů";
            // 
            // textBox_material
            // 
            this.textBox_material.Location = new System.Drawing.Point(6, 197);
            this.textBox_material.Name = "textBox_material";
            this.textBox_material.Size = new System.Drawing.Size(100, 22);
            this.textBox_material.TabIndex = 13;
            // 
            // textBox_diameter
            // 
            this.textBox_diameter.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_diameter.Location = new System.Drawing.Point(126, 197);
            this.textBox_diameter.Name = "textBox_diameter";
            this.textBox_diameter.Size = new System.Drawing.Size(100, 22);
            this.textBox_diameter.TabIndex = 12;
            // 
            // label_diameter
            // 
            this.label_diameter.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.label_diameter.AutoSize = true;
            this.label_diameter.Location = new System.Drawing.Point(123, 177);
            this.label_diameter.Name = "label_diameter";
            this.label_diameter.Size = new System.Drawing.Size(54, 17);
            this.label_diameter.TabIndex = 11;
            this.label_diameter.Text = "Průměr";
            // 
            // button_save
            // 
            this.button_save.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button_save.Location = new System.Drawing.Point(126, 230);
            this.button_save.Name = "button_save";
            this.button_save.Size = new System.Drawing.Size(100, 46);
            this.button_save.TabIndex = 8;
            this.button_save.Text = "Aplikovat";
            this.button_save.UseVisualStyleBackColor = true;
            this.button_save.Click += new System.EventHandler(this.button_save_Click);
            // 
            // label_material
            // 
            this.label_material.AutoSize = true;
            this.label_material.Location = new System.Drawing.Point(6, 177);
            this.label_material.Name = "label_material";
            this.label_material.Size = new System.Drawing.Size(58, 17);
            this.label_material.TabIndex = 6;
            this.label_material.Text = "Materiál";
            // 
            // numericUpDown_width
            // 
            this.numericUpDown_width.Location = new System.Drawing.Point(6, 142);
            this.numericUpDown_width.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.numericUpDown_width.Name = "numericUpDown_width";
            this.numericUpDown_width.Size = new System.Drawing.Size(100, 22);
            this.numericUpDown_width.TabIndex = 5;
            // 
            // label_width
            // 
            this.label_width.AutoSize = true;
            this.label_width.Location = new System.Drawing.Point(6, 122);
            this.label_width.Name = "label_width";
            this.label_width.Size = new System.Drawing.Size(70, 17);
            this.label_width.TabIndex = 4;
            this.label_width.Text = "Šířka [cm]";
            // 
            // numericUpDown_height
            // 
            this.numericUpDown_height.Location = new System.Drawing.Point(6, 89);
            this.numericUpDown_height.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.numericUpDown_height.Name = "numericUpDown_height";
            this.numericUpDown_height.Size = new System.Drawing.Size(100, 22);
            this.numericUpDown_height.TabIndex = 3;
            // 
            // label_height
            // 
            this.label_height.AutoSize = true;
            this.label_height.Location = new System.Drawing.Point(6, 69);
            this.label_height.Name = "label_height";
            this.label_height.Size = new System.Drawing.Size(76, 17);
            this.label_height.TabIndex = 2;
            this.label_height.Text = "Výška [cm]";
            // 
            // textBox_name
            // 
            this.textBox_name.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox_name.Location = new System.Drawing.Point(6, 38);
            this.textBox_name.Name = "textBox_name";
            this.textBox_name.Size = new System.Drawing.Size(220, 22);
            this.textBox_name.TabIndex = 1;
            // 
            // label_name
            // 
            this.label_name.AutoSize = true;
            this.label_name.Location = new System.Drawing.Point(6, 18);
            this.label_name.Name = "label_name";
            this.label_name.Size = new System.Drawing.Size(52, 17);
            this.label_name.TabIndex = 0;
            this.label_name.Text = "Název ";
            // 
            // button_newObjectWindow
            // 
            this.button_newObjectWindow.Location = new System.Drawing.Point(25, 72);
            this.button_newObjectWindow.Name = "button_newObjectWindow";
            this.button_newObjectWindow.Size = new System.Drawing.Size(94, 25);
            this.button_newObjectWindow.TabIndex = 7;
            this.button_newObjectWindow.Text = "Okno";
            this.button_newObjectWindow.UseVisualStyleBackColor = true;
            this.button_newObjectWindow.Click += new System.EventHandler(this.button_newObjectWindow_Click);
            // 
            // button_newObjectDoor
            // 
            this.button_newObjectDoor.Location = new System.Drawing.Point(25, 103);
            this.button_newObjectDoor.Name = "button_newObjectDoor";
            this.button_newObjectDoor.Size = new System.Drawing.Size(94, 25);
            this.button_newObjectDoor.TabIndex = 8;
            this.button_newObjectDoor.Text = "Dveře";
            this.button_newObjectDoor.UseVisualStyleBackColor = true;
            this.button_newObjectDoor.Click += new System.EventHandler(this.button_newObjectDoor_Click);
            // 
            // button_newObjectSwitch
            // 
            this.button_newObjectSwitch.Location = new System.Drawing.Point(25, 255);
            this.button_newObjectSwitch.Name = "button_newObjectSwitch";
            this.button_newObjectSwitch.Size = new System.Drawing.Size(94, 25);
            this.button_newObjectSwitch.TabIndex = 10;
            this.button_newObjectSwitch.Text = "Vypínač";
            this.button_newObjectSwitch.UseVisualStyleBackColor = true;
            this.button_newObjectSwitch.Click += new System.EventHandler(this.button_newObjectSwitch_Click);
            // 
            // button_newObjectSocket
            // 
            this.button_newObjectSocket.Location = new System.Drawing.Point(25, 224);
            this.button_newObjectSocket.Name = "button_newObjectSocket";
            this.button_newObjectSocket.Size = new System.Drawing.Size(94, 25);
            this.button_newObjectSocket.TabIndex = 12;
            this.button_newObjectSocket.Text = "Zásuvka";
            this.button_newObjectSocket.UseVisualStyleBackColor = true;
            this.button_newObjectSocket.Click += new System.EventHandler(this.button_newObjectSocket_Click);
            // 
            // button_newObjectCable
            // 
            this.button_newObjectCable.Location = new System.Drawing.Point(25, 162);
            this.button_newObjectCable.Name = "button_newObjectCable";
            this.button_newObjectCable.Size = new System.Drawing.Size(94, 25);
            this.button_newObjectCable.TabIndex = 13;
            this.button_newObjectCable.Text = "Vodič";
            this.button_newObjectCable.UseVisualStyleBackColor = true;
            this.button_newObjectCable.Click += new System.EventHandler(this.button_newObjectCable_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label6.Location = new System.Drawing.Point(9, 52);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(58, 17);
            this.label6.TabIndex = 14;
            this.label6.Text = "Stavba";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label7.Location = new System.Drawing.Point(9, 141);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(72, 17);
            this.label7.TabIndex = 15;
            this.label7.Text = "Elektřina";
            // 
            // button_newObjectElectricalBox
            // 
            this.button_newObjectElectricalBox.Location = new System.Drawing.Point(25, 193);
            this.button_newObjectElectricalBox.Name = "button_newObjectElectricalBox";
            this.button_newObjectElectricalBox.Size = new System.Drawing.Size(94, 25);
            this.button_newObjectElectricalBox.TabIndex = 16;
            this.button_newObjectElectricalBox.Text = "Krabice";
            this.button_newObjectElectricalBox.UseVisualStyleBackColor = true;
            this.button_newObjectElectricalBox.Click += new System.EventHandler(this.button_newObjectElectricalBox_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label8.Location = new System.Drawing.Point(9, 296);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(39, 17);
            this.label8.TabIndex = 17;
            this.label8.Text = "Plyn";
            // 
            // button_newObjectGasPipe
            // 
            this.button_newObjectGasPipe.Location = new System.Drawing.Point(25, 316);
            this.button_newObjectGasPipe.Name = "button_newObjectGasPipe";
            this.button_newObjectGasPipe.Size = new System.Drawing.Size(94, 25);
            this.button_newObjectGasPipe.TabIndex = 18;
            this.button_newObjectGasPipe.Text = "Trubka";
            this.button_newObjectGasPipe.UseVisualStyleBackColor = true;
            this.button_newObjectGasPipe.Click += new System.EventHandler(this.button_newObjectGasPipe_Click);
            // 
            // button_newObjectGasTap
            // 
            this.button_newObjectGasTap.Location = new System.Drawing.Point(25, 347);
            this.button_newObjectGasTap.Name = "button_newObjectGasTap";
            this.button_newObjectGasTap.Size = new System.Drawing.Size(94, 25);
            this.button_newObjectGasTap.TabIndex = 19;
            this.button_newObjectGasTap.Text = "Kohout";
            this.button_newObjectGasTap.UseVisualStyleBackColor = true;
            this.button_newObjectGasTap.Click += new System.EventHandler(this.button_newObjectGasTap_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label9.Location = new System.Drawing.Point(9, 389);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(45, 17);
            this.label9.TabIndex = 20;
            this.label9.Text = "Voda";
            // 
            // button_newObjectWaterPipe
            // 
            this.button_newObjectWaterPipe.Location = new System.Drawing.Point(25, 409);
            this.button_newObjectWaterPipe.Name = "button_newObjectWaterPipe";
            this.button_newObjectWaterPipe.Size = new System.Drawing.Size(94, 25);
            this.button_newObjectWaterPipe.TabIndex = 21;
            this.button_newObjectWaterPipe.Text = "Trubka";
            this.button_newObjectWaterPipe.UseVisualStyleBackColor = true;
            this.button_newObjectWaterPipe.Click += new System.EventHandler(this.button_newObjectWaterPipe_Click);
            // 
            // button_newObjectWaterTap
            // 
            this.button_newObjectWaterTap.Location = new System.Drawing.Point(25, 440);
            this.button_newObjectWaterTap.Name = "button_newObjectWaterTap";
            this.button_newObjectWaterTap.Size = new System.Drawing.Size(94, 25);
            this.button_newObjectWaterTap.TabIndex = 22;
            this.button_newObjectWaterTap.Text = "Kohout";
            this.button_newObjectWaterTap.UseVisualStyleBackColor = true;
            this.button_newObjectWaterTap.Click += new System.EventHandler(this.button_newObjectWaterTap_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(472, 9);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(92, 17);
            this.label10.TabIndex = 25;
            this.label10.Text = "Strana stěny:";
            // 
            // button_turnWall
            // 
            this.button_turnWall.Location = new System.Drawing.Point(603, 6);
            this.button_turnWall.Name = "button_turnWall";
            this.button_turnWall.Size = new System.Drawing.Size(76, 23);
            this.button_turnWall.TabIndex = 26;
            this.button_turnWall.Text = "Otočit";
            this.button_turnWall.UseVisualStyleBackColor = true;
            this.button_turnWall.Click += new System.EventHandler(this.button_turnWall_Click);
            // 
            // label_wallSide
            // 
            this.label_wallSide.AutoSize = true;
            this.label_wallSide.Location = new System.Drawing.Point(570, 9);
            this.label_wallSide.Name = "label_wallSide";
            this.label_wallSide.Size = new System.Drawing.Size(17, 17);
            this.label_wallSide.TabIndex = 27;
            this.label_wallSide.Text = "A";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(141, 11);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(48, 17);
            this.label11.TabIndex = 28;
            this.label11.Text = "Zoom:";
            // 
            // label_zoom
            // 
            this.label_zoom.AutoSize = true;
            this.label_zoom.Location = new System.Drawing.Point(195, 11);
            this.label_zoom.Name = "label_zoom";
            this.label_zoom.Size = new System.Drawing.Size(22, 17);
            this.label_zoom.TabIndex = 29;
            this.label_zoom.Text = "x1";
            // 
            // trackBar_zoom
            // 
            this.trackBar_zoom.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.trackBar_zoom.BackColor = System.Drawing.SystemColors.ControlDark;
            this.trackBar_zoom.LargeChange = 1;
            this.trackBar_zoom.Location = new System.Drawing.Point(144, 31);
            this.trackBar_zoom.Minimum = 1;
            this.trackBar_zoom.Name = "trackBar_zoom";
            this.trackBar_zoom.Size = new System.Drawing.Size(860, 56);
            this.trackBar_zoom.TabIndex = 30;
            this.trackBar_zoom.TickStyle = System.Windows.Forms.TickStyle.TopLeft;
            this.trackBar_zoom.Value = 1;
            this.trackBar_zoom.ValueChanged += new System.EventHandler(this.trackBar_zoom_ValueChanged);
            // 
            // button_delete
            // 
            this.button_delete.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.button_delete.Location = new System.Drawing.Point(1010, 3);
            this.button_delete.Name = "button_delete";
            this.button_delete.Size = new System.Drawing.Size(238, 26);
            this.button_delete.TabIndex = 33;
            this.button_delete.Text = "Odstranit objekt";
            this.button_delete.UseVisualStyleBackColor = true;
            this.button_delete.Click += new System.EventHandler(this.button_delete_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button_DownDim);
            this.groupBox1.Controls.Add(this.button_UpDim);
            this.groupBox1.Controls.Add(this.button_RightDim);
            this.groupBox1.Controls.Add(this.button_LeftDim);
            this.groupBox1.Location = new System.Drawing.Point(0, 533);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(138, 110);
            this.groupBox1.TabIndex = 34;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Kóty";
            // 
            // button_DownDim
            // 
            this.button_DownDim.Location = new System.Drawing.Point(48, 78);
            this.button_DownDim.Name = "button_DownDim";
            this.button_DownDim.Size = new System.Drawing.Size(33, 23);
            this.button_DownDim.TabIndex = 3;
            this.button_DownDim.Text = "D";
            this.button_DownDim.UseVisualStyleBackColor = true;
            this.button_DownDim.Click += new System.EventHandler(this.button_DownDim_Click);
            // 
            // button_UpDim
            // 
            this.button_UpDim.Location = new System.Drawing.Point(48, 21);
            this.button_UpDim.Name = "button_UpDim";
            this.button_UpDim.Size = new System.Drawing.Size(33, 23);
            this.button_UpDim.TabIndex = 2;
            this.button_UpDim.Text = "H";
            this.button_UpDim.UseVisualStyleBackColor = true;
            this.button_UpDim.Click += new System.EventHandler(this.button_UpDim_Click);
            // 
            // button_RightDim
            // 
            this.button_RightDim.Location = new System.Drawing.Point(75, 50);
            this.button_RightDim.Name = "button_RightDim";
            this.button_RightDim.Size = new System.Drawing.Size(33, 23);
            this.button_RightDim.TabIndex = 1;
            this.button_RightDim.Text = "P";
            this.button_RightDim.UseVisualStyleBackColor = true;
            this.button_RightDim.Click += new System.EventHandler(this.button_RightDim_Click);
            // 
            // button_LeftDim
            // 
            this.button_LeftDim.Location = new System.Drawing.Point(21, 50);
            this.button_LeftDim.Name = "button_LeftDim";
            this.button_LeftDim.Size = new System.Drawing.Size(33, 23);
            this.button_LeftDim.TabIndex = 0;
            this.button_LeftDim.Text = "L";
            this.button_LeftDim.UseVisualStyleBackColor = true;
            this.button_LeftDim.Click += new System.EventHandler(this.button_LeftDim_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.Location = new System.Drawing.Point(7, 483);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 17);
            this.label1.TabIndex = 35;
            this.label1.Text = "Ostatní";
            // 
            // button_newObjectLabel
            // 
            this.button_newObjectLabel.Location = new System.Drawing.Point(25, 503);
            this.button_newObjectLabel.Name = "button_newObjectLabel";
            this.button_newObjectLabel.Size = new System.Drawing.Size(94, 25);
            this.button_newObjectLabel.TabIndex = 36;
            this.button_newObjectLabel.Text = "Popisek";
            this.button_newObjectLabel.UseVisualStyleBackColor = true;
            this.button_newObjectLabel.Click += new System.EventHandler(this.button_newObjectLabel_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.button_MoveDown);
            this.groupBox2.Controls.Add(this.button_MoveUp);
            this.groupBox2.Controls.Add(this.button_MoveRight);
            this.groupBox2.Controls.Add(this.button_MoveLeft);
            this.groupBox2.Location = new System.Drawing.Point(0, 649);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(138, 110);
            this.groupBox2.TabIndex = 35;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Pohyb";
            // 
            // button_MoveDown
            // 
            this.button_MoveDown.Location = new System.Drawing.Point(48, 78);
            this.button_MoveDown.Name = "button_MoveDown";
            this.button_MoveDown.Size = new System.Drawing.Size(33, 23);
            this.button_MoveDown.TabIndex = 3;
            this.button_MoveDown.Text = "▼";
            this.button_MoveDown.UseVisualStyleBackColor = true;
            this.button_MoveDown.Click += new System.EventHandler(this.button_MoveDown_Click);
            // 
            // button_MoveUp
            // 
            this.button_MoveUp.Location = new System.Drawing.Point(48, 21);
            this.button_MoveUp.Name = "button_MoveUp";
            this.button_MoveUp.Size = new System.Drawing.Size(33, 23);
            this.button_MoveUp.TabIndex = 2;
            this.button_MoveUp.Text = "▲";
            this.button_MoveUp.UseVisualStyleBackColor = true;
            this.button_MoveUp.Click += new System.EventHandler(this.button_MoveUp_Click);
            // 
            // button_MoveRight
            // 
            this.button_MoveRight.Location = new System.Drawing.Point(75, 50);
            this.button_MoveRight.Name = "button_MoveRight";
            this.button_MoveRight.Size = new System.Drawing.Size(33, 23);
            this.button_MoveRight.TabIndex = 1;
            this.button_MoveRight.Text = "▶";
            this.button_MoveRight.UseVisualStyleBackColor = true;
            this.button_MoveRight.Click += new System.EventHandler(this.button_MoveRight_Click);
            // 
            // button_MoveLeft
            // 
            this.button_MoveLeft.Location = new System.Drawing.Point(21, 50);
            this.button_MoveLeft.Name = "button_MoveLeft";
            this.button_MoveLeft.Size = new System.Drawing.Size(33, 23);
            this.button_MoveLeft.TabIndex = 0;
            this.button_MoveLeft.Text = "◀";
            this.button_MoveLeft.UseVisualStyleBackColor = true;
            this.button_MoveLeft.Click += new System.EventHandler(this.button_MoveLeft_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1248, 800);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.button_newObjectLabel);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.button_delete);
            this.Controls.Add(this.trackBar_zoom);
            this.Controls.Add(this.label_zoom);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label_wallSide);
            this.Controls.Add(this.button_turnWall);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.button_newObjectWaterTap);
            this.Controls.Add(this.button_newObjectWaterPipe);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.button_newObjectGasTap);
            this.Controls.Add(this.button_newObjectGasPipe);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.button_newObjectElectricalBox);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.button_newObjectCable);
            this.Controls.Add(this.button_newObjectSocket);
            this.Controls.Add(this.button_newObjectSwitch);
            this.Controls.Add(this.button_newObjectDoor);
            this.Controls.Add(this.button_newObjectWindow);
            this.Controls.Add(this.groupBox_properties);
            this.Controls.Add(this.listBox_explorer);
            this.Controls.Add(this.pictureBox_canvas);
            this.Controls.Add(this.listBox_toolbox);
            this.Name = "Form2";
            this.Text = "Form2";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form2_FormClosed);
            this.Load += new System.EventHandler(this.Form2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_canvas)).EndInit();
            this.groupBox_properties.ResumeLayout(false);
            this.groupBox_properties.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_numOfWires)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_width)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_height)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar_zoom)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox listBox_toolbox;
        private System.Windows.Forms.PictureBox pictureBox_canvas;
        private System.Windows.Forms.ListBox listBox_explorer;
        private System.Windows.Forms.GroupBox groupBox_properties;
        private System.Windows.Forms.Label label_height;
        private System.Windows.Forms.TextBox textBox_name;
        private System.Windows.Forms.Label label_name;
        private System.Windows.Forms.NumericUpDown numericUpDown_height;
        private System.Windows.Forms.NumericUpDown numericUpDown_width;
        private System.Windows.Forms.Label label_width;
        private System.Windows.Forms.Label label_material;
        private System.Windows.Forms.Button button_save;
        private System.Windows.Forms.Button button_newObjectWindow;
        private System.Windows.Forms.Button button_newObjectDoor;
        private System.Windows.Forms.Button button_newObjectSwitch;
        private System.Windows.Forms.Button button_newObjectSocket;
        private System.Windows.Forms.Button button_newObjectCable;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button button_newObjectElectricalBox;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button button_newObjectGasPipe;
        private System.Windows.Forms.Button button_newObjectGasTap;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button button_newObjectWaterPipe;
        private System.Windows.Forms.Button button_newObjectWaterTap;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button button_turnWall;
        private System.Windows.Forms.Label label_wallSide;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label_zoom;
        private System.Windows.Forms.TrackBar trackBar_zoom;
        private System.Windows.Forms.Button button_delete;
        private System.Windows.Forms.TextBox textBox_diameter;
        private System.Windows.Forms.Label label_diameter;
        private System.Windows.Forms.TextBox textBox_material;
        private System.Windows.Forms.Label label_numOfWires;
        private System.Windows.Forms.NumericUpDown numericUpDown_numOfWires;
        private System.Windows.Forms.TextBox textBox_isolation;
        private System.Windows.Forms.Label label_isolation;
        private System.Windows.Forms.Button button_turnObject;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button button_DownDim;
        private System.Windows.Forms.Button button_UpDim;
        private System.Windows.Forms.Button button_RightDim;
        private System.Windows.Forms.Button button_LeftDim;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button_newObjectLabel;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button button_MoveDown;
        private System.Windows.Forms.Button button_MoveUp;
        private System.Windows.Forms.Button button_MoveRight;
        private System.Windows.Forms.Button button_MoveLeft;
    }
}