﻿
namespace VisualizationApp
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.groupBox_toolbox = new System.Windows.Forms.GroupBox();
            this.label_saved = new System.Windows.Forms.Label();
            this.button_paste = new System.Windows.Forms.Button();
            this.button_copy = new System.Windows.Forms.Button();
            this.radioButton_label = new System.Windows.Forms.RadioButton();
            this.radioButton_hand = new System.Windows.Forms.RadioButton();
            this.radioButton_wall = new System.Windows.Forms.RadioButton();
            this.button_delete = new System.Windows.Forms.Button();
            this.pictureBox_canvas = new System.Windows.Forms.PictureBox();
            this.label6 = new System.Windows.Forms.Label();
            this.groupBox_properties = new System.Windows.Forms.GroupBox();
            this.button_openWall = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.numericUpDown_wallHeight = new System.Windows.Forms.NumericUpDown();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.textBox_wallName = new System.Windows.Forms.TextBox();
            this.button_saveChanges = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.comboBox_wallMaterial = new System.Windows.Forms.ComboBox();
            this.numericUpDown_wallWidth = new System.Windows.Forms.NumericUpDown();
            this.label4 = new System.Windows.Forms.Label();
            this.numericUpDown_wallLength = new System.Windows.Forms.NumericUpDown();
            this.label3 = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.souborToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.novýToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.uložitJakoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nahrátToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItem_pointSnap = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItem_view = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItem_dimensions = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItem_dimLenghts = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItem_dimAngles = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItem_wallsExplorer = new System.Windows.Forms.ToolStripMenuItem();
            this.ToolStripMenuItem_wallsProperties = new System.Windows.Forms.ToolStripMenuItem();
            this.listBox_explorer = new System.Windows.Forms.ListBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.groupBox_toolbox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_canvas)).BeginInit();
            this.groupBox_properties.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_wallHeight)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_wallWidth)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_wallLength)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox_toolbox
            // 
            this.groupBox_toolbox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox_toolbox.Controls.Add(this.label_saved);
            this.groupBox_toolbox.Controls.Add(this.button_paste);
            this.groupBox_toolbox.Controls.Add(this.button_copy);
            this.groupBox_toolbox.Controls.Add(this.radioButton_label);
            this.groupBox_toolbox.Controls.Add(this.radioButton_hand);
            this.groupBox_toolbox.Controls.Add(this.radioButton_wall);
            this.groupBox_toolbox.Controls.Add(this.button_delete);
            this.groupBox_toolbox.Location = new System.Drawing.Point(12, 33);
            this.groupBox_toolbox.Name = "groupBox_toolbox";
            this.groupBox_toolbox.Size = new System.Drawing.Size(1040, 92);
            this.groupBox_toolbox.TabIndex = 1;
            this.groupBox_toolbox.TabStop = false;
            this.groupBox_toolbox.Text = "Nástroje";
            // 
            // label_saved
            // 
            this.label_saved.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label_saved.AutoSize = true;
            this.label_saved.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label_saved.ForeColor = System.Drawing.Color.OliveDrab;
            this.label_saved.Location = new System.Drawing.Point(490, 33);
            this.label_saved.Name = "label_saved";
            this.label_saved.Size = new System.Drawing.Size(144, 39);
            this.label_saved.TabIndex = 13;
            this.label_saved.Text = "Uloženo";
            // 
            // button_paste
            // 
            this.button_paste.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.button_paste.ForeColor = System.Drawing.Color.OrangeRed;
            this.button_paste.Location = new System.Drawing.Point(884, 50);
            this.button_paste.Name = "button_paste";
            this.button_paste.Size = new System.Drawing.Size(94, 36);
            this.button_paste.TabIndex = 8;
            this.button_paste.Text = "Vložit";
            this.button_paste.UseVisualStyleBackColor = true;
            this.button_paste.Click += new System.EventHandler(this.button_paste_Click);
            // 
            // button_copy
            // 
            this.button_copy.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.button_copy.ForeColor = System.Drawing.Color.CornflowerBlue;
            this.button_copy.Location = new System.Drawing.Point(884, 16);
            this.button_copy.Name = "button_copy";
            this.button_copy.Size = new System.Drawing.Size(94, 35);
            this.button_copy.TabIndex = 7;
            this.button_copy.Text = "Kopírovat";
            this.button_copy.UseVisualStyleBackColor = true;
            this.button_copy.Click += new System.EventHandler(this.button_copy_Click);
            // 
            // radioButton_label
            // 
            this.radioButton_label.AutoSize = true;
            this.radioButton_label.Location = new System.Drawing.Point(191, 22);
            this.radioButton_label.Name = "radioButton_label";
            this.radioButton_label.Size = new System.Drawing.Size(79, 21);
            this.radioButton_label.TabIndex = 6;
            this.radioButton_label.TabStop = true;
            this.radioButton_label.Text = "Popisek";
            this.radioButton_label.UseVisualStyleBackColor = true;
            // 
            // radioButton_hand
            // 
            this.radioButton_hand.AutoSize = true;
            this.radioButton_hand.Location = new System.Drawing.Point(107, 21);
            this.radioButton_hand.Name = "radioButton_hand";
            this.radioButton_hand.Size = new System.Drawing.Size(62, 21);
            this.radioButton_hand.TabIndex = 1;
            this.radioButton_hand.Text = "Ruka";
            this.radioButton_hand.UseVisualStyleBackColor = true;
            this.radioButton_hand.CheckedChanged += new System.EventHandler(this.radioButton_hand_CheckedChanged);
            // 
            // radioButton_wall
            // 
            this.radioButton_wall.AutoSize = true;
            this.radioButton_wall.Checked = true;
            this.radioButton_wall.Location = new System.Drawing.Point(6, 21);
            this.radioButton_wall.Name = "radioButton_wall";
            this.radioButton_wall.Size = new System.Drawing.Size(66, 21);
            this.radioButton_wall.TabIndex = 0;
            this.radioButton_wall.TabStop = true;
            this.radioButton_wall.Text = "Stěna";
            this.radioButton_wall.UseVisualStyleBackColor = true;
            this.radioButton_wall.CheckedChanged += new System.EventHandler(this.radioButton_wall_CheckedChanged);
            // 
            // button_delete
            // 
            this.button_delete.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.button_delete.BackColor = System.Drawing.Color.White;
            this.button_delete.Enabled = false;
            this.button_delete.Font = new System.Drawing.Font("Bahnschrift SemiBold", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.button_delete.ForeColor = System.Drawing.Color.Red;
            this.button_delete.Image = ((System.Drawing.Image)(resources.GetObject("button_delete.Image")));
            this.button_delete.Location = new System.Drawing.Point(987, 16);
            this.button_delete.Margin = new System.Windows.Forms.Padding(0);
            this.button_delete.Name = "button_delete";
            this.button_delete.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.button_delete.Size = new System.Drawing.Size(50, 50);
            this.button_delete.TabIndex = 5;
            this.button_delete.UseVisualStyleBackColor = false;
            this.button_delete.Click += new System.EventHandler(this.button_delete_Click);
            // 
            // pictureBox_canvas
            // 
            this.pictureBox_canvas.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox_canvas.BackColor = System.Drawing.Color.White;
            this.pictureBox_canvas.Location = new System.Drawing.Point(12, 130);
            this.pictureBox_canvas.Name = "pictureBox_canvas";
            this.pictureBox_canvas.Size = new System.Drawing.Size(634, 461);
            this.pictureBox_canvas.TabIndex = 2;
            this.pictureBox_canvas.TabStop = false;
            this.pictureBox_canvas.Paint += new System.Windows.Forms.PaintEventHandler(this.pictureBox_canvas_Paint);
            this.pictureBox_canvas.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox_canvas_MouseDown);
            this.pictureBox_canvas.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pictureBox_canvas_MouseMove);
            this.pictureBox_canvas.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pictureBox_canvas_MouseUp);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(7, 25);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(48, 17);
            this.label6.TabIndex = 6;
            this.label6.Text = "Název";
            // 
            // groupBox_properties
            // 
            this.groupBox_properties.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox_properties.Controls.Add(this.button_openWall);
            this.groupBox_properties.Controls.Add(this.label7);
            this.groupBox_properties.Controls.Add(this.numericUpDown_wallHeight);
            this.groupBox_properties.Controls.Add(this.pictureBox1);
            this.groupBox_properties.Controls.Add(this.textBox_wallName);
            this.groupBox_properties.Controls.Add(this.button_saveChanges);
            this.groupBox_properties.Controls.Add(this.label5);
            this.groupBox_properties.Controls.Add(this.comboBox_wallMaterial);
            this.groupBox_properties.Controls.Add(this.numericUpDown_wallWidth);
            this.groupBox_properties.Controls.Add(this.label6);
            this.groupBox_properties.Controls.Add(this.label4);
            this.groupBox_properties.Controls.Add(this.numericUpDown_wallLength);
            this.groupBox_properties.Controls.Add(this.label3);
            this.groupBox_properties.Location = new System.Drawing.Point(652, 284);
            this.groupBox_properties.Name = "groupBox_properties";
            this.groupBox_properties.Size = new System.Drawing.Size(400, 352);
            this.groupBox_properties.TabIndex = 5;
            this.groupBox_properties.TabStop = false;
            this.groupBox_properties.Text = "Vlastnosti";
            // 
            // button_openWall
            // 
            this.button_openWall.Location = new System.Drawing.Point(285, 217);
            this.button_openWall.Name = "button_openWall";
            this.button_openWall.Size = new System.Drawing.Size(109, 32);
            this.button_openWall.TabIndex = 11;
            this.button_openWall.Text = "Otevřít stěnu";
            this.button_openWall.UseVisualStyleBackColor = true;
            this.button_openWall.Click += new System.EventHandler(this.button_openWall_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(262, 79);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(76, 17);
            this.label7.TabIndex = 10;
            this.label7.Text = "Výška [cm]";
            // 
            // numericUpDown_wallHeight
            // 
            this.numericUpDown_wallHeight.Increment = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.numericUpDown_wallHeight.Location = new System.Drawing.Point(265, 99);
            this.numericUpDown_wallHeight.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.numericUpDown_wallHeight.Name = "numericUpDown_wallHeight";
            this.numericUpDown_wallHeight.Size = new System.Drawing.Size(92, 22);
            this.numericUpDown_wallHeight.TabIndex = 9;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox1.BackColor = System.Drawing.Color.White;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBox1.Location = new System.Drawing.Point(10, 189);
            this.pictureBox1.MinimumSize = new System.Drawing.Size(160, 160);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(160, 160);
            this.pictureBox1.TabIndex = 8;
            this.pictureBox1.TabStop = false;
            // 
            // textBox_wallName
            // 
            this.textBox_wallName.Location = new System.Drawing.Point(10, 45);
            this.textBox_wallName.Name = "textBox_wallName";
            this.textBox_wallName.Size = new System.Drawing.Size(347, 22);
            this.textBox_wallName.TabIndex = 7;
            // 
            // button_saveChanges
            // 
            this.button_saveChanges.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button_saveChanges.Location = new System.Drawing.Point(285, 255);
            this.button_saveChanges.Name = "button_saveChanges";
            this.button_saveChanges.Size = new System.Drawing.Size(109, 80);
            this.button_saveChanges.TabIndex = 6;
            this.button_saveChanges.Text = "Aplikovat";
            this.button_saveChanges.UseVisualStyleBackColor = true;
            this.button_saveChanges.Click += new System.EventHandler(this.button_saveChanges_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(7, 139);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(58, 17);
            this.label5.TabIndex = 5;
            this.label5.Text = "Materiál";
            // 
            // comboBox_wallMaterial
            // 
            this.comboBox_wallMaterial.FormattingEnabled = true;
            this.comboBox_wallMaterial.Items.AddRange(new object[] {
            "Nevybráno",
            "Cihla-plná",
            "Cihla-dutá",
            "Cihla-vápenopísková",
            "Ytong",
            "Porfix",
            "Kámen"});
            this.comboBox_wallMaterial.Location = new System.Drawing.Point(10, 159);
            this.comboBox_wallMaterial.Name = "comboBox_wallMaterial";
            this.comboBox_wallMaterial.Size = new System.Drawing.Size(121, 24);
            this.comboBox_wallMaterial.TabIndex = 4;
            this.comboBox_wallMaterial.SelectedIndexChanged += new System.EventHandler(this.comboBox_wallMaterial_SelectedIndexChanged);
            // 
            // numericUpDown_wallWidth
            // 
            this.numericUpDown_wallWidth.Increment = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.numericUpDown_wallWidth.Location = new System.Drawing.Point(136, 99);
            this.numericUpDown_wallWidth.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.numericUpDown_wallWidth.Name = "numericUpDown_wallWidth";
            this.numericUpDown_wallWidth.Size = new System.Drawing.Size(92, 22);
            this.numericUpDown_wallWidth.TabIndex = 3;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(133, 79);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(99, 17);
            this.label4.TabIndex = 2;
            this.label4.Text = "Síla stěny [cm]";
            // 
            // numericUpDown_wallLength
            // 
            this.numericUpDown_wallLength.Enabled = false;
            this.numericUpDown_wallLength.Increment = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.numericUpDown_wallLength.Location = new System.Drawing.Point(10, 99);
            this.numericUpDown_wallLength.Maximum = new decimal(new int[] {
            100000000,
            0,
            0,
            0});
            this.numericUpDown_wallLength.Name = "numericUpDown_wallLength";
            this.numericUpDown_wallLength.Size = new System.Drawing.Size(92, 22);
            this.numericUpDown_wallLength.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(7, 79);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 17);
            this.label3.TabIndex = 0;
            this.label3.Text = "Délka [cm]";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.menuStrip1.Dock = System.Windows.Forms.DockStyle.None;
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.souborToolStripMenuItem,
            this.toolStripMenuItem1,
            this.ToolStripMenuItem_view});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(244, 28);
            this.menuStrip1.TabIndex = 10;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // souborToolStripMenuItem
            // 
            this.souborToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.novýToolStripMenuItem,
            this.uložitJakoToolStripMenuItem,
            this.nahrátToolStripMenuItem});
            this.souborToolStripMenuItem.Name = "souborToolStripMenuItem";
            this.souborToolStripMenuItem.Size = new System.Drawing.Size(71, 24);
            this.souborToolStripMenuItem.Text = "Soubor";
            // 
            // novýToolStripMenuItem
            // 
            this.novýToolStripMenuItem.Name = "novýToolStripMenuItem";
            this.novýToolStripMenuItem.Size = new System.Drawing.Size(163, 26);
            this.novýToolStripMenuItem.Text = "Nový";
            this.novýToolStripMenuItem.Click += new System.EventHandler(this.novýToolStripMenuItem_Click);
            // 
            // uložitJakoToolStripMenuItem
            // 
            this.uložitJakoToolStripMenuItem.Name = "uložitJakoToolStripMenuItem";
            this.uložitJakoToolStripMenuItem.Size = new System.Drawing.Size(163, 26);
            this.uložitJakoToolStripMenuItem.Text = "Uložit jako";
            this.uložitJakoToolStripMenuItem.Click += new System.EventHandler(this.uložitJakoToolStripMenuItem_Click);
            // 
            // nahrátToolStripMenuItem
            // 
            this.nahrátToolStripMenuItem.Name = "nahrátToolStripMenuItem";
            this.nahrátToolStripMenuItem.Size = new System.Drawing.Size(163, 26);
            this.nahrátToolStripMenuItem.Text = "Otevřít";
            this.nahrátToolStripMenuItem.Click += new System.EventHandler(this.nahrátToolStripMenuItem_Click);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.CheckOnClick = true;
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ToolStripMenuItem_pointSnap});
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(75, 24);
            this.toolStripMenuItem1.Text = "Kreslení";
            // 
            // ToolStripMenuItem_pointSnap
            // 
            this.ToolStripMenuItem_pointSnap.CheckOnClick = true;
            this.ToolStripMenuItem_pointSnap.Name = "ToolStripMenuItem_pointSnap";
            this.ToolStripMenuItem_pointSnap.Size = new System.Drawing.Size(210, 26);
            this.ToolStripMenuItem_pointSnap.Text = "Přichytávání bodů";
            // 
            // ToolStripMenuItem_view
            // 
            this.ToolStripMenuItem_view.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ToolStripMenuItem_dimensions,
            this.ToolStripMenuItem_wallsExplorer,
            this.ToolStripMenuItem_wallsProperties});
            this.ToolStripMenuItem_view.Name = "ToolStripMenuItem_view";
            this.ToolStripMenuItem_view.Size = new System.Drawing.Size(90, 24);
            this.ToolStripMenuItem_view.Text = "Zobrazení";
            // 
            // ToolStripMenuItem_dimensions
            // 
            this.ToolStripMenuItem_dimensions.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ToolStripMenuItem_dimLenghts,
            this.ToolStripMenuItem_dimAngles});
            this.ToolStripMenuItem_dimensions.Name = "ToolStripMenuItem_dimensions";
            this.ToolStripMenuItem_dimensions.Size = new System.Drawing.Size(173, 26);
            this.ToolStripMenuItem_dimensions.Text = "Kóty";
            // 
            // ToolStripMenuItem_dimLenghts
            // 
            this.ToolStripMenuItem_dimLenghts.CheckOnClick = true;
            this.ToolStripMenuItem_dimLenghts.Name = "ToolStripMenuItem_dimLenghts";
            this.ToolStripMenuItem_dimLenghts.Size = new System.Drawing.Size(130, 26);
            this.ToolStripMenuItem_dimLenghts.Text = "Délka";
            this.ToolStripMenuItem_dimLenghts.CheckedChanged += new System.EventHandler(this.ToolStripMenuItem_dimLenghts_CheckedChanged);
            // 
            // ToolStripMenuItem_dimAngles
            // 
            this.ToolStripMenuItem_dimAngles.CheckOnClick = true;
            this.ToolStripMenuItem_dimAngles.Name = "ToolStripMenuItem_dimAngles";
            this.ToolStripMenuItem_dimAngles.Size = new System.Drawing.Size(130, 26);
            this.ToolStripMenuItem_dimAngles.Text = "Úhel";
            this.ToolStripMenuItem_dimAngles.CheckedChanged += new System.EventHandler(this.ToolStripMenuItem_dimAngles_CheckedChanged);
            // 
            // ToolStripMenuItem_wallsExplorer
            // 
            this.ToolStripMenuItem_wallsExplorer.Checked = true;
            this.ToolStripMenuItem_wallsExplorer.CheckOnClick = true;
            this.ToolStripMenuItem_wallsExplorer.CheckState = System.Windows.Forms.CheckState.Checked;
            this.ToolStripMenuItem_wallsExplorer.Name = "ToolStripMenuItem_wallsExplorer";
            this.ToolStripMenuItem_wallsExplorer.Size = new System.Drawing.Size(173, 26);
            this.ToolStripMenuItem_wallsExplorer.Text = "Přehled stěn";
            this.ToolStripMenuItem_wallsExplorer.CheckedChanged += new System.EventHandler(this.ToolStripMenuItem_wallsExplorer_CheckedChanged);
            // 
            // ToolStripMenuItem_wallsProperties
            // 
            this.ToolStripMenuItem_wallsProperties.Checked = true;
            this.ToolStripMenuItem_wallsProperties.CheckOnClick = true;
            this.ToolStripMenuItem_wallsProperties.CheckState = System.Windows.Forms.CheckState.Checked;
            this.ToolStripMenuItem_wallsProperties.Name = "ToolStripMenuItem_wallsProperties";
            this.ToolStripMenuItem_wallsProperties.Size = new System.Drawing.Size(173, 26);
            this.ToolStripMenuItem_wallsProperties.Text = "Vlastnosti";
            this.ToolStripMenuItem_wallsProperties.CheckedChanged += new System.EventHandler(this.ToolStripMenuItem_wallsProperties_CheckedChanged);
            // 
            // listBox_explorer
            // 
            this.listBox_explorer.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.listBox_explorer.FormattingEnabled = true;
            this.listBox_explorer.HorizontalScrollbar = true;
            this.listBox_explorer.ItemHeight = 16;
            this.listBox_explorer.Location = new System.Drawing.Point(652, 130);
            this.listBox_explorer.MinimumSize = new System.Drawing.Size(400, 4);
            this.listBox_explorer.Name = "listBox_explorer";
            this.listBox_explorer.ScrollAlwaysVisible = true;
            this.listBox_explorer.Size = new System.Drawing.Size(400, 148);
            this.listBox_explorer.TabIndex = 11;
            this.listBox_explorer.SelectedIndexChanged += new System.EventHandler(this.listBox_explorer_SelectedIndexChanged);
            // 
            // timer1
            // 
            this.timer1.Interval = 500;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1061, 648);
            this.Controls.Add(this.listBox_explorer);
            this.Controls.Add(this.groupBox_properties);
            this.Controls.Add(this.pictureBox_canvas);
            this.Controls.Add(this.groupBox_toolbox);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "VisualizationApp";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox_toolbox.ResumeLayout(false);
            this.groupBox_toolbox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_canvas)).EndInit();
            this.groupBox_properties.ResumeLayout(false);
            this.groupBox_properties.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_wallHeight)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_wallWidth)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown_wallLength)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.GroupBox groupBox_toolbox;
        private System.Windows.Forms.RadioButton radioButton_wall;
        private System.Windows.Forms.PictureBox pictureBox_canvas;
        private System.Windows.Forms.RadioButton radioButton_hand;
        private System.Windows.Forms.GroupBox groupBox_properties;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox comboBox_wallMaterial;
        private System.Windows.Forms.NumericUpDown numericUpDown_wallWidth;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.NumericUpDown numericUpDown_wallLength;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button_saveChanges;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItem_pointSnap;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItem_view;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItem_dimensions;
        private System.Windows.Forms.Button button_delete;
        private System.Windows.Forms.ListBox listBox_explorer;
        private System.Windows.Forms.TextBox textBox_wallName;
        private System.Windows.Forms.RadioButton radioButton_label;
        private System.Windows.Forms.ToolStripMenuItem souborToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem uložitJakoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nahrátToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItem_wallsExplorer;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItem_wallsProperties;
        private System.Windows.Forms.Button button_paste;
        private System.Windows.Forms.Button button_copy;
        private System.Windows.Forms.Label label_saved;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.NumericUpDown numericUpDown_wallHeight;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItem_dimLenghts;
        private System.Windows.Forms.ToolStripMenuItem ToolStripMenuItem_dimAngles;
        private System.Windows.Forms.Button button_openWall;
        private System.Windows.Forms.ToolStripMenuItem novýToolStripMenuItem;
        private System.Windows.Forms.Timer timer1;
    }
}

