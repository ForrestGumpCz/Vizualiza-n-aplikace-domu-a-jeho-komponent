﻿namespace VisualizationApp
{
    public static class Actualize
    {
        public static void ExplorerForm1(this System.Windows.Forms.ListBox explorer, System.Windows.Forms.ComboBox wallMaterial)
        {
            explorer.Items.Clear();
            foreach (Form1.Walls wall in Form1.listWalls)
                explorer.Items.Add(wall.name + " | délka: " + wall.lenght + " | síla stěny: " + wall.width + " | výška: " + wall.height + " | materiál: " + wallMaterial.Items[wall.material]);

            foreach (Form1.Labels label in Form1.listLabels)
                explorer.Items.Add("Popis: " + label.text);

            if (Form1._selectedWall >= 0)
                explorer.SelectedIndex = Form1._selectedWall;
            else if (Form1._selectedLabel >= 0)
                explorer.SelectedIndex = Form1.listWalls.Count + Form1._selectedLabel;
        }

        public static void RightDownDims()
        {
            //Actualization right and down dimension when object moved
            string obj_type = Get.SelectedObjectType();
            if (obj_type != "none")
            {
                Form1.objectDimension dim = null;
                dim = Get.GetDim(Get.SelectedObjectId(), obj_type, "right");
                if (dim != null)
                    dim.startXY.X = Get.RightSideLocationOfObject().X;
                dim = null;
                dim = Get.GetDim(Get.SelectedObjectId(), obj_type, "down");
                if (dim != null)
                    dim.startXY.Y = Get.DownSideLocationOfObject().Y;
            }
        }
        //Loads all object of wall to Explorer
        public static void ExplorerForm2(this System.Windows.Forms.ListBox explorer)
        {
            explorer.Items.Clear();
            int i = 0;
            //Windows
            foreach (Form1.objectEntity window in Form1.listWindows)
            {
                if (window.wallId == Form2._selectedWall && window.wallSide == Form2._wallSide)
                    explorer.Items.Add(i.ToString() + ": " + window.name + " | Šířka: " + window.width.ToString() + "cm | Výška: " + window.height.ToString() + "cm");
                i++;
            }
            i = 0;
            //Doors
            foreach (Form1.objectEntity door in Form1.listDoors)
            {
                if (door.wallId == Form2._selectedWall && door.wallSide == Form2._wallSide)
                    explorer.Items.Add(i.ToString() + ": " + door.name + " | Šířka: " + door.width.ToString() + "cm | Výška: " + door.height.ToString() + "cm");
                i++;
            }
            i = 0;
            //Electrical Cables
            foreach (Form1.objectCableEntity cable in Form1.listCables)
            {
                if (cable.wallId == Form2._selectedWall && cable.wallSide == Form2._wallSide)
                    if (EntityDetection.IsHorizontal(cable.width))
                        explorer.Items.Add(i.ToString() + ": " + cable.name + " | typ: " + cable.isolation + " " + cable.num_of_wires + "x" + cable.diameter + " | materiál: " + cable.material_of_wires + " | délka: " + cable.width);
                    else
                        explorer.Items.Add(i.ToString() + ": " + cable.name + " | typ: " + cable.isolation + " " + cable.num_of_wires + "x" + cable.diameter + " | materiál: " + cable.material_of_wires + " | délka: " + cable.height);
                i++;
            }
            i = 0;
            //Electrical Boxes
            foreach (Form1.objectEntity box in Form1.listElectricalBoxes)
            {
                if (box.wallId == Form2._selectedWall && box.wallSide == Form2._wallSide)
                    explorer.Items.Add(i.ToString() + ": " + box.name);
                i++;
            }
            i = 0;
            //Sockets
            foreach (Form1.objectEntity socket in Form1.listSockets)
            {
                if (socket.wallId == Form2._selectedWall && socket.wallSide == Form2._wallSide)
                    explorer.Items.Add(i.ToString() + ": " + socket.name);
                i++;
            }
            i = 0;
            //Switches
            foreach (Form1.objectEntity obj_switch in Form1.listSwitches)
            {
                if (obj_switch.wallId == Form2._selectedWall && obj_switch.wallSide == Form2._wallSide)
                    explorer.Items.Add(i.ToString() + ": " + obj_switch.name);
                i++;
            }
            i = 0;
            //Gas pipes
            foreach (Form1.objectPipeEntity pipe in Form1.listGasPipes)
            {
                if (pipe.wallId == Form2._selectedWall && pipe.wallSide == Form2._wallSide)
                    if (EntityDetection.IsHorizontal(pipe.width))
                        explorer.Items.Add(i.ToString() + ": " + pipe.name + " | " + pipe.diameter + "mm | materiál: " + pipe.material + " | délka: " + pipe.width);
                    else
                        explorer.Items.Add(i.ToString() + ": " + pipe.name + " | " + pipe.diameter + "mm | materiál: " + pipe.material + " | délka: " + pipe.height);
                i++;
            }
            i = 0;
            //Gas Tapes
            foreach (Form1.objectTapEntity tap in Form1.listGasTapes)
            {
                if (tap.wallId == Form2._selectedWall && tap.wallSide == Form2._wallSide)
                    explorer.Items.Add(i.ToString() + ": " + tap.name);
                i++;
            }
            i = 0;
            //Water pipes
            foreach (Form1.objectPipeEntity pipe in Form1.listWaterPipes)
            {
                if (pipe.wallId == Form2._selectedWall && pipe.wallSide == Form2._wallSide)
                    if (EntityDetection.IsHorizontal(pipe.width))
                        explorer.Items.Add(i.ToString() + ": " + pipe.name + " | " + pipe.diameter + "mm | materiál: " + pipe.material + " | délka: " + pipe.width);
                    else
                        explorer.Items.Add(i.ToString() + ": " + pipe.name + " | " + pipe.diameter + "mm | materiál: " + pipe.material + " | délka: " + pipe.height);
                i++;
            }
            i = 0;
            //Water Tapes
            foreach (Form1.objectTapEntity tap in Form1.listWaterTapes)
            {
                if (tap.wallId == Form2._selectedWall && tap.wallSide == Form2._wallSide)
                    explorer.Items.Add(i.ToString() + ": " + tap.name);
                i++;
            }
            i = 0;
            //Labels
            foreach (Form1.WallLabels label in Form1.listWallLabels)
            {
                if (label.wallId == Form2._selectedWall && label.wallSide == Form2._wallSide)
                    explorer.Items.Add(i.ToString() + ": " + "Popisek " + label.id + ": " + label.text);
                i++;
            }
        }

        public static void CanvasMoving(int canvasMovingX, int canvasMovingY)
        {
            Form2._start_offsetX += canvasMovingX;
            Form2._start_offsetY += canvasMovingY;

            //recalculation of coordinates for each window
            foreach (Form1.objectEntity window in Form1.listWindows)
            {
                if (window.wallId == Form2._selectedWall)
                {
                    window.locationXY.X += canvasMovingX;
                    window.locationXY.Y += canvasMovingY;
                }
            }
            //recalculation of coordinates for each door
            foreach (Form1.objectEntity door in Form1.listDoors)
            {
                if (door.wallId == Form2._selectedWall)
                {
                    door.locationXY.X += canvasMovingX;
                    door.locationXY.Y += canvasMovingY;
                }
            }
            //recalculation of coordinates for each cable
            foreach (Form1.objectCableEntity cable in Form1.listCables)
            {
                if (cable.wallId == Form2._selectedWall)
                {
                    cable.locationXY.X += canvasMovingX;
                    cable.locationXY.Y += canvasMovingY;
                }
            }
            //recalculation of coordinates for each electrical box
            foreach (Form1.objectEntity box in Form1.listElectricalBoxes)
            {
                if (box.wallId == Form2._selectedWall)
                {
                    box.locationXY.X += canvasMovingX;
                    box.locationXY.Y += canvasMovingY;
                }
            }
            //recalculation of coordinates for each socket
            foreach (Form1.objectEntity socket in Form1.listSockets)
            {
                if (socket.wallId == Form2._selectedWall)
                {
                    socket.locationXY.X += canvasMovingX;
                    socket.locationXY.Y += canvasMovingY;
                }
            }
            //recalculation of coordinates for each switch
            foreach (Form1.objectEntity obj_switch in Form1.listSwitches)
            {
                if (obj_switch.wallId == Form2._selectedWall)
                {
                    obj_switch.locationXY.X += canvasMovingX;
                    obj_switch.locationXY.Y += canvasMovingY;
                }
            }
            //recalculation of coordinates for each gas pipe
            foreach (Form1.objectPipeEntity pipe in Form1.listGasPipes)
            {
                if (pipe.wallId == Form2._selectedWall)
                {
                    pipe.locationXY.X += canvasMovingX;
                    pipe.locationXY.Y += canvasMovingY;
                }
            }
            //recalculation of coordinates for each gas tap
            foreach (Form1.objectTapEntity tap in Form1.listGasTapes)
            {
                if (tap.wallId == Form2._selectedWall)
                {
                    tap.locationXY.X += canvasMovingX;
                    tap.locationXY.Y += canvasMovingY;
                }
            }
            //recalculation of coordinates for each water pipe
            foreach (Form1.objectPipeEntity pipe in Form1.listWaterPipes)
            {
                if (pipe.wallId == Form2._selectedWall)
                {
                    pipe.locationXY.X += canvasMovingX;
                    pipe.locationXY.Y += canvasMovingY;
                }
            }
            //recalculation of coordinates for each water tap
            foreach (Form1.objectTapEntity tap in Form1.listWaterTapes)
            {
                if (tap.wallId == Form2._selectedWall)
                {
                    tap.locationXY.X += canvasMovingX;
                    tap.locationXY.Y += canvasMovingY;
                }
            }
            //recalculation of coordinates for each dimension
            foreach (Form1.objectDimension dim in Form1.listDimensions)
            {
                if (dim.wallId == Form2._selectedWall)
                {
                    dim.startXY.X += canvasMovingX;
                    dim.startXY.Y += canvasMovingY;
                }
            }
            //recalculation of coordinates for each label
            foreach (Form1.WallLabels label in Form1.listWallLabels)
            {
                if (label.wallId == Form2._selectedWall)
                {
                    label.XY.X += canvasMovingX;
                    label.XY.Y += canvasMovingY;
                }
            }
        }
    }
}
