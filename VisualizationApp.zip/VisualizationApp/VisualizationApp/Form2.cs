﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace VisualizationApp
{
    public partial class Form2 : Form
    {
        public static int _start_offsetX = 20, _start_offsetY = 20;
        public static char _wallSide = 'A';
        public static int _zoom = 1;
        public static int _prevZoom = 1;


        bool _isMouseDown = false;
        public static Point _ptMouseDown;
        public static Point _ptNEW;
        public static int _widthNEW;
        public static int _heghtNEW;

        public static double _aX, _aY, _bX, _bY, _distX, _distY;
        int canvasMovingX, canvasMovingY;


        public static int _selectedWall;
        public static int _selectedWindow = -1;
        public static int _selectedDoor = -1;
        public static int _selectedCable = -1;
        public static int _selectedElectricalBox = -1;
        public static int _selectedSocket = -1;
        public static int _selectedSwitch = -1;
        public static int _selectedGasPipe = -1;
        public static int _selectedGasTap = -1;
        public static int _selectedWaterPipe = -1;
        public static int _selectedWaterTap = -1;
        public static int _selectedDimension = -1;
        public static int _selectedLabel = -1;

        public static Form1.Walls _openedWall = new Form1.Walls();

        public Form2(int selWall)
        {
            _selectedWall = selWall;
            InitializeComponent(); 
        }

        private void SetDesktopWindowToDefault()
        {
            this.Text = "Editace stěny: " + Form1.listWalls[_selectedWall].name;
            this.Width = Screen.PrimaryScreen.Bounds.Width - 100;
            this.Height = Screen.PrimaryScreen.Bounds.Height - 100;
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            if (_selectedWall < 0)
            {
                MessageBox.Show("Nebyla vybraná žádná stěna.");
                this.Close();
                return;
            }

            SetDesktopWindowToDefault();
            listBox_explorer.ExplorerForm2();         
            _openedWall = Form1.listWalls[_selectedWall];
            label_wallSide.Text = _wallSide.ToString();

           
        }

        private void Form2_FormClosed(object sender, FormClosedEventArgs e)
        {
            _prevZoom = _zoom;
            _zoom = 1;
            _wallSide = 'A';
            Zoom.NewLocationsForAllStuff();
            _wallSide = 'B';
            Zoom.NewLocationsForAllStuff();

            int newX = 0, newY = 0;
            if (_start_offsetX > 0)
                newX = 20 - _start_offsetX;
            else if (_start_offsetX < 0)
                newX = Math.Abs(_start_offsetX) - 20;

            if (_start_offsetY > 0)
                newY = 20 - _start_offsetY;
            else if (_start_offsetY < 0)
                newY = Math.Abs(_start_offsetY) - 20;

            Actualize.CanvasMoving(newX, newY);
        }
//Mouse interactions
        private void pictureBox_canvas_MouseDown(object sender, MouseEventArgs e)
        {
            _isMouseDown = true;
            _ptMouseDown = e.Location;
            listBox_explorer.ExplorerForm2();

            if ((_selectedDimension = EntityDetection.MouseInAnyDimension(e.Location)) >= 0)
            {             
                pictureBox_canvas.Invalidate();
                ShowNothing();
                _selectedWindow = -1;
                _selectedDoor = -1;
                _selectedCable = -1;
                _selectedElectricalBox = -1;
                _selectedSocket = -1;
                _selectedSwitch = -1;
                _selectedGasPipe = -1;
                _selectedGasTap = -1;
                _selectedWaterPipe = -1;
                _selectedWaterTap = -1;
                _selectedLabel = -1;
            }

            //clicked on label
            else if ((_selectedLabel = EntityDetection.MouseInAnyLabel(e.Location)) >= 0)
            {
                ShowLabelProperties();
                //Counting records in explorer
                listBox_explorer.SetSelected(listBox_explorer.ExplorerIndex(Form1.listWallLabels[_selectedLabel].text, _selectedLabel), true);



                pictureBox_canvas.Invalidate();
                
                _selectedWindow = -1;
                _selectedDoor = -1;
                _selectedCable = -1;
                _selectedElectricalBox = -1;
                _selectedSocket = -1;
                _selectedSwitch = -1;
                _selectedGasPipe = -1;
                _selectedGasTap = -1;
                _selectedWaterPipe = -1;
                _selectedWaterTap = -1;
                _selectedDimension = -1;
            }

            //clicked on window
            else if ((_selectedWindow = EntityDetection.MouseInAnyWindow(e.Location)) >= 0)
            {
                //Counting records in explorer
                listBox_explorer.SetSelected(listBox_explorer.ExplorerIndex(Form1.listWindows[_selectedWindow].name, _selectedWindow), true);

                pictureBox_canvas.Invalidate();
                ShowRectangleProperties();
                _selectedDoor = -1;
                _selectedCable = -1;
                _selectedElectricalBox = -1;
                _selectedSocket = -1;
                _selectedSwitch = -1;
                _selectedGasPipe = -1;
                _selectedGasTap = -1;
                _selectedWaterPipe = -1;
                _selectedWaterTap = -1;
                _selectedDimension = -1;
                _selectedLabel = -1;
            }

            //clicked on door
            else if((_selectedDoor = EntityDetection.MouseInAnyDoor(e.Location)) >= 0)
            {
                //Counting records in explorer
                listBox_explorer.SetSelected(listBox_explorer.ExplorerIndex(Form1.listDoors[_selectedDoor].name, _selectedDoor), true);

                pictureBox_canvas.Invalidate();
                ShowRectangleProperties();
                _selectedWindow = -1;
                _selectedCable = -1;
                _selectedElectricalBox = -1;
                _selectedSocket = -1;
                _selectedSwitch = -1;
                _selectedGasPipe = -1;
                _selectedGasTap = -1;
                _selectedWaterPipe = -1;
                _selectedWaterTap = -1;
                _selectedDimension = -1;
                _selectedLabel = -1;
            }

            //clicked on Cable
            else if ((_selectedCable = EntityDetection.MouseInAnyCable(e.Location)) >= 0)
            {
                //Counting records in explorer
                listBox_explorer.SetSelected(listBox_explorer.ExplorerIndex(Form1.listCables[_selectedCable].name, _selectedCable), true);

                pictureBox_canvas.Invalidate();
                ShowCableProperties();
                _selectedWindow = -1;
                _selectedDoor = -1;
                _selectedElectricalBox = -1;
                _selectedSocket = -1;
                _selectedSwitch = -1;
                _selectedGasPipe = -1;
                _selectedGasTap = -1;
                _selectedWaterPipe = -1;
                _selectedWaterTap = -1;
                _selectedDimension = -1;
                _selectedLabel = -1;
            }

            //clicked on Electrical Box
            else if ((_selectedElectricalBox = EntityDetection.MouseInAnyElectricalBox(e.Location)) >= 0)
            {
                //Counting records in explorer
                listBox_explorer.SetSelected(listBox_explorer.ExplorerIndex(Form1.listElectricalBoxes[_selectedElectricalBox].name, _selectedElectricalBox), true);

                pictureBox_canvas.Invalidate();
                ShowOnlyNameProperties();
                _selectedWindow = -1;
                _selectedDoor = -1;
                _selectedCable = -1;
                _selectedSocket = -1;
                _selectedSwitch = -1;
                _selectedGasPipe = -1;
                _selectedGasTap = -1;
                _selectedWaterPipe = -1;
                _selectedWaterTap = -1;
                _selectedDimension = -1;
                _selectedLabel = -1;
            }

            //clicked on socket
            else if ((_selectedSocket = EntityDetection.MouseInAnySocket(e.Location)) >= 0)
            {
                //Counting records in explorer
                listBox_explorer.SetSelected(listBox_explorer.ExplorerIndex(Form1.listSockets[_selectedSocket].name, _selectedSocket), true);

                pictureBox_canvas.Invalidate();
                ShowOnlyNameProperties();
                _selectedWindow = -1;
                _selectedDoor = -1;
                _selectedCable = -1;
                _selectedElectricalBox = -1;
                _selectedSwitch = -1;
                _selectedGasPipe = -1;
                _selectedGasTap = -1;
                _selectedWaterPipe = -1;
                _selectedWaterTap = -1;
                _selectedDimension = -1;
                _selectedLabel = -1;
            }

            //clicked on switch
            else if ((_selectedSwitch = EntityDetection.MouseInAnySwitch(e.Location)) >= 0)
            {
                //Counting records in explorer
                listBox_explorer.SetSelected(listBox_explorer.ExplorerIndex(Form1.listSwitches[_selectedSwitch].name, _selectedSwitch), true);

                pictureBox_canvas.Invalidate();
                ShowOnlyNameProperties();
                _selectedWindow = -1;
                _selectedDoor = -1;
                _selectedCable = -1;
                _selectedElectricalBox = -1;
                _selectedSocket = -1;
                _selectedGasPipe = -1;
                _selectedGasTap = -1;
                _selectedWaterPipe = -1;
                _selectedWaterTap = -1;
                _selectedDimension = -1;
                _selectedLabel = -1;
            }

            //clicked on Gas pipe
            else if ((_selectedGasPipe = EntityDetection.MouseInAnyGasPipe(e.Location)) >= 0)
            {
                //Counting records in explorer
                listBox_explorer.SetSelected(listBox_explorer.ExplorerIndex(Form1.listGasPipes[_selectedGasPipe].name, _selectedGasPipe), true);

                pictureBox_canvas.Invalidate();
                ShowPipeProperties();
                _selectedWindow = -1;
                _selectedDoor = -1;
                _selectedCable = -1;
                _selectedElectricalBox = -1;
                _selectedSocket = -1;
                _selectedSwitch = -1;
                _selectedGasTap = -1;
                _selectedWaterPipe = -1;
                _selectedWaterTap = -1;
                _selectedDimension = -1;
                _selectedLabel = -1;
            }

            //clicked on Gas tap
            else if ((_selectedGasTap = EntityDetection.MouseInAnyGasTap(e.Location)) >= 0)
            {
                //Counting records in explorer
                listBox_explorer.SetSelected(listBox_explorer.ExplorerIndex(Form1.listGasTapes[_selectedGasTap].name, _selectedGasTap), true);

                pictureBox_canvas.Invalidate();
                ShowTapProperties();
                _selectedWindow = -1;
                _selectedDoor = -1;
                _selectedCable = -1;
                _selectedElectricalBox = -1;
                _selectedSocket = -1;
                _selectedSwitch = -1;
                _selectedGasPipe = -1;
                _selectedWaterPipe = -1;
                _selectedWaterTap = -1;
                _selectedDimension = -1;
                _selectedLabel = -1;
            }

            //clicked on Water pipe
            else if ((_selectedWaterPipe = EntityDetection.MouseInAnyWaterPipe(e.Location)) >= 0)
            {
                //Counting records in explorer
                listBox_explorer.SetSelected(listBox_explorer.ExplorerIndex(Form1.listWaterPipes[_selectedWaterPipe].name, _selectedWaterPipe), true);

                pictureBox_canvas.Invalidate();
                ShowPipeProperties();
                _selectedWindow = -1;
                _selectedDoor = -1;
                _selectedCable = -1;
                _selectedElectricalBox = -1;
                _selectedSocket = -1;
                _selectedSwitch = -1;
                _selectedGasPipe = -1;
                _selectedGasTap = -1;
                _selectedWaterTap = -1;
                _selectedDimension = -1;
                _selectedLabel = -1;
            }

            //clicked on Water tap
            else if ((_selectedWaterTap = EntityDetection.MouseInAnyWaterTap(e.Location)) >= 0)
            {
                //Counting records in explorer
                listBox_explorer.SetSelected(listBox_explorer.ExplorerIndex(Form1.listWaterTapes[_selectedWaterTap].name, _selectedWaterTap), true);

                pictureBox_canvas.Invalidate();
                ShowTapProperties();
                _selectedWindow = -1;
                _selectedDoor = -1;
                _selectedCable = -1;
                _selectedElectricalBox = -1;
                _selectedSocket = -1;
                _selectedSwitch = -1;
                _selectedGasPipe = -1;
                _selectedWaterPipe = -1;
                _selectedGasTap = -1;
                _selectedDimension = -1;
                _selectedLabel = -1;
            }

            //clicked into free space
            else
            {
                listBox_explorer.ClearSelected();
                //set no object selected
                _selectedWindow = -1;
                _selectedDoor = -1;
                _selectedCable = -1;
                _selectedElectricalBox = -1;
                _selectedSocket = -1;
                _selectedSwitch = -1;
                _selectedGasPipe = -1;
                _selectedGasTap = -1;
                _selectedWaterPipe = -1;
                _selectedWaterTap = -1;
                _selectedDimension = -1;
                _selectedLabel = -1;
                ShowNothing();
            }             
        }

        private void pictureBox_canvas_MouseMove(object sender, MouseEventArgs e)
        {
            //hover over objects
            if(_isMouseDown == false)
            {
                //hover over windows, doors, sockets
                if(EntityDetection.MouseInAnyWindow(e.Location) >= 0 || EntityDetection.MouseInAnyDoor(e.Location) >= 0 || EntityDetection.MouseInAnyCable(e.Location) >= 0 ||
                    EntityDetection.MouseInAnyElectricalBox(e.Location) >= 0 || EntityDetection.MouseInAnySocket(e.Location) >= 0 || EntityDetection.MouseInAnySwitch(e.Location) >= 0 ||
                    EntityDetection.MouseInAnyGasTap(e.Location) >= 0 || EntityDetection.MouseInAnyGasPipe(e.Location) >= 0 || EntityDetection.MouseInAnyWaterPipe(e.Location) >= 0 ||
                    EntityDetection.MouseInAnyWaterTap(e.Location) >= 0 || EntityDetection.MouseInAnyDimension(e.Location) >= 0 || EntityDetection.MouseInAnyLabel(e.Location) >= 0)
                    Cursor = Cursors.Hand;
                else
                    Cursor = Cursors.Arrow;
            }

            //moving object / canvas
            else
            {
                //Moving with window
                if (_selectedWindow >= 0)
                {
                    _ptNEW.X = e.X + Form1.listWindows[_selectedWindow].locationXY.X - _ptMouseDown.X;
                    _ptNEW.Y = e.Y + Form1.listWindows[_selectedWindow].locationXY.Y - _ptMouseDown.Y;
                    _widthNEW = Form1.listWindows[_selectedWindow].width;
                    _heghtNEW = Form1.listWindows[_selectedWindow].height;
                    pictureBox_canvas.Invalidate();
                }

                //Moving with door
                else if (_selectedDoor >= 0)
                {
                    _ptNEW.X = e.X + Form1.listDoors[_selectedDoor].locationXY.X - _ptMouseDown.X;
                    _ptNEW.Y = e.Y + Form1.listDoors[_selectedDoor].locationXY.Y - _ptMouseDown.Y;
                    _widthNEW = Form1.listDoors[_selectedDoor].width;
                    _heghtNEW = Form1.listDoors[_selectedDoor].height;
                    pictureBox_canvas.Invalidate();
                }

                //Moving cable
                else if (_selectedCable >= 0)
                {
                    _ptNEW.X = e.X + Form1.listCables[_selectedCable].locationXY.X - _ptMouseDown.X;
                    _ptNEW.Y = e.Y + Form1.listCables[_selectedCable].locationXY.Y - _ptMouseDown.Y;
                    _widthNEW = Form1.listCables[_selectedCable].width;
                    _heghtNEW = Form1.listCables[_selectedCable].height;   
                    pictureBox_canvas.Invalidate();
                }

                //Moving with electrical box
                else if (_selectedElectricalBox >= 0)
                {
                    _ptNEW.X = e.X + Form1.listElectricalBoxes[_selectedElectricalBox].locationXY.X - _ptMouseDown.X;
                    _ptNEW.Y = e.Y + Form1.listElectricalBoxes[_selectedElectricalBox].locationXY.Y - _ptMouseDown.Y;
                    _widthNEW = Form1.listElectricalBoxes[_selectedElectricalBox].width;
                    _heghtNEW = Form1.listElectricalBoxes[_selectedElectricalBox].height;
                    pictureBox_canvas.Invalidate();
                }

                //Moving with socket
                else if (_selectedSocket >= 0)
                {
                    _ptNEW.X = e.X + Form1.listSockets[_selectedSocket].locationXY.X - _ptMouseDown.X;
                    _ptNEW.Y = e.Y + Form1.listSockets[_selectedSocket].locationXY.Y - _ptMouseDown.Y;
                    _widthNEW = Form1.listSockets[_selectedSocket].width;
                    _heghtNEW = Form1.listSockets[_selectedSocket].height;
                    pictureBox_canvas.Invalidate();
                }

                //Moving with switch
                else if (_selectedSwitch >= 0)
                {
                    _ptNEW.X = e.X + Form1.listSwitches[_selectedSwitch].locationXY.X - _ptMouseDown.X;
                    _ptNEW.Y = e.Y + Form1.listSwitches[_selectedSwitch].locationXY.Y - _ptMouseDown.Y;
                    _widthNEW = Form1.listSwitches[_selectedSwitch].width;
                    _heghtNEW = Form1.listSwitches[_selectedSwitch].height;
                    pictureBox_canvas.Invalidate();
                }

                //Moving gas pipe
                else if (_selectedGasPipe >= 0)
                {
                    _ptNEW.X = e.X + Form1.listGasPipes[_selectedGasPipe].locationXY.X - _ptMouseDown.X;
                    _ptNEW.Y = e.Y + Form1.listGasPipes[_selectedGasPipe].locationXY.Y - _ptMouseDown.Y;
                    _widthNEW = Form1.listGasPipes[_selectedGasPipe].width;
                    _heghtNEW = Form1.listGasPipes[_selectedGasPipe].height;
                    pictureBox_canvas.Invalidate();
                }

                //Moving with gas tap
                else if (_selectedGasTap >= 0)
                {
                    _ptNEW.X = e.X + Form1.listGasTapes[_selectedGasTap].locationXY.X - _ptMouseDown.X;
                    _ptNEW.Y = e.Y + Form1.listGasTapes[_selectedGasTap].locationXY.Y - _ptMouseDown.Y;
                    _widthNEW = Form1.listGasTapes[_selectedGasTap].width;
                    _heghtNEW = Form1.listGasTapes[_selectedGasTap].height;
                    pictureBox_canvas.Invalidate();
                }

                //Moving water pipe
                else if (_selectedWaterPipe >= 0)
                {
                    _ptNEW.X = e.X + Form1.listWaterPipes[_selectedWaterPipe].locationXY.X - _ptMouseDown.X;
                    _ptNEW.Y = e.Y + Form1.listWaterPipes[_selectedWaterPipe].locationXY.Y - _ptMouseDown.Y;
                    _widthNEW = Form1.listWaterPipes[_selectedWaterPipe].width;
                    _heghtNEW = Form1.listWaterPipes[_selectedWaterPipe].height;
                    pictureBox_canvas.Invalidate();
                }

                //Moving with water tap
                else if (_selectedWaterTap >= 0)
                {
                    _ptNEW.X = e.X + Form1.listWaterTapes[_selectedWaterTap].locationXY.X - _ptMouseDown.X;
                    _ptNEW.Y = e.Y + Form1.listWaterTapes[_selectedWaterTap].locationXY.Y - _ptMouseDown.Y;
                    _widthNEW = Form1.listWaterTapes[_selectedWaterTap].width;
                    _heghtNEW = Form1.listWaterTapes[_selectedWaterTap].height;
                    pictureBox_canvas.Invalidate();
                }


                //Moving with water tap
                else if (_selectedDimension >= 0)
                {
                    if(Form1.listDimensions[_selectedDimension].dimType == "left" || Form1.listDimensions[_selectedDimension].dimType == "right")
                    {
                        _ptNEW.X = Form1.listDimensions[_selectedDimension].startXY.X;
                        _ptNEW.Y = e.Y + Form1.listDimensions[_selectedDimension].startXY.Y - _ptMouseDown.Y;
                    }
                    else if(Form1.listDimensions[_selectedDimension].dimType == "up" || Form1.listDimensions[_selectedDimension].dimType == "down")
                    {
                        _ptNEW.X = e.X + Form1.listDimensions[_selectedDimension].startXY.X - _ptMouseDown.X;
                        _ptNEW.Y = Form1.listDimensions[_selectedDimension].startXY.Y;
                    }
                    
                    pictureBox_canvas.Invalidate();
                }

                //Moving with label
                else if (_selectedLabel >= 0)
                {
                    _ptNEW.X = e.X + Form1.listWallLabels[_selectedLabel].XY.X - _ptMouseDown.X;
                    _ptNEW.Y = e.Y + Form1.listWallLabels[_selectedLabel].XY.Y - _ptMouseDown.Y;
                    pictureBox_canvas.Invalidate();
                }

                //Moving with canvas
                else
                {
                    canvasMovingX = e.Location.X - _ptMouseDown.X;
                    canvasMovingY = e.Location.Y - _ptMouseDown.Y;
                    Cursor = Cursors.Hand;
                }
                    
            }
        }

        private void pictureBox_canvas_MouseUp(object sender, MouseEventArgs e)
        {
            _isMouseDown = false;
            if (_ptMouseDown != e.Location)
            {


                //window moving
                if (_selectedWindow >= 0)
                {
                    if (Form1.listWindows[_selectedWindow].wallId == _selectedWall && Form1.listWindows[_selectedWindow].wallSide == _wallSide)
                        Form1.listWindows[_selectedWindow].locationXY = _ptNEW;
                }

                //door moving
                else if (_selectedDoor >= 0)
                {
                    if (Form1.listDoors[_selectedDoor].wallId == _selectedWall && Form1.listDoors[_selectedDoor].wallSide == _wallSide)
                        Form1.listDoors[_selectedDoor].locationXY = _ptNEW;
                }

                //cable moving
                else if (_selectedCable >= 0)
                {
                    if (Form1.listCables[_selectedCable].wallId == _selectedWall && Form1.listCables[_selectedCable].wallSide == _wallSide)
                        Form1.listCables[_selectedCable].locationXY = _ptNEW;
                }

                //electrical box moving
                else if (_selectedElectricalBox >= 0)
                {
                    if (Form1.listElectricalBoxes[_selectedElectricalBox].wallId == _selectedWall && Form1.listElectricalBoxes[_selectedElectricalBox].wallSide == _wallSide)
                        Form1.listElectricalBoxes[_selectedElectricalBox].locationXY = _ptNEW;
                }

                //socket moving
                else if (_selectedSocket >= 0)
                {
                    if (Form1.listSockets[_selectedSocket].wallId == _selectedWall && Form1.listSockets[_selectedSocket].wallSide == _wallSide)
                        Form1.listSockets[_selectedSocket].locationXY = _ptNEW;
                }

                //switch moving
                else if (_selectedSwitch >= 0)
                {
                    if (Form1.listSwitches[_selectedSwitch].wallId == _selectedWall && Form1.listSwitches[_selectedSwitch].wallSide == _wallSide)
                        Form1.listSwitches[_selectedSwitch].locationXY = _ptNEW;
                }

                //gas pipe moving
                else if (_selectedGasPipe >= 0)
                {
                    if (Form1.listGasPipes[_selectedGasPipe].wallId == _selectedWall && Form1.listGasPipes[_selectedGasPipe].wallSide == _wallSide)
                        Form1.listGasPipes[_selectedGasPipe].locationXY = _ptNEW;
                }

                //gas tap moving
                else if (_selectedGasTap >= 0)
                {
                    if (Form1.listGasTapes[_selectedGasTap].wallId == _selectedWall && Form1.listGasTapes[_selectedGasTap].wallSide == _wallSide)
                        Form1.listGasTapes[_selectedGasTap].locationXY = _ptNEW;
                }

                //water pipe moving
                else if (_selectedWaterPipe >= 0)
                {
                    if (Form1.listWaterPipes[_selectedWaterPipe].wallId == _selectedWall && Form1.listWaterPipes[_selectedWaterPipe].wallSide == _wallSide)
                        Form1.listWaterPipes[_selectedWaterPipe].locationXY = _ptNEW;
                }

                //water tap moving
                else if (_selectedWaterTap >= 0)
                {
                    if (Form1.listWaterTapes[_selectedWaterTap].wallId == _selectedWall && Form1.listWaterTapes[_selectedWaterTap].wallSide == _wallSide)
                        Form1.listWaterTapes[_selectedWaterTap].locationXY = _ptNEW;
                }

                //dimension moving
                else if (_selectedDimension >= 0)
                {
                    if (Form1.listDimensions[_selectedDimension].wallId == _selectedWall && Form1.listDimensions[_selectedDimension].wallSide == _wallSide)
                        Form1.listDimensions[_selectedDimension].startXY = _ptNEW;
                }

                //label moving
                else if (_selectedLabel >= 0)
                {
                    if (Form1.listWallLabels[_selectedLabel].wallId == _selectedWall && Form1.listWallLabels[_selectedLabel].wallSide == _wallSide)
                        Form1.listWallLabels[_selectedLabel].XY = _ptNEW;
                }

                //canvas moving
                else
                {
                    Actualize.CanvasMoving(canvasMovingX, canvasMovingY);
                }
                Cursor = Cursors.Arrow;
            }       
            pictureBox_canvas.Invalidate();

            Actualize.RightDownDims();
        }

        

        //Toolbox instances
        //new instance of objectWindow
        private void button_newObjectWindow_Click(object sender, EventArgs e)
        {
            //Creation new object window with default parameters
            Form1.objectEntity window = NewEntity.Window();
            Form1.listWindows.Add(window);

            listBox_explorer.ExplorerForm2();
            listBox_explorer.SetSelected(listBox_explorer.ExplorerIndex(window.name, Form1.listWindows.Count - 1), true);
            pictureBox_canvas.Invalidate();
        }

        //new instance of objectDoor
        private void button_newObjectDoor_Click(object sender, EventArgs e)
        {
            //Creation new object window with default parameters
            Form1.objectEntity door = NewEntity.Door();
            Form1.listDoors.Add(door);

            listBox_explorer.ExplorerForm2();
            listBox_explorer.SetSelected(listBox_explorer.ExplorerIndex(door.name, Form1.listDoors.Count - 1), true);
            pictureBox_canvas.Invalidate();
        }

        //new instance of objectCable
        private void button_newObjectCable_Click(object sender, EventArgs e)
        {
            //Creation new object cable with default parameters
            Form1.objectCableEntity cable = NewEntity.Cable();
            Form1.listCables.Add(cable);

            listBox_explorer.ExplorerForm2();
            listBox_explorer.SetSelected(listBox_explorer.ExplorerIndex(cable.name, Form1.listCables.Count - 1), true);
            pictureBox_canvas.Invalidate();
        }

        //new instance of objectElectricalBox
        private void button_newObjectElectricalBox_Click(object sender, EventArgs e)
        {
            //Creation new object ElectricalBox with default parameters
            Form1.objectEntity box = NewEntity.Box();
            Form1.listElectricalBoxes.Add(box);

            listBox_explorer.ExplorerForm2();
            listBox_explorer.SetSelected(listBox_explorer.ExplorerIndex(box.name, Form1.listElectricalBoxes.Count - 1), true);
            pictureBox_canvas.Invalidate();
        }

        //new instance of objectSocket
        private void button_newObjectSocket_Click(object sender, EventArgs e)
        {
            //Creation new object Socket with default parameters
            Form1.objectEntity socket = NewEntity.Socket();
            Form1.listSockets.Add(socket);

            listBox_explorer.ExplorerForm2();
            listBox_explorer.SetSelected(listBox_explorer.ExplorerIndex(socket.name, Form1.listSockets.Count - 1), true);
            pictureBox_canvas.Invalidate();
        }

        //new instance of objectSwitch
        private void button_newObjectSwitch_Click(object sender, EventArgs e)
        {
            //Creation new object Switch with default parameters
            Form1.objectEntity obj_switch = NewEntity.Switch();
            Form1.listSwitches.Add(obj_switch);

            listBox_explorer.ExplorerForm2();
            listBox_explorer.SetSelected(listBox_explorer.ExplorerIndex(obj_switch.name, Form1.listSwitches.Count - 1), true);
            pictureBox_canvas.Invalidate();
        }

        //new instance of objectGasPipe
        private void button_newObjectGasPipe_Click(object sender, EventArgs e)
        {
            //Creation new object Gas pipe with default parameters
            Form1.objectPipeEntity pipe = NewEntity.GasPipe();
            Form1.listGasPipes.Add(pipe);

            listBox_explorer.ExplorerForm2();
            listBox_explorer.SetSelected(listBox_explorer.ExplorerIndex(pipe.name, Form1.listGasPipes.Count - 1), true);
            pictureBox_canvas.Invalidate();
        }

        //new instance of objectGasTap
        private void button_newObjectGasTap_Click(object sender, EventArgs e)
        {
            //Creation new object GasTap with default parameters
            Form1.objectTapEntity tap = NewEntity.GasTap();
            Form1.listGasTapes.Add(tap);

            listBox_explorer.ExplorerForm2();
            listBox_explorer.SetSelected(listBox_explorer.ExplorerIndex(tap.name, Form1.listGasTapes.Count - 1), true);
            pictureBox_canvas.Invalidate();
        }

        //new instance of objectWaterPipe
        private void button_newObjectWaterPipe_Click(object sender, EventArgs e)
        {
            //Creation new object Water pipe with default parameters
            Form1.objectPipeEntity pipe = NewEntity.WaterPipe();
            Form1.listWaterPipes.Add(pipe);

            listBox_explorer.ExplorerForm2();
            listBox_explorer.SetSelected(listBox_explorer.ExplorerIndex(pipe.name, Form1.listWaterPipes.Count - 1), true);
            pictureBox_canvas.Invalidate();
        }

        //new isntance of object water tap
        private void button_newObjectWaterTap_Click(object sender, EventArgs e)
        {
            //Creation new object WaterTap with default parameters
            Form1.objectTapEntity tap = NewEntity.WaterTap();
            Form1.listWaterTapes.Add(tap);

             listBox_explorer.ExplorerForm2();
            listBox_explorer.SetSelected(listBox_explorer.ExplorerIndex(tap.name, Form1.listWaterTapes.Count - 1), true);
            pictureBox_canvas.Invalidate();
        }

        //new instance of object label
        private void button_newObjectLabel_Click(object sender, EventArgs e)
        {
            //Creation new object label with default parameters
            Form1.WallLabels label = NewEntity.Label();
            Form1.listWallLabels.Add(label);

            listBox_explorer.ExplorerForm2();
            listBox_explorer.SetSelected(listBox_explorer.ExplorerIndex(label.id + ": Popisek " + label.id, Form1.listWallLabels.Count - 1), true);
            pictureBox_canvas.Invalidate();

        }

        //Another buttons
        //change side of wall
        private void button_turnWall_Click(object sender, EventArgs e)
        {
            if(_wallSide == 'A')
            {
                label_wallSide.Text = "B";
                _wallSide = 'B';
            }
            else
            {
                label_wallSide.Text = "A";
                _wallSide = 'A';
            }
            pictureBox_canvas.Invalidate();
             listBox_explorer.ExplorerForm2();              
        }

        //delete object
        private void button_delete_Click(object sender, EventArgs e)
        {
            RemoveChildDimensions(Get.SelectedObjectType(), Get.SelectedObjectId());
            if (_selectedWindow >= 0)
            {
                Form1.listWindows.RemoveAt(_selectedWindow);               
                _selectedWindow = -1;               
            }
            else if (_selectedDoor >= 0)
            {
                Form1.listDoors.RemoveAt(_selectedDoor);
                _selectedDoor = -1;
            }
            else if (_selectedCable >= 0)
            {
                Form1.listCables.RemoveAt(_selectedCable);
                _selectedCable = -1;
            }
            else if (_selectedElectricalBox >= 0)
            {
                Form1.listElectricalBoxes.RemoveAt(_selectedElectricalBox);
                _selectedElectricalBox = -1;
            }
            else if (_selectedSocket >= 0)
            {
                Form1.listSockets.RemoveAt(_selectedSocket);
                _selectedSocket = -1;
            }
            else if (_selectedSwitch >= 0)
            {
                Form1.listSwitches.RemoveAt(_selectedSwitch);
                _selectedSwitch = -1;
            }
            else if (_selectedGasPipe >= 0)
            {
                Form1.listGasPipes.RemoveAt(_selectedGasPipe);
                _selectedGasPipe = -1;
            }
            else if (_selectedGasTap >= 0)
            {
                Form1.listGasTapes.RemoveAt(_selectedGasTap);
                _selectedGasTap = -1;
            }
            else if (_selectedWaterPipe >= 0)
            {
                Form1.listWaterPipes.RemoveAt(_selectedWaterPipe);
                _selectedWaterPipe = -1;
            }
            else if (_selectedWaterTap >= 0)
            {
                Form1.listWaterTapes.RemoveAt(_selectedWaterTap);
                _selectedWaterTap = -1;
            }
            else if (_selectedLabel >= 0)
            {
                Form1.listWallLabels.RemoveAt(_selectedLabel);
                _selectedLabel = -1;
            }
            pictureBox_canvas.Invalidate();
             listBox_explorer.ExplorerForm2();
        }

        //turn object about 90° degrees to right
        private void button_turnObject_Click(object sender, EventArgs e)
        {
            int tmp;
            
           if(_selectedCable >= 0)
            {
                tmp = Form1.listCables[_selectedCable].width;
                Form1.listCables[_selectedCable].width = Form1.listCables[_selectedCable].height;
                Form1.listCables[_selectedCable].height = tmp;
            }
            
            else if (_selectedGasPipe >= 0)
            {
                tmp = Form1.listGasPipes[_selectedGasPipe].width;
                Form1.listGasPipes[_selectedGasPipe].width = Form1.listGasPipes[_selectedGasPipe].height;
                Form1.listGasPipes[_selectedGasPipe].height = tmp;
            }
            
            else if (_selectedWaterPipe >= 0)
            {
                tmp = Form1.listWaterPipes[_selectedWaterPipe].width;
                Form1.listWaterPipes[_selectedWaterPipe].width = Form1.listWaterPipes[_selectedWaterPipe].height;
                Form1.listWaterPipes[_selectedWaterPipe].height = tmp;
            }          

            tmp = _widthNEW;
            _widthNEW = _heghtNEW;
            _heghtNEW = tmp;

            pictureBox_canvas.Invalidate();
             listBox_explorer.ExplorerForm2();
            Actualize.RightDownDims();
        }

        //saving properties
        private void button_save_Click(object sender, EventArgs e)
        {
            if (IsNameAlreadyUsed(textBox_name.Text) == true)
            {
                MessageBox.Show("Název: " + textBox_name.Text + " v projektu již existuje!\n\n" + "Tip: zadejte unikátní název přidáním nazvu entity např. label:dveře");
                MessageBox.Show("Změny nebyly provedeny!");
                return;
            }
            

            //window selected
            if (_selectedWindow >= 0)
            {
                Form1.listWindows[_selectedWindow].name = textBox_name.Text;
                Form1.listWindows[_selectedWindow].width = (int)numericUpDown_width.Value;
                Form1.listWindows[_selectedWindow].height = (int)numericUpDown_height.Value;
            }
            //door selected
            else if (_selectedDoor >= 0)
            {
                Form1.listDoors[_selectedDoor].name = textBox_name.Text;
                Form1.listDoors[_selectedDoor].width = (int)numericUpDown_width.Value;
                Form1.listDoors[_selectedDoor].height = (int)numericUpDown_height.Value;
            }

            //cable selected
            else if (_selectedCable >= 0)
            {
                Form1.listCables[_selectedCable].name = textBox_name.Text;
                if (EntityDetection.IsHorizontal(Form1.listCables[_selectedCable].width))
                    Form1.listCables[_selectedCable].width = (int)numericUpDown_height.Value;
                else
                    Form1.listCables[_selectedCable].height = (int)numericUpDown_height.Value;
                Form1.listCables[_selectedCable].material_of_wires = textBox_material.Text;
                Form1.listCables[_selectedCable].isolation = textBox_isolation.Text;
                Form1.listCables[_selectedCable].num_of_wires = (int)numericUpDown_numOfWires.Value;
                Form1.listCables[_selectedCable].diameter = textBox_diameter.Text;
            }

            //electrical box selected
            else if (_selectedElectricalBox >= 0)
            {
                Form1.listElectricalBoxes[_selectedElectricalBox].name = textBox_name.Text;
            }

            //socket selected
            else if (_selectedSocket >= 0)
            {
                Form1.listSockets[_selectedSocket].name = textBox_name.Text;
            }

            //switch selected
            else if (_selectedSwitch >= 0)
            {
                Form1.listSwitches[_selectedSwitch].name = textBox_name.Text;
            }

            //gas pipe selected
            else if (_selectedGasPipe >= 0)
            {
                Form1.listGasPipes[_selectedGasPipe].name = textBox_name.Text;
                if (EntityDetection.IsHorizontal(Form1.listGasPipes[_selectedGasPipe].width))
                    Form1.listGasPipes[_selectedGasPipe].width = (int)numericUpDown_height.Value;
                else
                    Form1.listGasPipes[_selectedGasPipe].height = (int)numericUpDown_height.Value;

                Form1.listGasPipes[_selectedGasPipe].material = textBox_material.Text;
                Form1.listGasPipes[_selectedGasPipe].diameter = textBox_diameter.Text;
            }

            //gas tap selected
            else if (_selectedGasTap >= 0)
            {
                Form1.listGasTapes[_selectedGasTap].name = textBox_name.Text;
            }

            //water pipe selected
            else if (_selectedWaterPipe >= 0)
            {
                Form1.listWaterPipes[_selectedWaterPipe].name = textBox_name.Text;
                if (EntityDetection.IsHorizontal(Form1.listWaterPipes[_selectedWaterPipe].width))
                    Form1.listWaterPipes[_selectedWaterPipe].width = (int)numericUpDown_height.Value;
                else
                    Form1.listWaterPipes[_selectedWaterPipe].height = (int)numericUpDown_height.Value;

                Form1.listWaterPipes[_selectedWaterPipe].material = textBox_material.Text;
                Form1.listWaterPipes[_selectedWaterPipe].diameter = textBox_diameter.Text;
            }

            //water tap selected
            else if (_selectedWaterTap >= 0)
            {
                Form1.listWaterTapes[_selectedWaterTap].name = textBox_name.Text;
            }

            //label selected
            else if (_selectedLabel >= 0)
            {
                Form1.listWallLabels[_selectedLabel].text = textBox_name.Text;
            }

             listBox_explorer.ExplorerForm2();
            pictureBox_canvas.Invalidate();
        }

        //Zooming
        private void trackBar_zoom_ValueChanged(object sender, EventArgs e)
        {
            _prevZoom = _zoom;
            _zoom = trackBar_zoom.Value;
            label_zoom.Text = "x" + _zoom.ToString();
           
            Zoom.NewLocationsForAllStuff();

            pictureBox_canvas.Invalidate();
        }

        //Dimension buttons
        // Method for creation left-side dimension for selected object
        private void button_LeftDim_Click(object sender, EventArgs e)
        {
            foreach (Form1.objectDimension dim in Form1.listDimensions)
            {
                if (dim.wallId == _selectedWall && dim.wallSide == _wallSide && dim.dimType == "left")
                    if (dim.objectType == Get.SelectedObjectType() && dim.idObject == Get.SelectedObjectId())
                    {
                        Form1.listDimensions.Remove(dim);
                        pictureBox_canvas.Invalidate();
                        return;
                    }                       
            }

            Point finish = Get.LeftSideLocationOfObject();
            if(finish.X >= 0 && finish.Y >= 0)
            {
                Form1.objectDimension Dim = new Form1.objectDimension();
                Dim.startXY = new Point(_start_offsetX, finish.Y);
                Dim.wallId = _selectedWall;
                Dim.wallSide = _wallSide;
                Dim.dimType = "left";
                Dim.objectType = Get.SelectedObjectType();
                Dim.idObject = Get.SelectedObjectId();


                Form1.listDimensions.Add(Dim);
            }
            pictureBox_canvas.Invalidate();
        }

        // Method for creation up-side dimension for selected object
        private void button_UpDim_Click(object sender, EventArgs e)
        {
            foreach (Form1.objectDimension dim in Form1.listDimensions)
            {
                if (dim.wallId == _selectedWall && dim.wallSide == _wallSide && dim.dimType == "up")
                    if (dim.objectType == Get.SelectedObjectType() && dim.idObject == Get.SelectedObjectId())
                    {
                        Form1.listDimensions.Remove(dim);
                        pictureBox_canvas.Invalidate();
                        return;
                    }
            }

            Point finish = Get.UpSideLocationOfObject();
            if (finish.X >= 0 && finish.Y >= 0)
            {
                Form1.objectDimension Dim = new Form1.objectDimension();
                Dim.startXY = new Point(finish.X, _start_offsetY);
                Dim.wallId = _selectedWall;
                Dim.wallSide = _wallSide;
                Dim.dimType = "up";
                Dim.objectType = Get.SelectedObjectType();
                Dim.idObject = Get.SelectedObjectId();


                Form1.listDimensions.Add(Dim);
            }
            pictureBox_canvas.Invalidate();
        }

        // Method for creation right-side dimension for selected object
        private void button_RightDim_Click(object sender, EventArgs e)
        {
            foreach (Form1.objectDimension dim in Form1.listDimensions)
            {
                if (dim.wallId == _selectedWall && dim.wallSide == _wallSide && dim.dimType == "right")
                    if (dim.objectType == Get.SelectedObjectType() && dim.idObject == Get.SelectedObjectId())
                    {
                        Form1.listDimensions.Remove(dim);
                        pictureBox_canvas.Invalidate();
                        return;
                    }
            }

            Point finish = Get.RightSideLocationOfObject();
            if (finish.X >= 0 && finish.Y >= 0)
            {
                Form1.objectDimension Dim = new Form1.objectDimension();
                Dim.startXY = new Point(finish.X, finish.Y);
                Dim.wallId = _selectedWall;
                Dim.wallSide = _wallSide;
                Dim.dimType = "right";
                Dim.objectType = Get.SelectedObjectType();
                Dim.idObject = Get.SelectedObjectId();


                Form1.listDimensions.Add(Dim);
            }
            pictureBox_canvas.Invalidate();
        }

        // Method for creation down-side dimension for selected object
        private void button_DownDim_Click(object sender, EventArgs e)
        {
            foreach (Form1.objectDimension dim in Form1.listDimensions)
            {
                if (dim.wallId == _selectedWall && dim.wallSide == _wallSide && dim.dimType == "down")
                    if (dim.objectType == Get.SelectedObjectType() && dim.idObject == Get.SelectedObjectId())
                    {
                        Form1.listDimensions.Remove(dim);
                        pictureBox_canvas.Invalidate();
                        return;
                    }
            }

            Point finish = Get.DownSideLocationOfObject();
            if (finish.X >= 0 && finish.Y >= 0)
            {
                Form1.objectDimension Dim = new Form1.objectDimension();
                Dim.startXY = new Point(finish.X, finish.Y);
                Dim.wallId = _selectedWall;
                Dim.wallSide = _wallSide;
                Dim.dimType = "down";
                Dim.objectType = Get.SelectedObjectType();
                Dim.idObject = Get.SelectedObjectId();


                Form1.listDimensions.Add(Dim);
            }
            pictureBox_canvas.Invalidate();
        }

    //My methods
      
        private void RemoveChildDimensions(string type, int id)
        {
            int count = Form1.listDimensions.Count();
            for (int i = 0; i < count; i++)
            {
                Form1.objectDimension dim = Form1.listDimensions[i];
                if (dim.wallId == _selectedWall && dim.wallSide == _wallSide)
                    if (dim.objectType == type && dim.idObject == id)
                    {
                        Form1.listDimensions.Remove(dim);
                        i--;
                        count--;
                    }
                        
            }
        }

        private bool IsNameAlreadyUsed(string name)
        {
            foreach (Form1.objectEntity obj in Form1.listWindows)
                if (obj.name == name && obj != Form1.listWindows[_selectedWindow])
                    return true;

            foreach (Form1.objectEntity obj in Form1.listDoors)
                if (obj.name == name && obj != Form1.listDoors[_selectedDoor])
                    return true;

            foreach (Form1.objectCableEntity obj in Form1.listCables)
                if (obj.name == name && obj != Form1.listCables[_selectedCable])
                    return true;

            foreach (Form1.objectEntity obj in Form1.listElectricalBoxes)
                if (obj.name == name && obj != Form1.listElectricalBoxes[_selectedElectricalBox])
                    return true;

            foreach (Form1.objectEntity obj in Form1.listSockets)
                if (obj.name == name && obj != Form1.listSockets[_selectedSocket])
                    return true;

            foreach (Form1.objectEntity obj in Form1.listSwitches)
                if (obj.name == name && obj != Form1.listSwitches[_selectedSwitch])
                    return true;

            foreach (Form1.objectPipeEntity obj in Form1.listGasPipes)
                if (obj.name == name && obj != Form1.listGasPipes[_selectedGasPipe])
                    return true;

            foreach (Form1.objectPipeEntity obj in Form1.listWaterPipes)
                if (obj.name == name && obj != Form1.listWaterPipes[_selectedWaterPipe])
                    return true;

            foreach (Form1.objectTapEntity obj in Form1.listGasTapes)
                if (obj.name == name && obj != Form1.listGasTapes[_selectedGasTap])
                    return true;

            foreach (Form1.objectTapEntity obj in Form1.listWaterTapes)
                if (obj.name == name && obj != Form1.listWaterTapes[_selectedWaterTap])
                    return true;

            foreach (Form1.WallLabels obj in Form1.listWallLabels)
                if (obj.text == name && obj != Form1.listWallLabels[_selectedLabel])
                    return true;

            return false;
        }


        //show methods
        //hide all properties
        private void ShowNothing()
        {
            label_name.Visible = false;
            textBox_name.Visible = false;

            label_height.Visible = false;
            numericUpDown_height.Visible = false;

            label_width.Visible = false;
            numericUpDown_width.Visible = false;

            label_material.Visible = false;
            textBox_material.Visible = false;

            label_isolation.Visible = false;
            textBox_isolation.Visible = false;

            label_numOfWires.Visible = false;
            numericUpDown_numOfWires.Visible = false;

            label_diameter.Visible = false;
            textBox_diameter.Visible = false;

            button_save.Visible = false;
            button_turnObject.Visible = false;
        }

        //showl all properties
        private void showAll()
        {
            label_name.Visible = true;
            textBox_name.Visible = true;

            label_height.Visible = true;
            label_height.Text = "Výška";
            numericUpDown_height.Visible = true;
            numericUpDown_height.Minimum = 1;

            label_width.Visible = true;
            numericUpDown_width.Visible = true;
            numericUpDown_width.Minimum = 1;

            label_material.Visible = true;
            textBox_material.Visible = true;

            label_isolation.Visible = true;
            textBox_isolation.Visible = true;

            label_numOfWires.Visible = true;
            numericUpDown_numOfWires.Visible = true;

            label_diameter.Visible = true;
            textBox_diameter.Visible = true;

            button_save.Visible = true;
            button_turnObject.Visible = true;
        }

        //Prepare properties for window, door
        private void ShowRectangleProperties()
        {
            showAll();
            if(_selectedWindow >= 0)
            {
                textBox_name.Text = Form1.listWindows[_selectedWindow].name;
                numericUpDown_height.Value = Form1.listWindows[_selectedWindow].height;
                numericUpDown_width.Value = Form1.listWindows[_selectedWindow].width;
            }
            else if(_selectedDoor >= 0)
            {
                textBox_name.Text = Form1.listDoors[_selectedDoor].name;
                numericUpDown_height.Value = Form1.listDoors[_selectedDoor].height;
                numericUpDown_width.Value = Form1.listDoors[_selectedDoor].width;
            }

            textBox_name.Enabled = true;
            numericUpDown_height.Enabled = true;
            numericUpDown_width.Enabled = true;
            textBox_material.Enabled = false;
            textBox_isolation.Enabled = false;
            numericUpDown_numOfWires.Enabled = false;
            textBox_diameter.Enabled = false;
        }

        //Prepare properties for electrical box, socket, switch
        private void ShowOnlyNameProperties()
        {
            showAll();
            if(_selectedElectricalBox >= 0)
                textBox_name.Text = Form1.listElectricalBoxes[_selectedElectricalBox].name;
            else if(_selectedSocket >= 0)
                textBox_name.Text = Form1.listSockets[_selectedSocket].name;
            else if(_selectedSwitch >= 0)
                textBox_name.Text = Form1.listSwitches[_selectedSwitch].name;

            textBox_name.Enabled = true;
            numericUpDown_height.Enabled = false;
            numericUpDown_width.Enabled = false;
            textBox_material.Enabled = false;
            textBox_isolation.Enabled = false;
            numericUpDown_numOfWires.Enabled = false;
            textBox_diameter.Enabled = false;
        }

        private void button_MoveUp_Click(object sender, EventArgs e)
        {
            string obj_type = Get.SelectedObjectType();
            int id = Get.SelectedObjectId();

            if(obj_type == "window")
            {
                Form1.listWindows[id].locationXY.Y--;
            }
            else if (obj_type == "door")
            {
                Form1.listDoors[id].locationXY.Y--;
            }
            else if (obj_type == "cable")
            {
                Form1.listCables[id].locationXY.Y--;
            }
            else if (obj_type == "box")
            {
                Form1.listElectricalBoxes[id].locationXY.Y--;
            }
            else if (obj_type == "socket")
            {
                Form1.listSockets[id].locationXY.Y--;
            }
            else if (obj_type == "switch")
            {
                Form1.listSwitches[id].locationXY.Y--;
            }
            else if (obj_type == "gas_pipe")
            {
                Form1.listGasPipes[id].locationXY.Y--;
            }
            else if (obj_type == "gas_tap")
            {
                Form1.listGasTapes[id].locationXY.Y--;
            }
            else if (obj_type == "water_pipe")
            {
                Form1.listWaterPipes[id].locationXY.Y--;
            }
            else if (obj_type == "water_tap")
            {
                Form1.listWaterTapes[id].locationXY.Y--;
            }
            else if (obj_type == "label")
            {
                Form1.listWallLabels[id].XY.Y--;
            }
            Actualize.RightDownDims();
            pictureBox_canvas.Invalidate();
        }

        private void button_MoveRight_Click(object sender, EventArgs e)
        {
            string obj_type = Get.SelectedObjectType();
            int id = Get.SelectedObjectId();

            if (obj_type == "window")
            {
                Form1.listWindows[id].locationXY.X++;
            }
            else if (obj_type == "door")
            {
                Form1.listDoors[id].locationXY.X++;
            }
            else if (obj_type == "cable")
            {
                Form1.listCables[id].locationXY.X++;
            }
            else if (obj_type == "box")
            {
                Form1.listElectricalBoxes[id].locationXY.X++;
            }
            else if (obj_type == "socket")
            {
                Form1.listSockets[id].locationXY.X++;
            }
            else if (obj_type == "switch")
            {
                Form1.listSwitches[id].locationXY.X++;
            }
            else if (obj_type == "gas_pipe")
            {
                Form1.listGasPipes[id].locationXY.X++;
            }
            else if (obj_type == "gas_tap")
            {
                Form1.listGasTapes[id].locationXY.X++;
            }
            else if (obj_type == "water_pipe")
            {
                Form1.listWaterPipes[id].locationXY.X++;
            }
            else if (obj_type == "water_tap")
            {
                Form1.listWaterTapes[id].locationXY.X++;
            }
            else if (obj_type == "label")
            {
                Form1.listWallLabels[id].XY.X++;
            }
            Actualize.RightDownDims();
            pictureBox_canvas.Invalidate();
        }

        private void button_MoveDown_Click(object sender, EventArgs e)
        {
            string obj_type = Get.SelectedObjectType();
            int id = Get.SelectedObjectId();

            if (obj_type == "window")
            {
                Form1.listWindows[id].locationXY.Y++;
            }
            else if (obj_type == "door")
            {
                Form1.listDoors[id].locationXY.Y++;
            }
            else if (obj_type == "cable")
            {
                Form1.listCables[id].locationXY.Y++;
            }
            else if (obj_type == "box")
            {
                Form1.listElectricalBoxes[id].locationXY.Y++;
            }
            else if (obj_type == "socket")
            {
                Form1.listSockets[id].locationXY.Y++;
            }
            else if (obj_type == "switch")
            {
                Form1.listSwitches[id].locationXY.Y++;
            }
            else if (obj_type == "gas_pipe")
            {
                Form1.listGasPipes[id].locationXY.Y++;
            }
            else if (obj_type == "gas_tap")
            {
                Form1.listGasTapes[id].locationXY.Y++;
            }
            else if (obj_type == "water_pipe")
            {
                Form1.listWaterPipes[id].locationXY.Y++;
            }
            else if (obj_type == "water_tap")
            {
                Form1.listWaterTapes[id].locationXY.Y++;
            }
            else if (obj_type == "label")
            {
                Form1.listWallLabels[id].XY.Y++;
            }
            Actualize.RightDownDims();
            pictureBox_canvas.Invalidate();
        }

        private void button_MoveLeft_Click(object sender, EventArgs e)
        {
            string obj_type = Get.SelectedObjectType();
            int id = Get.SelectedObjectId();

            if (obj_type == "window")
            {
                Form1.listWindows[id].locationXY.X--;
            }
            else if (obj_type == "door")
            {
                Form1.listDoors[id].locationXY.X--;
            }
            else if (obj_type == "cable")
            {
                Form1.listCables[id].locationXY.X--;
            }
            else if (obj_type == "box")
            {
                Form1.listElectricalBoxes[id].locationXY.X--;
            }
            else if (obj_type == "socket")
            {
                Form1.listSockets[id].locationXY.X--;
            }
            else if (obj_type == "switch")
            {
                Form1.listSwitches[id].locationXY.X--;
            }
            else if (obj_type == "gas_pipe")
            {
                Form1.listGasPipes[id].locationXY.X--;
            }
            else if (obj_type == "gas_tap")
            {
                Form1.listGasTapes[id].locationXY.X--;
            }
            else if (obj_type == "water_pipe")
            {
                Form1.listWaterPipes[id].locationXY.X--;
            }
            else if (obj_type == "water_tap")
            {
                Form1.listWaterTapes[id].locationXY.X--;
            }
            else if (obj_type == "label")
            {
                Form1.listWallLabels[id].XY.X--;
            }
            Actualize.RightDownDims();
            pictureBox_canvas.Invalidate();
        }

        //Prepare properties for tapes
        private void ShowTapProperties()
        {
            showAll();

            if (_selectedGasTap >= 0)
                textBox_name.Text = Form1.listGasTapes[_selectedGasTap].name;
            else if (_selectedWaterTap >= 0)
                textBox_name.Text = Form1.listWaterTapes[_selectedWaterTap].name;

            if (_selectedGasTap >= 0)
                textBox_diameter.Text = Form1.listGasTapes[_selectedGasTap].diameter;
            else if (_selectedWaterTap >= 0)
                textBox_diameter.Text = Form1.listWaterTapes[_selectedWaterTap].diameter;

            textBox_name.Enabled = true;
            numericUpDown_height.Enabled = false;
            numericUpDown_width.Enabled = false;
            textBox_material.Enabled = false;
            textBox_isolation.Enabled = false;
            numericUpDown_numOfWires.Enabled = false;
            textBox_diameter.Enabled = true;
        }

        //Prepare properties for electrical cable
        private void ShowCableProperties()
        {
            showAll();
            textBox_name.Enabled = true;
            textBox_name.Text = Form1.listCables[_selectedCable].name;
            label_height.Text = "Délka [cm]";
            numericUpDown_height.Enabled = true;
            numericUpDown_height.Minimum = 2;
            if (EntityDetection.IsHorizontal(Form1.listCables[_selectedCable].width))
                numericUpDown_height.Value = Form1.listCables[_selectedCable].width;
            else
                numericUpDown_height.Value = Form1.listCables[_selectedCable].height;

            numericUpDown_width.Enabled = false;
            textBox_material.Enabled = true;
            textBox_material.Text = Form1.listCables[_selectedCable].material_of_wires;
            textBox_isolation.Enabled = true;
            textBox_isolation.Text = Form1.listCables[_selectedCable].isolation;
            numericUpDown_numOfWires.Enabled = true;
            numericUpDown_numOfWires.Value = Form1.listCables[_selectedCable].num_of_wires;
            textBox_diameter.Enabled = true;
            textBox_diameter.Text = Form1.listCables[_selectedCable].diameter;
        }

        //Prepare properties for gas and water pipe
        private void ShowPipeProperties()
        {
            showAll();
            textBox_name.Enabled = true;
            if(_selectedGasPipe >= 0)
            {
                textBox_name.Text = Form1.listGasPipes[_selectedGasPipe].name;
                if (EntityDetection.IsHorizontal(Form1.listGasPipes[_selectedGasPipe].width))
                    numericUpDown_height.Value = Form1.listGasPipes[_selectedGasPipe].width;
                else
                    numericUpDown_height.Value = Form1.listGasPipes[_selectedGasPipe].height;

                textBox_material.Text = Form1.listGasPipes[_selectedGasPipe].material;
                textBox_diameter.Text = Form1.listGasPipes[_selectedGasPipe].diameter;
            }
            else if (_selectedWaterPipe >= 0)
            {
                textBox_name.Text = Form1.listWaterPipes[_selectedWaterPipe].name;
                if (EntityDetection.IsHorizontal(Form1.listWaterPipes[_selectedWaterPipe].width))
                    numericUpDown_height.Value = Form1.listWaterPipes[_selectedWaterPipe].width;
                else
                    numericUpDown_height.Value = Form1.listWaterPipes[_selectedWaterPipe].height;

                textBox_material.Text = Form1.listWaterPipes[_selectedWaterPipe].material;
                textBox_diameter.Text = Form1.listWaterPipes[_selectedWaterPipe].diameter;
            }

            label_height.Text = "Délka [cm]";
            numericUpDown_height.Enabled = true;
            numericUpDown_height.Minimum = 2;
            
           
            numericUpDown_width.Enabled = false;
            textBox_material.Enabled = true;
            
            textBox_isolation.Enabled = false;            
            numericUpDown_numOfWires.Enabled = false;

            textBox_diameter.Enabled = true;
            
        }

        private void ShowLabelProperties()
        {
            showAll();
            textBox_name.Enabled = true;
            textBox_name.Text = Form1.listWallLabels[_selectedLabel].text;
            numericUpDown_height.Enabled = false;
            numericUpDown_width.Enabled = false;
            textBox_material.Enabled = false;
            textBox_isolation.Enabled = false;
            numericUpDown_numOfWires.Enabled = false;
            textBox_diameter.Enabled = false;
        }

    //Drawing       
        private void pictureBox_canvas_Paint(object sender, PaintEventArgs e)
        {
            //Draw wall corpus
            Graphics g = e.Graphics;
            Pen pen = new Pen(Color.Black, 5);

            //Draw wall silhouette
            g.DrawRectangle(pen, _start_offsetX, _start_offsetY, _openedWall.lenght * _zoom, _openedWall.height * _zoom);

            //Draw all created elements
            Draw.CreatedElements(pen,g);

            //Realtime drawing
            if (_isMouseDown)
            {
                pen.Width = 1;
                pen.Color = Color.Gray;
                Draw.Realtime(pen, g);
            }

            //selected window
            Draw.Selected(pen, g);
        }

        private void listBox_explorer_SelectedIndexChanged(object sender, EventArgs e)
        {
            int idx = listBox_explorer.SelectedIndex;
            _selectedWindow = -1;
            _selectedDoor = -1;
            _selectedCable = -1;
            _selectedElectricalBox = -1;
            _selectedSocket = -1;
            _selectedSwitch = -1;
            _selectedGasPipe = -1;
            _selectedGasTap = -1;
            _selectedWaterPipe = -1;
            _selectedWaterTap = -1;
            _selectedDimension = -1;
            _selectedLabel = -1;

            int a = Get.TrueCount("window");
            int b = Get.TrueCount("door");
            int c = Get.TrueCount("cable");
            int d = Get.TrueCount("box");
            int ee = Get.TrueCount("socket");
            int f = Get.TrueCount("switch");
            int g = Get.TrueCount("gas_pipe");
            int h = Get.TrueCount("gas_tap");
            int i = Get.TrueCount("water_pipe");
            int j = Get.TrueCount("water_tap");
            int k = Get.TrueCount("label");

            string str = listBox_explorer.SelectedItem.ToString();

            //index of window
            if (idx >= 0 && idx < a)
            {
                _selectedWindow = Get.IndexFromExplorer(str);
                ShowRectangleProperties();
            }
            //index of door
            else if(idx >= a && idx < a + b)
            {
                _selectedDoor = Get.IndexFromExplorer(str);
                ShowRectangleProperties();
            }
            //index of cable
            else if(idx >= a + b && idx < a + b + c)
            {
                _selectedCable = Get.IndexFromExplorer(str);
                ShowCableProperties();
            }
            //index of box
            else if (idx >= a + b + c && idx < a + b + c + d)
            {
                _selectedElectricalBox = Get.IndexFromExplorer(str);
                ShowOnlyNameProperties();
            }
            //index of socket
            else if (idx >= a + b + c + d && idx < a + b + c + d + ee)
            {
                _selectedSocket = Get.IndexFromExplorer(str);
                ShowOnlyNameProperties();
            }
            //index of switch
            else if (idx >= a + b + c + d + ee && idx < a + b + c + d + ee + f)
            {
                _selectedSwitch = Get.IndexFromExplorer(str);
                ShowOnlyNameProperties();
            }
            //index of gas pipe
            else if (idx >= a + b + c + d + ee + f&& idx < a + b + c + d + ee + f + g)
            {
                _selectedGasPipe = Get.IndexFromExplorer(str);
                ShowPipeProperties();
            }
            //index of gas tap
            else if (idx >= a + b + c + d + ee + f + g && idx < a + b + c + d + ee + f + g + h)
            {
                _selectedGasTap = Get.IndexFromExplorer(str);
                ShowTapProperties();
            }
            //index of water pipe
            else if (idx >= a + b + c + d + ee + f + g + h && idx < a + b + c + d + ee + f + g + h + i)
            {
                _selectedWaterPipe = Get.IndexFromExplorer(str);
                ShowPipeProperties();
            }
            //index of water tap
            else if (idx >= a + b + c + d + ee + f + g + h + i && idx < a + b + c + d + ee + f + g + h + i + j)
            {
                _selectedWaterTap = Get.IndexFromExplorer(str);
                ShowTapProperties();
            }
            //Index of label
            else if (idx >= a + b + c + d + ee + f + g + h + i + j && idx < a + b + c + d + ee + f + g + h + i + j + k)
            {
                _selectedLabel = Get.IndexFromExplorer(str);
                ShowLabelProperties();
            }
            pictureBox_canvas.Invalidate();
        }

    }
}
