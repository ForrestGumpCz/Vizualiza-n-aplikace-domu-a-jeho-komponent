﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Drawing;

namespace Test
{
    [TestClass]
    public class MousePriximityDetection_Tests
    {
        [TestMethod]
        public void MouseProximityDetectionTest_TRUE()
        {
            Point startPoint = new Point(10, 10);
            Point mouseLocation = new Point(9, 14);
            int toleranceX = 5;
            int toleranceY = 5;
            bool result = VisualizationApp.EntityDetection.MouseProximityDetection(startPoint, mouseLocation, toleranceX, toleranceY);

            Assert.IsTrue(result);
        }
        [TestMethod]
        public void MouseProximityDetectionTest_FALSE()
        {
            Point startPoint = new Point(10, 10);
            Point mouseLocation = new Point(0, 0);
            int toleranceX = 5;
            int toleranceY = 5;
            bool result = VisualizationApp.EntityDetection.MouseProximityDetection(startPoint, mouseLocation, toleranceX, toleranceY);

            Assert.IsFalse(result);
        }
    }
}
