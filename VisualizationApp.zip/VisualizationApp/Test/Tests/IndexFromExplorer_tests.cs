﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace Test
{
    [TestClass]
    public class IndexFromExplorer_tests
    {
        [TestMethod]
        public void GetIndexFromExplorer()
        {
            string str = "2: text text text";

            int result = VisualizationApp.Get.IndexFromExplorer(str);

            Assert.AreEqual(2, result);
        }
    }
}
