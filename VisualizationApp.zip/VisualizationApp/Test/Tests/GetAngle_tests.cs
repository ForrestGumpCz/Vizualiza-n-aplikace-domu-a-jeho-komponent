﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Drawing;

namespace Test
{
    [TestClass]
    public class GetAngle_tests
    {
        [TestMethod]
        public void GetAngle()
        {
            Point p1 = new Point(0, 0);
            Point p2 = new Point(50, 50);

            float result = VisualizationApp.Get.Angle(p1,p2);

            Assert.AreEqual(45f, result);
        }
    }
}
