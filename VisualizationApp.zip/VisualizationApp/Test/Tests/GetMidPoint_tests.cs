﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Drawing;

namespace Test
{
    [TestClass]
    public class GetMidPoint_tests
    {
        [TestMethod]
        public void GetMidPoint_TRUE()
        {
            Point from = new Point(0, 0);
            Point to = new Point(50, 50);
            int offset = 0;
            Point result = VisualizationApp.Get.MidPoint(from, to,offset);

            Point expected_result = new Point(25,25);
            Assert.AreEqual(expected_result,result);
        }
    }
}
