﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Drawing;

namespace Test
{
    [TestClass]
    public class GetDistance_tests
    {
        [TestMethod]
        public void GetDistance_TRUE()
        {
            Point from = new Point(0, 0);
            Point to = new Point(50, 50);
            int result = VisualizationApp.Get.Distance(from, to);

            int expected_result = (int)70.710678118655;
            Assert.AreEqual(expected_result,result);
        }
    }
}
